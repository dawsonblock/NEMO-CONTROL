package cli

import (
	"errors"
	"slices"
	"strings"
)

// CommandIntent separates command meaning from an adapter's execution transport.
// Its arguments/source are owned snapshots; providers still choose the shell,
// working directory, environment, and any outer command wrapping.
type CommandIntent struct {
	args   []string
	source string
	shell  bool
}

func ParseCommandIntent(command []string, shellMode bool, literalArgs map[int]bool) (CommandIntent, error) {
	if len(command) == 0 {
		return CommandIntent{}, errors.New("missing command")
	}
	if shellMode || shouldUseShellWithLiteralArgs(command, literalArgs) {
		return CommandIntent{
			shell:  true,
			source: runCommandShellStringWithLiteralArgs(command, shellMode, literalArgs),
		}, nil
	}
	return CommandIntent{args: slices.Clone(command)}, nil
}

// Argv applies the transport's shell prefix only to shell intent, including an
// explicitly empty shell source. Both the prefix and literal arguments are copied.
func (c CommandIntent) Argv(shellPrefix ...string) []string {
	if c.shell {
		return append(slices.Clone(shellPrefix), c.source)
	}
	return slices.Clone(c.args)
}

// ShellCommand quotes execution argv for a POSIX source-only transport. Once
// classified, arguments must not be reinterpreted as operators or assignments.
func (c CommandIntent) ShellCommand(shellPrefix ...string) string {
	return strings.Join(shellWords(c.Argv(shellPrefix...)), " ")
}

// ShellSource renders a terminal workload for the caller's existing POSIX shell.
// Shell intent remains source in that shell; literal argv replaces it with exec.
func (c CommandIntent) ShellSource() string {
	if c.shell {
		return c.source
	}
	return "exec " + strings.Join(shellWords(c.args), " ")
}
