package cli

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/alecthomas/kong"
	"github.com/openclaw/crabbox/internal/execution"
)

type crabboxKongCLI struct {
	Version kong.VersionFlag `name:"version" short:"v" help:"Print version."`

	VersionCmd  versionKongCmd     `cmd:"" name:"version" help:"Print version."`
	Init        initKongCmd        `cmd:"" passthrough:"" help:"Onboard the current repo for Crabbox."`
	Login       loginKongCmd       `cmd:"" passthrough:"" help:"Open GitHub login, store broker credentials, verify access."`
	Logout      logoutKongCmd      `cmd:"" passthrough:"" help:"Remove the stored broker token."`
	Whoami      whoamiKongCmd      `cmd:"" passthrough:"" help:"Show broker identity."`
	Doctor      doctorKongCmd      `cmd:"" passthrough:"" help:"Check local and broker/provider readiness."`
	Warmup      warmupKongCmd      `cmd:"" passthrough:"" help:"Lease a box and wait until it is ready."`
	Prewarm     prewarmKongCmd     `cmd:"" passthrough:"" help:"Lease and hydrate a reusable test-ready box."`
	Run         runKongCmd         `cmd:"" passthrough:"" help:"Sync the repo, run a remote command, stream output."`
	Exec        execKongCmd        `cmd:"" passthrough:"" help:"Execute a capability via JSON stdin/stdout (NeMo bridge)."`
	ServeExec   serveExecKongCmd   `cmd:"" help:"Start the persistent execution service (Unix socket)."`
	Invoke      invokeKongCmd      `cmd:"" help:"Invoke a capability via the execution service (planner-agnostic client)."`
	Watch       watchKongCmd       `cmd:"" passthrough:"" help:"Re-run a command on a warm lease when local files change."`
	Shard       shardKongCmd       `cmd:"" passthrough:"" help:"Fork a checkpoint into parallel shards and merge their test results."`
	Bench       benchKongCmd       `cmd:"" help:"Record and report local benchmark timings."`
	Job         jobKongCmd         `cmd:"" help:"Run named repo-local Crabbox jobs."`
	Desktop     desktopKongCmd     `cmd:"" help:"Launch apps into a visible desktop session."`
	Media       mediaKongCmd       `cmd:"" help:"Create preview artifacts from recorded desktop videos."`
	Artifacts   artifactsKongCmd   `cmd:"" help:"Collect, transform, and publish QA artifacts."`
	SyncPlan    syncPlanKongCmd    `cmd:"" name:"sync-plan" passthrough:"" help:"Show local sync manifest size hotspots."`
	Providers   providersKongCmd   `cmd:"" passthrough:"" help:"Show provider capabilities and recommendations."`
	History     historyKongCmd     `cmd:"" passthrough:"" help:"List recorded remote runs."`
	Logs        logsKongCmd        `cmd:"" passthrough:"" help:"Print recorded run logs."`
	Events      eventsKongCmd      `cmd:"" passthrough:"" help:"Print recorded run events."`
	Attach      attachKongCmd      `cmd:"" passthrough:"" help:"Follow recorded events for an active run."`
	Results     resultsKongCmd     `cmd:"" passthrough:"" help:"Show recorded test result summaries."`
	Receipt     receiptKongCmd     `cmd:"" passthrough:"" help:"Retrieve and verify a signed terminal run receipt."`
	Verify      verifyKongCmd      `cmd:"" passthrough:"" help:"Verify a signed run receipt."`
	Evidence    evidenceKongCmd    `cmd:"" passthrough:"" help:"Verify a RunEvidenceV1 document (digest, receipt binding, signature)."`
	Cache       cacheKongCmd       `cmd:"" help:"Inspect, purge, or warm remote caches."`
	Status      statusKongCmd      `cmd:"" passthrough:"" help:"Show lease state; add --wait to block until ready."`
	Heartbeat   heartbeatKongCmd   `cmd:"" passthrough:"" help:"Refresh a lease idle deadline and print its state."`
	Claims      claimsKongCmd      `cmd:"" help:"Inspect unverified local lease claims without loading providers."`
	List        listKongCmd        `cmd:"" passthrough:"" help:"List Crabbox machines."`
	Ports       portsKongCmd       `cmd:"" passthrough:"" help:"Publish, list, or unpublish provider-native ports."`
	Cp          cpKongCmd          `cmd:"" name:"cp" passthrough:"" help:"Copy files between the host and a lease."`
	Tunnel      tunnelKongCmd      `cmd:"" passthrough:"" help:"Forward a lease loopback port to this machine."`
	Share       shareKongCmd       `cmd:"" passthrough:"" help:"Share a lease with users or the owning org."`
	Unshare     unshareKongCmd     `cmd:"" passthrough:"" help:"Remove lease sharing."`
	Image       imageKongCmd       `cmd:"" help:"Create provider images and promote brokered AWS runner images."`
	Usage       usageKongCmd       `cmd:"" passthrough:"" help:"Show cost and usage estimates by user, org, or fleet."`
	Capacity    capacityKongCmd    `cmd:"" passthrough:"" help:"Show self-owner admission count and effective owner limit."`
	Marketplace marketplaceKongCmd `cmd:"" help:"Preview the Crabbox credits gateway and smart routing quotes."`
	Admin       adminKongCmd       `cmd:"" help:"Lease admin controls for trusted operators."`
	Actions     actionsKongCmd     `cmd:"" help:"Register GitHub Actions runners or dispatch workflows."`
	Capsule     capsuleKongCmd     `cmd:"" help:"Capture and replay lightweight failure capsules."`
	Checkpoint  checkpointKongCmd  `cmd:"" help:"Create, restore, and fork VM or workspace checkpoints."`
	Ssh         sshKongCmd         `cmd:"" name:"ssh" passthrough:"" help:"Print the SSH command for a lease."`
	Connect     connectKongCmd     `cmd:"" passthrough:"" help:"Open an interactive SSH session to a lease."`
	Open        openKongCmd        `cmd:"" passthrough:"" help:"Prepare an editor handoff for a lease."`
	Vnc         vncKongCmd         `cmd:"" name:"vnc" passthrough:"" help:"Print or open VNC connection details for a desktop lease."`
	Webvnc      webvncKongCmd      `cmd:"" name:"webvnc" passthrough:"" help:"Open a desktop lease or local VNC tunnel in a browser."`
	Code        codeKongCmd        `cmd:"" passthrough:"" help:"Bridge a code lease into the authenticated web portal."`
	Egress      egressKongCmd      `cmd:"" passthrough:"" help:"Bridge lease browser/app traffic through this machine."`
	Screenshot  screenshotKongCmd  `cmd:"" passthrough:"" help:"Capture a PNG from a desktop lease."`
	Inspect     inspectKongCmd     `cmd:"" passthrough:"" help:"Print lease/provider details; add --json for scripts."`
	Stop        stopKongCmd        `cmd:"" passthrough:"" help:"Release a lease or delete a direct-provider machine."`
	Release     releaseKongCmd     `cmd:"" passthrough:"" help:"Alias for stop."`
	Pause       pauseKongCmd       `cmd:"" passthrough:"" help:"Pause a lease, freeing remote compute while preserving state (provider-dependent)."`
	Resume      resumeKongCmd      `cmd:"" passthrough:"" help:"Resume a previously paused lease."`
	Cleanup     cleanupKongCmd     `cmd:"" passthrough:"" help:"Sweep expired direct-provider machines or local provider state."`
	Azure       azureKongCmd       `cmd:"" help:"Azure provider setup and login."`
	Config      configKongCmd      `cmd:"" help:"Show or update user config."`
	Adapter     adapterKongCmd     `cmd:"" help:"Serve or connect the Crabfleet runtime adapter."`
	Pool        poolKongCmd        `cmd:"" help:"Alias commands for machine pools."`
	Machine     machineKongCmd     `cmd:"" help:"Alias commands for direct-provider machines."`
	Pond        pondKongCmd        `cmd:"" help:"Pond bridge plane: peer discovery for delegated providers."`
}

type kongExit struct {
	code int
}

func (a App) runKong(ctx context.Context, args []string) (err error) {
	args = normalizeKongHelpArgs(args)
	var cli crabboxKongCLI
	parser, err := kong.New(&cli,
		kong.Name("crabbox"),
		kong.Description("Crabbox leases remote test boxes, syncs your dirty checkout, runs commands, and cleans up."),
		kong.Vars{
			"version": currentVersion(),
			// One resolver owns the default socket path so
			// serve-exec, invoke, and exec cannot drift.
			"execution_socket": execution.DefaultSocketPath(),
		},
		kong.Writers(a.Stdout, a.Stderr),
		kong.Exit(func(code int) {
			panic(kongExit{code: code})
		}),
	)
	if err != nil {
		return err
	}
	defer func() {
		recovered := recover()
		if recovered == nil {
			return
		}
		if exit, ok := recovered.(kongExit); ok {
			if exit.code == 0 {
				err = nil
			} else {
				err = ExitError{Code: exit.code}
			}
			return
		}
		panic(recovered)
	}()
	kctx, err := parser.Parse(args)
	if err != nil {
		var parseErr *kong.ParseError
		if errors.As(err, &parseErr) {
			return exit(2, "%v", parseErr)
		}
		return err
	}
	kctx.BindTo(ctx, (*context.Context)(nil))
	return kctx.Run(a)
}

func normalizeKongHelpArgs(args []string) []string {
	if len(args) > 1 && args[0] == "help" {
		next := append([]string{}, args[1:]...)
		next = append(next, "--help")
		return next
	}
	if isKongCommandGroup(args[0]) && (len(args) == 1 || args[1] == "help") {
		return []string{args[0], "--help"}
	}
	return args
}

func isKongCommandGroup(command string) bool {
	switch command {
	case "actions", "adapter", "admin", "artifacts", "azure", "bench", "cache", "capsule", "checkpoint", "claims", "config", "pond", "desktop", "image", "job", "machine", "marketplace", "media", "pool":
		return true
	default:
		return false
	}
}

type initKongCmd struct {
	Args []string `arg:"" optional:""`
}
type loginKongCmd struct {
	Args []string `arg:"" optional:""`
}
type logoutKongCmd struct {
	Args []string `arg:"" optional:""`
}
type whoamiKongCmd struct {
	Args []string `arg:"" optional:""`
}
type doctorKongCmd struct {
	Args []string `arg:"" optional:""`
}
type warmupKongCmd struct {
	Args []string `arg:"" optional:""`
}
type prewarmKongCmd struct {
	Args []string `arg:"" optional:""`
}
type runKongCmd struct {
	Args []string `arg:"" optional:""`
}
type execKongCmd struct {
	Args []string `arg:"" optional:""`
}
type serveExecKongCmd struct {
	Socket string `help:"Unix socket path (default: the canonical per-user execution socket)" default:"${execution_socket}"`
}
type invokeKongCmd struct {
	Socket         string        `help:"Unix socket path (default: the canonical per-user execution socket)" default:"${execution_socket}"`
	Capability     string        `help:"Capability to invoke" required:""`
	Principal      string        `help:"Requesting principal" required:""`
	IdempotencyKey string        `help:"Idempotency key (required for MUTATION/CRITICAL)"`
	Arguments      string        `help:"Arguments as JSON" default:"{}"`
	ExecutionClass string        `help:"Execution class assertion (advisory; registry is authoritative)"`
	Deadline       string        `help:"RFC3339 deadline"`
	Timeout        time.Duration `help:"Client-side wait for a response; after transmission a timeout is UNKNOWN, never FAILED" default:"30s"`
}
type watchKongCmd struct {
	Args []string `arg:"" optional:""`
}
type shardKongCmd struct {
	Args []string `arg:"" optional:""`
}
type benchKongCmd struct {
	Run    benchRunKongCmd    `cmd:"" passthrough:"" help:"Run a workload across providers and record benchmark timings."`
	Record benchRecordKongCmd `cmd:"" passthrough:"" help:"Append a TimingReport JSON object to the local benchmark ledger."`
	Report benchReportKongCmd `cmd:"" passthrough:"" help:"Aggregate local benchmark timing observations."`
}
type benchRunKongCmd struct {
	Args []string `arg:"" optional:""`
}
type benchRecordKongCmd struct {
	Args []string `arg:"" optional:""`
}
type benchReportKongCmd struct {
	Args []string `arg:"" optional:""`
}
type jobKongCmd struct {
	List jobListKongCmd `cmd:"" passthrough:"" help:"List configured jobs."`
	Run  jobRunKongCmd  `cmd:"" passthrough:"" help:"Run a configured job."`
}
type jobListKongCmd struct {
	Args []string `arg:"" optional:""`
}
type jobRunKongCmd struct {
	Args []string `arg:"" optional:""`
}
type syncPlanKongCmd struct {
	Args []string `arg:"" optional:""`
}
type providersKongCmd struct {
	Args []string `arg:"" optional:""`
}
type historyKongCmd struct {
	Args []string `arg:"" optional:""`
}
type logsKongCmd struct {
	Args []string `arg:"" optional:""`
}
type eventsKongCmd struct {
	Args []string `arg:"" optional:""`
}
type attachKongCmd struct {
	Args []string `arg:"" optional:""`
}
type resultsKongCmd struct {
	Args []string `arg:"" optional:""`
}
type receiptKongCmd struct {
	Args []string `arg:"" optional:""`
}
type verifyKongCmd struct {
	Args []string `arg:"" optional:""`
}
type evidenceKongCmd struct {
	Args []string `arg:"" optional:""`
}
type portsKongCmd struct {
	Args []string `arg:"" optional:""`
}
type cpKongCmd struct {
	Args []string `arg:"" optional:""`
}
type tunnelKongCmd struct {
	Args []string `arg:"" optional:""`
}
type statusKongCmd struct {
	Args []string `arg:"" optional:""`
}
type heartbeatKongCmd struct {
	Args []string `arg:"" optional:""`
}
type claimsKongCmd struct {
	List claimsListKongCmd `cmd:"" passthrough:"" help:"List unverified local lease claims without loading providers."`
}
type claimsListKongCmd struct {
	Args []string `arg:"" optional:""`
}
type listKongCmd struct {
	Args []string `arg:"" optional:""`
}
type shareKongCmd struct {
	Args []string `arg:"" optional:""`
}
type unshareKongCmd struct {
	Args []string `arg:"" optional:""`
}
type usageKongCmd struct {
	Args []string `arg:"" optional:""`
}
type capacityKongCmd struct {
	Args []string `arg:"" optional:""`
}
type marketplaceKongCmd struct {
	Status marketplaceStatusKongCmd `cmd:"" passthrough:"" help:"Show credits gateway status."`
	Quote  marketplaceQuoteKongCmd  `cmd:"" passthrough:"" help:"Preview smart-routing provider quotes."`
}
type marketplaceStatusKongCmd struct {
	Args []string `arg:"" optional:""`
}
type marketplaceQuoteKongCmd struct {
	Args []string `arg:"" optional:""`
}
type sshKongCmd struct {
	Args []string `arg:"" optional:""`
}
type connectKongCmd struct {
	Args []string `arg:"" optional:""`
}
type openKongCmd struct {
	Args []string `arg:"" optional:""`
}
type vncKongCmd struct {
	Args []string `arg:"" optional:""`
}
type webvncKongCmd struct {
	Args []string `arg:"" optional:""`
}
type codeKongCmd struct {
	Args []string `arg:"" optional:""`
}
type egressKongCmd struct {
	Args []string `arg:"" optional:""`
}
type screenshotKongCmd struct {
	Args []string `arg:"" optional:""`
}
type inspectKongCmd struct {
	Args []string `arg:"" optional:""`
}
type stopKongCmd struct {
	Args []string `arg:"" optional:""`
}
type releaseKongCmd struct {
	Args []string `arg:"" optional:""`
}
type pauseKongCmd struct {
	Args []string `arg:"" optional:""`
}
type resumeKongCmd struct {
	Args []string `arg:"" optional:""`
}
type cleanupKongCmd struct {
	Args []string `arg:"" optional:""`
}

type desktopKongCmd struct {
	Launch   desktopLaunchKongCmd   `cmd:"" passthrough:"" help:"Start an app inside a desktop lease."`
	Terminal desktopTerminalKongCmd `cmd:"" passthrough:"" help:"Start a visible terminal inside a desktop lease."`
	Record   desktopRecordKongCmd   `cmd:"" passthrough:"" help:"Record desktop video from a lease."`
	Proof    desktopProofKongCmd    `cmd:"" passthrough:"" help:"Launch a terminal and collect proof artifacts."`
	Doctor   desktopDoctorKongCmd   `cmd:"" passthrough:"" help:"Check desktop session readiness for a lease."`
	Click    desktopClickKongCmd    `cmd:"" passthrough:"" help:"Click inside a desktop lease."`
	Paste    desktopPasteKongCmd    `cmd:"" passthrough:"" help:"Paste text into a desktop lease."`
	Type     desktopTypeKongCmd     `cmd:"" passthrough:"" help:"Type text into a desktop lease."`
	Key      desktopKeyKongCmd      `cmd:"" passthrough:"" help:"Send keys to a desktop lease."`
}
type desktopLaunchKongCmd struct {
	Args []string `arg:"" optional:""`
}
type desktopTerminalKongCmd struct {
	Args []string `arg:"" optional:""`
}
type desktopRecordKongCmd struct {
	Args []string `arg:"" optional:""`
}
type desktopProofKongCmd struct {
	Args []string `arg:"" optional:""`
}
type desktopDoctorKongCmd struct {
	Args []string `arg:"" optional:""`
}
type desktopClickKongCmd struct {
	Args []string `arg:"" optional:""`
}
type desktopPasteKongCmd struct {
	Args []string `arg:"" optional:""`
}
type desktopTypeKongCmd struct {
	Args []string `arg:"" optional:""`
}
type desktopKeyKongCmd struct {
	Args []string `arg:"" optional:""`
}

type mediaKongCmd struct {
	Preview mediaPreviewKongCmd `cmd:"" passthrough:"" help:"Create a trimmed animated GIF preview from a video."`
}
type mediaPreviewKongCmd struct {
	Args []string `arg:"" optional:""`
}

type artifactsKongCmd struct {
	Collect  artifactsCollectKongCmd  `cmd:"" passthrough:"" help:"Collect screenshots, video, logs, status, and metadata into a bundle."`
	Video    artifactsVideoKongCmd    `cmd:"" passthrough:"" help:"Record an MP4 from a desktop lease."`
	Gif      artifactsGifKongCmd      `cmd:"" passthrough:"" help:"Create a trimmed GIF preview from a video."`
	Template artifactsTemplateKongCmd `cmd:"" passthrough:"" help:"Write Mantis/OpenClaw QA summary markdown."`
	Publish  artifactsPublishKongCmd  `cmd:"" passthrough:"" help:"Upload a bundle and optionally comment inline-ready assets on a PR."`
	List     artifactsListKongCmd     `cmd:"" passthrough:"" help:"List files from an artifact manifest."`
	Pull     artifactsPullKongCmd     `cmd:"" passthrough:"" help:"Download files from an artifact manifest."`
}
type artifactsCollectKongCmd struct {
	Args []string `arg:"" optional:""`
}
type artifactsVideoKongCmd struct {
	Args []string `arg:"" optional:""`
}
type artifactsGifKongCmd struct {
	Args []string `arg:"" optional:""`
}
type artifactsTemplateKongCmd struct {
	Args []string `arg:"" optional:""`
}
type artifactsPublishKongCmd struct {
	Args []string `arg:"" optional:""`
}
type artifactsListKongCmd struct {
	Args []string `arg:"" optional:""`
}
type artifactsPullKongCmd struct {
	Args []string `arg:"" optional:""`
}

type cacheKongCmd struct {
	List    cacheListKongCmd    `cmd:"" passthrough:"" help:"Show remote cache usage."`
	Stats   cacheStatsKongCmd   `cmd:"" passthrough:"" help:"Show remote cache usage."`
	Purge   cachePurgeKongCmd   `cmd:"" passthrough:"" help:"Remove selected cache content."`
	Warm    cacheWarmKongCmd    `cmd:"" passthrough:"" help:"Run a command that populates caches."`
	Volumes cacheVolumesKongCmd `cmd:"" passthrough:"" help:"List configured provider cache volumes."`
}
type cacheListKongCmd struct {
	Args []string `arg:"" optional:""`
}
type cacheStatsKongCmd struct {
	Args []string `arg:"" optional:""`
}
type cachePurgeKongCmd struct {
	Args []string `arg:"" optional:""`
}
type cacheWarmKongCmd struct {
	Args []string `arg:"" optional:""`
}
type cacheVolumesKongCmd struct {
	Args []string `arg:"" optional:""`
}

type imageKongCmd struct {
	Create    imageCreateKongCmd    `cmd:"" passthrough:"" help:"Create a provider image from a brokered lease."`
	Promote   imagePromoteKongCmd   `cmd:"" passthrough:"" help:"Promote an AMI for brokered AWS runners."`
	FSRStatus imageFSRStatusKongCmd `cmd:"" name:"fsr-status" passthrough:"" help:"Show AWS Fast Snapshot Restore status for an image."`
	Delete    imageDeleteKongCmd    `cmd:"" passthrough:"" help:"Delete a provider image."`
}
type imageCreateKongCmd struct {
	Args []string `arg:"" optional:""`
}
type imagePromoteKongCmd struct {
	Args []string `arg:"" optional:""`
}
type imageFSRStatusKongCmd struct {
	Args []string `arg:"" optional:""`
}
type imageDeleteKongCmd struct {
	Args []string `arg:"" optional:""`
}

type adminKongCmd struct {
	Leases      adminLeasesKongCmd      `cmd:"" passthrough:"" help:"List coordinator lease records."`
	LeaseAudit  adminLeaseAuditKongCmd  `cmd:"" name:"lease-audit" passthrough:"" help:"Check expired coordinator leases against cloud provider state."`
	Providers   adminProvidersKongCmd   `cmd:"" passthrough:"" help:"Inspect provider identities and policies."`
	Hosts       adminHostsKongCmd       `cmd:"" passthrough:"" help:"List, allocate, or release provider hosts."`
	AWSIdentity adminAWSIdentityKongCmd `cmd:"" name:"aws-identity" passthrough:"" help:"Show the coordinator AWS caller identity."`
	AWSPolicy   adminAWSPolicyKongCmd   `cmd:"" name:"aws-policy" passthrough:"" help:"Print the baseline brokered AWS IAM policy."`
	MacHosts    adminMacHostsKongCmd    `cmd:"" name:"mac-hosts" passthrough:"" help:"List, allocate, or release AWS EC2 Mac Dedicated Hosts."`
	Release     adminReleaseKongCmd     `cmd:"" passthrough:"" help:"Mark a lease released."`
	Delete      adminDeleteKongCmd      `cmd:"" passthrough:"" help:"Delete the backing server and mark the lease released."`
}
type adminLeasesKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adminLeaseAuditKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adminProvidersKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adminHostsKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adminAWSIdentityKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adminAWSPolicyKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adminMacHostsKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adminReleaseKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adminDeleteKongCmd struct {
	Args []string `arg:"" optional:""`
}

type actionsKongCmd struct {
	Hydrate  actionsHydrateKongCmd  `cmd:"" passthrough:"" help:"Hydrate a lease from the configured repo workflow."`
	Register actionsRegisterKongCmd `cmd:"" passthrough:"" help:"Register an existing Linux lease as a GitHub Actions runner."`
	Dispatch actionsDispatchKongCmd `cmd:"" passthrough:"" help:"Dispatch the configured GitHub Actions workflow."`
}
type actionsHydrateKongCmd struct {
	Args []string `arg:"" optional:""`
}
type actionsRegisterKongCmd struct {
	Args []string `arg:"" optional:""`
}
type actionsDispatchKongCmd struct {
	Args []string `arg:"" optional:""`
}

type capsuleKongCmd struct {
	FromActions capsuleFromActionsKongCmd `cmd:"" name:"from-actions" passthrough:"" help:"Create a capsule from a GitHub Actions run URL."`
	Replay      capsuleReplayKongCmd      `cmd:"" passthrough:"" help:"Replay a capsule using Crabbox run."`
	Inspect     capsuleInspectKongCmd     `cmd:"" passthrough:"" help:"Inspect a capsule manifest and replay history."`
	Promote     capsulePromoteKongCmd     `cmd:"" passthrough:"" help:"Promote a capsule as a regression."`
}
type capsuleFromActionsKongCmd struct {
	Args []string `arg:"" optional:""`
}
type capsuleReplayKongCmd struct {
	Args []string `arg:"" optional:""`
}
type capsuleInspectKongCmd struct {
	Args []string `arg:"" optional:""`
}
type capsulePromoteKongCmd struct {
	Args []string `arg:"" optional:""`
}

type checkpointKongCmd struct {
	Create  checkpointCreateKongCmd  `cmd:"" passthrough:"" help:"Create a VM or workspace checkpoint from a lease."`
	Abandon checkpointAbandonKongCmd `cmd:"" passthrough:"" help:"Dispose of an exact source while retaining an unresolved checkpoint."`
	List    checkpointListKongCmd    `cmd:"" passthrough:"" help:"List coordinator-owned and local checkpoints."`
	Inspect checkpointInspectKongCmd `cmd:"" passthrough:"" help:"Inspect checkpoint metadata."`
	Policy  checkpointPolicyKongCmd  `cmd:"" passthrough:"" help:"Update coordinator-managed checkpoint retention."`
	Restore checkpointRestoreKongCmd `cmd:"" passthrough:"" help:"Restore a checkpoint onto an existing lease."`
	Fork    checkpointForkKongCmd    `cmd:"" passthrough:"" help:"Lease a new box from a checkpoint."`
	Delete  checkpointDeleteKongCmd  `cmd:"" passthrough:"" help:"Delete a checkpoint and provider snapshot."`
	Prune   checkpointPruneKongCmd   `cmd:"" passthrough:"" help:"Delete checkpoints matching age and kind filters."`
}
type checkpointCreateKongCmd struct {
	Args []string `arg:"" optional:""`
}
type checkpointAbandonKongCmd struct {
	Args []string `arg:"" optional:""`
}
type checkpointListKongCmd struct {
	Args []string `arg:"" optional:""`
}
type checkpointInspectKongCmd struct {
	Args []string `arg:"" optional:""`
}
type checkpointPolicyKongCmd struct {
	Args []string `arg:"" optional:""`
}
type checkpointRestoreKongCmd struct {
	Args []string `arg:"" optional:""`
}
type checkpointForkKongCmd struct {
	Args []string `arg:"" optional:""`
}
type checkpointDeleteKongCmd struct {
	Args []string `arg:"" optional:""`
}
type checkpointPruneKongCmd struct {
	Args []string `arg:"" optional:""`
}

type configKongCmd struct {
	Path      configPathKongCmd      `cmd:"" help:"Print the user config path."`
	Show      configShowKongCmd      `cmd:"" passthrough:"" help:"Print merged config without secret values."`
	SetBroker configSetBrokerKongCmd `cmd:"" name:"set-broker" passthrough:"" help:"Store broker URL and optional tokens in user config."`
}

type azureKongCmd struct {
	Login azureLoginKongCmd `cmd:"" passthrough:"" help:"Detect subscription from az CLI, validate credentials, store in user config."`
}
type azureLoginKongCmd struct {
	Args []string `arg:"" optional:""`
}
type configPathKongCmd struct{}
type configShowKongCmd struct {
	Args []string `arg:"" optional:""`
}
type configSetBrokerKongCmd struct {
	Args []string `arg:"" optional:""`
}

type adapterKongCmd struct {
	Serve   controllerServeKongCmd `cmd:"" passthrough:"" help:"Serve the authenticated workspace lifecycle API."`
	Connect adapterConnectKongCmd  `cmd:"" passthrough:"" help:"Connect a local Unix-socket runtime adapter to the configured coordinator."`
	Ingress adapterIngressKongCmd  `cmd:"" passthrough:"" help:"Serve an authenticated ingress for a loopback adapter or fleet service."`
	State   controllerStateKongCmd `cmd:"" help:"Inspect adapter state without lifecycle side effects."`
}
type adapterConnectKongCmd struct {
	Args []string `arg:"" optional:""`
}
type adapterIngressKongCmd struct {
	Args []string `arg:"" optional:""`
}
type controllerServeKongCmd struct {
	Args []string `arg:"" optional:""`
}
type controllerStateKongCmd struct {
	Validate controllerStateValidateKongCmd `cmd:"" passthrough:"" help:"Validate an adapter state file without modifying it."`
}
type controllerStateValidateKongCmd struct {
	Args []string `arg:"" optional:""`
}

type poolKongCmd struct {
	List      poolListKongCmd      `cmd:"" passthrough:"" help:"List machine inventory."`
	Ready     poolReadyKongCmd     `cmd:"" passthrough:"" help:"List ready-pool leases."`
	Identity  poolIdentityKongCmd  `cmd:"" passthrough:"" help:"Generate a typed ready-pool identity from an existing lease."`
	Register  poolRegisterKongCmd  `cmd:"" passthrough:"" help:"Register a hydrated lease in a ready pool."`
	Borrow    poolBorrowKongCmd    `cmd:"" passthrough:"" help:"Borrow a ready-pool lease."`
	Heartbeat poolHeartbeatKongCmd `cmd:"" passthrough:"" help:"Refresh a ready-pool borrow deadline."`
	Return    poolReturnKongCmd    `cmd:"" passthrough:"" help:"Return or drain a ready-pool lease."`
	Ensure    poolEnsureKongCmd    `cmd:"" passthrough:"" help:"Ensure ready-pool capacity."`
}
type poolListKongCmd struct {
	Args []string `arg:"" optional:""`
}
type poolReadyKongCmd struct {
	Args []string `arg:"" optional:""`
}
type poolIdentityKongCmd struct {
	Args []string `arg:"" optional:""`
}
type poolRegisterKongCmd struct {
	Args []string `arg:"" optional:""`
}
type poolBorrowKongCmd struct {
	Args []string `arg:"" optional:""`
}
type poolHeartbeatKongCmd struct {
	Args []string `arg:"" optional:""`
}
type poolReturnKongCmd struct {
	Args []string `arg:"" optional:""`
}
type poolEnsureKongCmd struct {
	Args []string `arg:"" optional:""`
}

type machineKongCmd struct {
	Cleanup machineCleanupKongCmd `cmd:"" passthrough:"" help:"Alias for cleanup."`
}
type machineCleanupKongCmd struct {
	Args []string `arg:"" optional:""`
}

type pondKongCmd struct {
	Peers      pondPeersKongCmd      `cmd:"" passthrough:"" help:"List peer endpoints for a pond on a delegated provider."`
	Connect    pondConnectKongCmd    `cmd:"" passthrough:"" help:"Open SSH -L forwards to every pond member that declared --expose ports."`
	Disconnect pondDisconnectKongCmd `cmd:"" passthrough:"" help:"Stop daemonized SSH-mesh forwards for a pond."`
	Release    pondReleaseKongCmd    `cmd:"" passthrough:"" help:"Stop every lease in the named pond; retain claims for reusable stopped resources."`
}
type pondPeersKongCmd struct {
	Args []string `arg:"" optional:""`
}
type pondConnectKongCmd struct {
	Args []string `arg:"" optional:""`
}
type pondDisconnectKongCmd struct {
	Args []string `arg:"" optional:""`
}
type pondReleaseKongCmd struct {
	Args []string `arg:"" optional:""`
}

type versionKongCmd struct{}

func (c *initKongCmd) Run(ctx context.Context, app App) error    { return app.initProject(ctx, c.Args) }
func (c *loginKongCmd) Run(ctx context.Context, app App) error   { return app.login(ctx, c.Args) }
func (c *logoutKongCmd) Run(ctx context.Context, app App) error  { return app.logout(ctx, c.Args) }
func (c *whoamiKongCmd) Run(ctx context.Context, app App) error  { return app.whoami(ctx, c.Args) }
func (c *doctorKongCmd) Run(ctx context.Context, app App) error  { return app.doctor(ctx, c.Args) }
func (c *warmupKongCmd) Run(ctx context.Context, app App) error  { return app.warmup(ctx, c.Args) }
func (c *prewarmKongCmd) Run(ctx context.Context, app App) error { return app.prewarm(ctx, c.Args) }
func (c *runKongCmd) Run(ctx context.Context, app App) error     { return app.runCommand(ctx, c.Args) }
func (c *execKongCmd) Run(ctx context.Context, app App) error {
	// exec is a passthrough bridge (Kong forbids flags on it); its
	// client wait is the shared default, which matches the legacy
	// bridge's own subprocess timeout.
	return app.execCommand(ctx, c.Args, execution.DefaultClientTimeout)
}
func (c *serveExecKongCmd) Run(ctx context.Context, app App) error {
	return app.serveExecCommand(ctx, c.Socket)
}
func (c *invokeKongCmd) Run(ctx context.Context, app App) error {
	return app.invokeCommand(ctx, c.Socket, c.Capability, c.Principal, c.IdempotencyKey, c.Arguments, c.ExecutionClass, c.Deadline, c.Timeout)
}
func (c *watchKongCmd) Run(ctx context.Context, app App) error { return app.watch(ctx, c.Args) }
func (c *shardKongCmd) Run(ctx context.Context, app App) error { return app.shard(ctx, c.Args) }
func (c *benchRunKongCmd) Run(ctx context.Context, app App) error {
	return app.benchRun(ctx, c.Args)
}
func (c *benchRecordKongCmd) Run(ctx context.Context, app App) error {
	return app.benchRecord(ctx, c.Args)
}
func (c *benchReportKongCmd) Run(ctx context.Context, app App) error {
	return app.benchReport(ctx, c.Args)
}
func (c *jobListKongCmd) Run(ctx context.Context, app App) error   { return app.jobList(ctx, c.Args) }
func (c *jobRunKongCmd) Run(ctx context.Context, app App) error    { return app.jobRun(ctx, c.Args) }
func (c *syncPlanKongCmd) Run(ctx context.Context, app App) error  { return app.syncPlan(ctx, c.Args) }
func (c *providersKongCmd) Run(ctx context.Context, app App) error { return app.providers(ctx, c.Args) }
func (c *historyKongCmd) Run(ctx context.Context, app App) error   { return app.history(ctx, c.Args) }
func (c *logsKongCmd) Run(ctx context.Context, app App) error      { return app.logs(ctx, c.Args) }
func (c *eventsKongCmd) Run(ctx context.Context, app App) error    { return app.events(ctx, c.Args) }
func (c *attachKongCmd) Run(ctx context.Context, app App) error    { return app.attach(ctx, c.Args) }
func (c *resultsKongCmd) Run(ctx context.Context, app App) error   { return app.results(ctx, c.Args) }
func (c *receiptKongCmd) Run(ctx context.Context, app App) error   { return app.receipt(ctx, c.Args) }
func (c *verifyKongCmd) Run(ctx context.Context, app App) error    { return app.verify(ctx, c.Args) }
func (c *evidenceKongCmd) Run(ctx context.Context, app App) error  { return app.evidence(ctx, c.Args) }
func (c *portsKongCmd) Run(ctx context.Context, app App) error     { return app.ports(ctx, c.Args) }
func (c *cpKongCmd) Run(ctx context.Context, app App) error        { return app.copyCommand(ctx, c.Args) }
func (c *tunnelKongCmd) Run(ctx context.Context, app App) error    { return app.tunnel(ctx, c.Args) }
func (c *statusKongCmd) Run(ctx context.Context, app App) error    { return app.status(ctx, c.Args) }
func (c *heartbeatKongCmd) Run(ctx context.Context, app App) error { return app.heartbeat(ctx, c.Args) }
func (c *claimsListKongCmd) Run(_ context.Context, app App) error {
	return app.claimsList(stripKongCommandPath(c.Args, "claims", "list"))
}
func (c *listKongCmd) Run(ctx context.Context, app App) error     { return app.list(ctx, c.Args) }
func (c *shareKongCmd) Run(ctx context.Context, app App) error    { return app.share(ctx, c.Args) }
func (c *unshareKongCmd) Run(ctx context.Context, app App) error  { return app.unshare(ctx, c.Args) }
func (c *usageKongCmd) Run(ctx context.Context, app App) error    { return app.usage(ctx, c.Args) }
func (c *capacityKongCmd) Run(ctx context.Context, app App) error { return app.capacity(ctx, c.Args) }
func (c *marketplaceStatusKongCmd) Run(ctx context.Context, app App) error {
	return app.marketplaceStatus(ctx, c.Args)
}
func (c *marketplaceQuoteKongCmd) Run(ctx context.Context, app App) error {
	return app.marketplaceQuote(ctx, c.Args)
}
func (c *sshKongCmd) Run(ctx context.Context, app App) error     { return app.ssh(ctx, c.Args) }
func (c *connectKongCmd) Run(ctx context.Context, app App) error { return app.connect(ctx, c.Args) }
func (c *openKongCmd) Run(ctx context.Context, app App) error    { return app.open(ctx, c.Args) }
func (c *vncKongCmd) Run(ctx context.Context, app App) error     { return app.vnc(ctx, c.Args) }
func (c *webvncKongCmd) Run(ctx context.Context, app App) error  { return app.webvnc(ctx, c.Args) }
func (c *codeKongCmd) Run(ctx context.Context, app App) error    { return app.webCode(ctx, c.Args) }
func (c *egressKongCmd) Run(ctx context.Context, app App) error  { return app.egress(ctx, c.Args) }
func (c *screenshotKongCmd) Run(ctx context.Context, app App) error {
	return app.screenshot(ctx, c.Args)
}
func (c *inspectKongCmd) Run(ctx context.Context, app App) error { return app.inspect(ctx, c.Args) }
func (c *stopKongCmd) Run(ctx context.Context, app App) error    { return app.stop(ctx, c.Args) }
func (c *releaseKongCmd) Run(ctx context.Context, app App) error { return app.stop(ctx, c.Args) }
func (c *pauseKongCmd) Run(ctx context.Context, app App) error   { return app.pause(ctx, c.Args) }
func (c *resumeKongCmd) Run(ctx context.Context, app App) error  { return app.resume(ctx, c.Args) }
func (c *cleanupKongCmd) Run(ctx context.Context, app App) error { return app.cleanup(ctx, c.Args) }
func (c *pondConnectKongCmd) Run(ctx context.Context, app App) error {
	return app.pondConnect(ctx, stripKongCommandPath(c.Args, "pond", "connect"))
}
func (c *pondDisconnectKongCmd) Run(ctx context.Context, app App) error {
	return app.pondDisconnect(ctx, stripKongCommandPath(c.Args, "pond", "disconnect"))
}
func (c *pondReleaseKongCmd) Run(ctx context.Context, app App) error {
	return app.pondRelease(ctx, stripKongCommandPath(c.Args, "pond", "release"))
}

func (c *desktopLaunchKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopLaunch(ctx, c.Args)
}
func (c *desktopTerminalKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopTerminal(ctx, c.Args)
}
func (c *desktopRecordKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopRecord(ctx, c.Args)
}
func (c *desktopProofKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopProof(ctx, c.Args)
}
func (c *desktopDoctorKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopDoctor(ctx, c.Args)
}
func (c *desktopClickKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopClick(ctx, c.Args)
}
func (c *desktopPasteKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopPaste(ctx, c.Args)
}
func (c *desktopTypeKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopType(ctx, c.Args)
}
func (c *desktopKeyKongCmd) Run(ctx context.Context, app App) error {
	return app.desktopKey(ctx, c.Args)
}

func (c *mediaPreviewKongCmd) Run(ctx context.Context, app App) error {
	return app.mediaPreview(ctx, c.Args)
}

func (c *artifactsCollectKongCmd) Run(ctx context.Context, app App) error {
	return app.artifactsCollect(ctx, stripKongCommandPath(c.Args, "artifacts", "collect"))
}
func (c *artifactsVideoKongCmd) Run(ctx context.Context, app App) error {
	return app.artifactsVideo(ctx, stripKongCommandPath(c.Args, "artifacts", "video"))
}
func (c *artifactsGifKongCmd) Run(ctx context.Context, app App) error {
	return app.artifactsGif(ctx, stripKongCommandPath(c.Args, "artifacts", "gif"))
}
func (c *artifactsTemplateKongCmd) Run(ctx context.Context, app App) error {
	return app.artifactsTemplate(ctx, stripKongCommandPath(c.Args, "artifacts", "template"))
}
func (c *artifactsPublishKongCmd) Run(ctx context.Context, app App) error {
	return app.artifactsPublish(ctx, stripKongCommandPath(c.Args, "artifacts", "publish"))
}
func (c *artifactsListKongCmd) Run(ctx context.Context, app App) error {
	return app.artifactsList(ctx, stripKongCommandPath(c.Args, "artifacts", "list"))
}
func (c *artifactsPullKongCmd) Run(ctx context.Context, app App) error {
	return app.artifactsPull(ctx, stripKongCommandPath(c.Args, "artifacts", "pull"))
}

func (c *cacheListKongCmd) Run(ctx context.Context, app App) error {
	return app.cacheStats(ctx, c.Args)
}
func (c *cacheStatsKongCmd) Run(ctx context.Context, app App) error {
	return app.cacheStats(ctx, c.Args)
}
func (c *cachePurgeKongCmd) Run(ctx context.Context, app App) error {
	return app.cachePurge(ctx, c.Args)
}
func (c *cacheWarmKongCmd) Run(ctx context.Context, app App) error { return app.cacheWarm(ctx, c.Args) }
func (c *cacheVolumesKongCmd) Run(ctx context.Context, app App) error {
	return app.cacheVolumes(ctx, c.Args)
}

func (c *imageCreateKongCmd) Run(ctx context.Context, app App) error {
	return app.imageCreate(ctx, c.Args)
}
func (c *imagePromoteKongCmd) Run(ctx context.Context, app App) error {
	return app.imagePromote(ctx, c.Args)
}
func (c *imageFSRStatusKongCmd) Run(ctx context.Context, app App) error {
	return app.imageFSRStatus(ctx, c.Args)
}
func (c *imageDeleteKongCmd) Run(ctx context.Context, app App) error {
	return app.imageDelete(ctx, c.Args)
}

func (c *adminLeasesKongCmd) Run(ctx context.Context, app App) error {
	return app.adminLeases(ctx, c.Args)
}
func (c *adminLeaseAuditKongCmd) Run(ctx context.Context, app App) error {
	return app.adminLeaseAudit(ctx, c.Args)
}
func (c *adminProvidersKongCmd) Run(ctx context.Context, app App) error {
	return app.adminProviders(ctx, c.Args)
}
func (c *adminHostsKongCmd) Run(ctx context.Context, app App) error {
	return app.adminHosts(ctx, c.Args)
}
func (c *adminAWSIdentityKongCmd) Run(ctx context.Context, app App) error {
	return app.adminAWSIdentity(ctx, c.Args)
}
func (c *adminAWSPolicyKongCmd) Run(_ context.Context, app App) error {
	return app.adminAWSPolicy(c.Args)
}
func (c *adminMacHostsKongCmd) Run(ctx context.Context, app App) error {
	return app.adminMacHosts(ctx, c.Args)
}
func (c *adminReleaseKongCmd) Run(ctx context.Context, app App) error {
	return app.adminRelease(ctx, c.Args)
}
func (c *adminDeleteKongCmd) Run(ctx context.Context, app App) error {
	return app.adminDelete(ctx, c.Args)
}

func (c *actionsHydrateKongCmd) Run(ctx context.Context, app App) error {
	return app.actionsHydrate(ctx, c.Args)
}
func (c *actionsRegisterKongCmd) Run(ctx context.Context, app App) error {
	return app.actionsRegister(ctx, c.Args)
}
func (c *actionsDispatchKongCmd) Run(ctx context.Context, app App) error {
	return app.actionsDispatch(ctx, c.Args)
}

func (c *capsuleFromActionsKongCmd) Run(ctx context.Context, app App) error {
	return app.capsuleFromActions(ctx, stripKongCommandPath(c.Args, "capsule", "from-actions"))
}
func (c *capsuleReplayKongCmd) Run(ctx context.Context, app App) error {
	return app.capsuleReplay(ctx, stripKongCommandPath(c.Args, "capsule", "replay"))
}
func (c *capsuleInspectKongCmd) Run(ctx context.Context, app App) error {
	return app.capsuleInspect(ctx, stripKongCommandPath(c.Args, "capsule", "inspect"))
}
func (c *capsulePromoteKongCmd) Run(ctx context.Context, app App) error {
	return app.capsulePromote(ctx, stripKongCommandPath(c.Args, "capsule", "promote"))
}

func (c *checkpointCreateKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointCreate(ctx, stripKongCommandPath(c.Args, "checkpoint", "create"))
}
func (c *checkpointAbandonKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointAbandon(ctx, stripKongCommandPath(c.Args, "checkpoint", "abandon"))
}
func (c *checkpointListKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointList(ctx, stripKongCommandPath(c.Args, "checkpoint", "list"))
}
func (c *checkpointInspectKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointInspect(ctx, stripKongCommandPath(c.Args, "checkpoint", "inspect"))
}
func (c *checkpointPolicyKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointPolicy(ctx, stripKongCommandPath(c.Args, "checkpoint", "policy"))
}
func (c *checkpointRestoreKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointRestore(ctx, stripKongCommandPath(c.Args, "checkpoint", "restore"))
}
func (c *checkpointForkKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointFork(ctx, stripKongCommandPath(c.Args, "checkpoint", "fork"))
}
func (c *checkpointDeleteKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointDelete(ctx, stripKongCommandPath(c.Args, "checkpoint", "delete"))
}
func (c *checkpointPruneKongCmd) Run(ctx context.Context, app App) error {
	return app.checkpointPrune(ctx, stripKongCommandPath(c.Args, "checkpoint", "prune"))
}

func (c *configPathKongCmd) Run(ctx context.Context, app App) error {
	path := writableConfigPath()
	if path == "" {
		return exit(2, "user config directory is unavailable")
	}
	fmt.Fprintln(app.Stdout, path)
	return nil
}
func (c *configShowKongCmd) Run(app App) error {
	return app.configShow(c.Args)
}
func (c *configSetBrokerKongCmd) Run(app App) error {
	return app.configSetBroker(c.Args)
}

func (c *controllerServeKongCmd) Run(ctx context.Context, app App) error {
	return app.controllerServe(ctx, stripKongCommandPath(c.Args, "adapter", "serve"))
}
func (c *controllerStateValidateKongCmd) Run(app App) error {
	return app.controllerStateValidate(stripKongCommandPath(c.Args, "adapter", "state", "validate"))
}

func (c *adapterConnectKongCmd) Run(ctx context.Context, app App) error {
	return app.adapterConnect(ctx, stripKongCommandPath(c.Args, "adapter", "connect"))
}

func (c *adapterIngressKongCmd) Run(ctx context.Context, app App) error {
	return app.adapterIngress(ctx, stripKongCommandPath(c.Args, "adapter", "ingress"))
}

func (c *azureLoginKongCmd) Run(ctx context.Context, app App) error {
	return app.azureLogin(ctx, c.Args)
}

func (c *poolListKongCmd) Run(ctx context.Context, app App) error {
	return app.list(ctx, c.Args)
}
func (c *poolReadyKongCmd) Run(ctx context.Context, app App) error {
	return app.readyPoolList(ctx, stripKongCommandPath(c.Args, "pool", "ready"))
}
func (c *poolIdentityKongCmd) Run(ctx context.Context, app App) error {
	return app.readyPoolIdentity(ctx, stripKongCommandPath(c.Args, "pool", "identity"))
}
func (c *poolRegisterKongCmd) Run(ctx context.Context, app App) error {
	return app.readyPoolRegister(ctx, stripKongCommandPath(c.Args, "pool", "register"))
}
func (c *poolBorrowKongCmd) Run(ctx context.Context, app App) error {
	return app.readyPoolBorrow(ctx, stripKongCommandPath(c.Args, "pool", "borrow"))
}
func (c *poolHeartbeatKongCmd) Run(ctx context.Context, app App) error {
	return app.readyPoolHeartbeat(ctx, stripKongCommandPath(c.Args, "pool", "heartbeat"))
}
func (c *poolReturnKongCmd) Run(ctx context.Context, app App) error {
	return app.readyPoolReturn(ctx, stripKongCommandPath(c.Args, "pool", "return"))
}
func (c *poolEnsureKongCmd) Run(ctx context.Context, app App) error {
	return app.readyPoolEnsure(ctx, stripKongCommandPath(c.Args, "pool", "ensure"))
}
func (c *machineCleanupKongCmd) Run(ctx context.Context, app App) error {
	return app.cleanup(ctx, c.Args)
}

func (c *pondPeersKongCmd) Run(ctx context.Context, app App) error {
	return app.pondPeers(ctx, stripKongCommandPath(c.Args, "pond", "peers"))
}

func (c *versionKongCmd) Run(app App) error {
	fmt.Fprintln(app.Stdout, currentVersion())
	return nil
}

func stripKongCommandPath(args []string, path ...string) []string {
	out := append([]string{}, args...)
	for _, part := range path {
		if len(out) == 0 || out[0] != part {
			return out
		}
		out = out[1:]
	}
	return out
}
