package opensandbox

import (
	"flag"
	"io"
	"time"

	core "github.com/openclaw/crabbox/internal/cli"
)

type Config = core.Config
type ProviderSpec = core.ProviderSpec
type Runtime = core.Runtime
type Backend = core.Backend
type DoctorRequest = core.DoctorRequest
type DoctorResult = core.DoctorResult
type WarmupRequest = core.WarmupRequest
type RunRequest = core.RunRequest
type RunResult = core.RunResult
type ListRequest = core.ListRequest
type LeaseView = core.LeaseView
type StatusRequest = core.StatusRequest
type StatusView = core.StatusView
type StopRequest = core.StopRequest
type CleanupRequest = core.CleanupRequest
type Server = core.Server
type Repo = core.Repo
type LeaseClaim = core.LeaseClaim
type ExitError = core.ExitError
type timingReport = core.TimingReport
type timingPhase = core.TimingPhase

const (
	providerName    = "opensandbox"
	leasePrefix     = "osbx_"
	recoveryPrefix  = "osbxr_"
	namePrefix      = "crabbox-"
	defaultAPIURL   = "http://localhost:8080"
	defaultWorkdir  = "/workspace/crabbox"
	defaultImage    = "ubuntu:24.04"
	targetLinux     = core.TargetLinux
	NetworkPublic   = core.NetworkPublic
	statusViewReady = "running"

	openSandboxCleanupTimeout   = 15 * time.Second
	openSandboxReadyTimeout     = 5 * time.Minute
	openSandboxExecGrace        = 30 * time.Second
	openSandboxMinimumTTL       = 10 * time.Minute
	openSandboxStatusPoll       = 2 * time.Second
	openSandboxStatusProbe      = 5 * time.Second
	openSandboxInterruptTimeout = 5 * time.Second
	openSandboxExecTimeoutSecs  = 600
	openSandboxClaimKey         = "crabbox.claim"
	openSandboxNameKey          = "crabbox.name"
)

func exit(code int, format string, args ...any) core.ExitError {
	return core.Exit(code, format, args...)
}

func flagWasSet(fs *flag.FlagSet, name string) bool {
	return core.FlagWasSet(fs, name)
}

func writeTimingJSON(w io.Writer, report timingReport) error {
	return core.WriteTimingJSON(w, report)
}

func newLeaseSlug(leaseID string) string {
	return core.NewLeaseSlug(leaseID)
}

func normalizeLeaseSlug(value string) string {
	return core.NormalizeLeaseSlug(value)
}

func allocateClaimLeaseSlug(leaseID, requested string) (string, error) {
	return core.AllocateClaimLeaseSlug(leaseID, requested)
}

func blank(value, fallback string) string {
	return core.Blank(value, fallback)
}

func claimLeaseForRepoProviderScopePond(leaseID, slug, provider, providerScope, pond, repoRoot string, idleTimeout time.Duration, reclaim bool) error {
	return core.ClaimLeaseForRepoProviderScopePond(leaseID, slug, provider, providerScope, pond, repoRoot, idleTimeout, reclaim)
}

func readLeaseClaim(leaseID string) (core.LeaseClaim, error) {
	return core.ReadLeaseClaim(leaseID)
}

func listOpenSandboxLeaseClaims() ([]core.LeaseClaim, error) {
	return core.ListLeaseClaimsWithPrefix(leasePrefix)
}

func listOpenSandboxCleanupClaims() ([]core.LeaseClaim, error) {
	claims, err := listOpenSandboxLeaseClaims()
	if err != nil {
		return nil, err
	}
	recoveries, err := core.ListLeaseClaimsWithPrefix(recoveryPrefix)
	if err != nil {
		return nil, err
	}
	return append(claims, recoveries...), nil
}

func removeLeaseClaim(leaseID string) {
	core.RemoveLeaseClaim(leaseID)
}

func removeLeaseClaimIfUnchanged(leaseID string, expected LeaseClaim) error {
	return core.RemoveLeaseClaimIfUnchanged(leaseID, expected)
}

func printEnvForwardingSummary(w io.Writer, provider, behavior string, allow []string, env map[string]string) {
	core.PrintEnvForwardingSummary(w, provider, behavior, allow, env)
}

func shellQuote(s string) string {
	return core.ShellQuote(s)
}

func openSandboxCleanupCommand(leaseID string) string {
	return "crabbox stop --provider " + providerName + " " + shellQuote(leaseID)
}

func inventoryDoctorResult(provider string, leases int) DoctorResult {
	return core.InventoryDoctorResult(provider, leases)
}
