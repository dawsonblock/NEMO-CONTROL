// SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Exact-match cache-key derivation.
//!
//! The LLM execution intercept receives the *raw* [`LlmRequest`] (the decoded
//! `AnnotatedLlmRequest` is only handed to *request* intercepts), so the plugin
//! decodes the request itself and keys on the normalized form: provider-shaped
//! differences that mean the same thing collapse to one key. The provider
//! surface is auto-detected from the request shape (hinted by the provider
//! name); there is nothing to configure. Only when detection or decode fails is
//! the raw body fingerprinted (the fallback). Either way RFC
//! 8785 canonicalization removes field-order/whitespace noise, an always-on
//! skip-list drops volatile/identity fields, tool-call IDs are normalized, and
//! only allowlisted headers plus Relay-owned routing partitions fold in.

use std::collections::BTreeSet;

use nemo_relay::api::llm::LlmRequest;
use nemo_relay::api::runtime::current_scope_stack;
use nemo_relay::codec::request::AnnotatedLlmRequest;
use nemo_relay::codec::resolve::{
    ProviderSurface, detect_request_surface_with_hint, request_codec,
};
use serde_json::{Map, Value as Json, json};
use sha2::{Digest, Sha256};

use crate::config::ResponseCacheConfig;
use crate::response_cache::config::{CacheShareScope, ResponseCacheKeyStrategy};
use crate::response_cache::mark::CacheReason;
use crate::response_cache::store::CACHE_SCHEMA_VERSION;

/// Top-level request-body keys that never affect the answer and are always
/// dropped before fingerprinting (IDs, routing, bookkeeping, streaming flag).
pub const DEFAULT_SKIP_KEYS: &[&str] = &["stream", "user", "metadata", "store"];

/// Relay-owned routing backend partition. It is always keyed and never
/// depends on the user-configured header allowlist.
const INTERNAL_DISPATCH_BACKEND_HEADER: &str = "x-nemo-relay-internal-dispatch-backend";

/// Result of deriving a cache key for a request.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum KeyOutcome {
    /// A usable exact-match key fingerprint (`"sha256:…"`).
    Key(String),
    /// The request is intentionally not cacheable; the reason is a short,
    /// stable label suitable for telemetry.
    Bypass(CacheReason),
}

/// Resolve the configured identity partition from the active Relay scope.
pub(crate) fn current_cache_partition(config: &ResponseCacheConfig) -> KeyOutcome {
    let stack = current_scope_stack();
    let stack = match stack.read() {
        Ok(stack) => stack,
        Err(_) => return KeyOutcome::Bypass(CacheReason::IdentityUnavailable),
    };
    // Security-sensitive cache partitions must come from the immutable runtime
    // identity installed by a trusted boundary. Ordinary scope metadata is
    // application-controlled and is intentionally ignored here.
    let identity = stack.runtime_identity();
    let policy_epoch = identity
        .as_ref()
        .map(|identity| Json::from(identity.policy_epoch()));
    let partition = match config.share_scope {
        CacheShareScope::Session => json!({
            "scope": "session",
            "session_id": stack.root_uuid(),
            "policy_epoch": policy_epoch,
        }),
        CacheShareScope::Principal => {
            let Some(identity) = identity.as_ref() else {
                return KeyOutcome::Bypass(CacheReason::IdentityUnavailable);
            };
            json!({
                "scope": "principal",
                "tenant_id": identity.tenant_id(),
                "principal_id": identity.principal_id(),
                "policy_epoch": policy_epoch,
            })
        }
        CacheShareScope::Tenant => {
            let Some(identity) = identity.as_ref() else {
                return KeyOutcome::Bypass(CacheReason::IdentityUnavailable);
            };
            json!({
                "scope": "tenant",
                "tenant_id": identity.tenant_id(),
                "policy_epoch": policy_epoch,
            })
        }
        CacheShareScope::Global => json!({
            "scope": "global",
            "policy_epoch": policy_epoch,
        }),
    };
    match fingerprint(&partition) {
        Some(partition) => KeyOutcome::Key(partition),
        None => KeyOutcome::Bypass(CacheReason::CanonicalizationFailed),
    }
}

/// Derives the cache key for a request, or decides it must bypass the cache.
///
/// The request is decoded to the normalized `AnnotatedLlmRequest` and keyed on
/// that (so provider-shaped differences that mean the same thing collapse to
/// one key); the surface is auto-detected from the request shape. Only when
/// detection or decode fails is the raw request body fingerprinted. Either way the answer-determining fields are
/// kept, noise is dropped, tool-call IDs are normalized, and only allowlisted
/// headers fold in.
#[cfg_attr(not(test), allow(dead_code))]
pub fn build_cache_key(
    provider: &str,
    request: &LlmRequest,
    config: &ResponseCacheConfig,
) -> KeyOutcome {
    match current_cache_partition(config) {
        KeyOutcome::Key(partition) => {
            build_cache_key_with_partition(provider, request, config, &partition)
        }
        bypass => bypass,
    }
}

pub(crate) fn build_cache_key_with_partition(
    provider: &str,
    request: &LlmRequest,
    config: &ResponseCacheConfig,
    identity_partition: &str,
) -> KeyOutcome {
    if let Some(reason) = cache_bypass_reason(request, config) {
        return KeyOutcome::Bypass(reason);
    }

    // Body to fingerprint: the decoded/normalized form when a surface resolves
    // and decode succeeds, otherwise the raw request body.
    let (mut body, effective_codec) = resolved_body(provider, request);
    let chat_token_cap_spelling = openai_chat_token_cap_spelling(provider, request);

    if let Some(object) = body.as_object_mut() {
        // `AnnotatedLlmRequest.extra` is `#[serde(flatten)]`, so provider fields
        // also land at top level — one skip pass covers both.
        for key in DEFAULT_SKIP_KEYS {
            object.remove(*key);
        }
        normalize_tool_call_ids(object);
    }

    if config.key_strategy == ResponseCacheKeyStrategy::Logical
        && let Some(object) = body.as_object_mut()
        && let Some(tools) = object.get("tools").cloned()
    {
        object.insert("tools".to_string(), structural_tool_schema(&tools));
    }

    let header_allowlist = normalized_header_allowlist(&config.header_allowlist);
    let headers = cache_key_headers(&request.headers, &header_allowlist);

    let mut key_doc = json!({
        "v": CACHE_SCHEMA_VERSION,
        "ns": config.namespace,
        "identity_partition": identity_partition,
        "provider": provider,
        "strategy": config.key_strategy,
        "codec": effective_codec,
        "openai_chat_token_cap": chat_token_cap_spelling,
        "body": body,
        "headers": headers,
    });
    // Preserve the original v1 key document for the default empty policy. A
    // non-empty policy intentionally partitions entries from older policy
    // configurations, including requests where the allowlisted header is absent.
    if !header_allowlist.is_empty() {
        key_doc
            .as_object_mut()
            .expect("cache key document is an object")
            .insert("header_allowlist".to_string(), json!(header_allowlist));
    }
    if contains_unrepresentable_int(&key_doc) {
        return KeyOutcome::Bypass(CacheReason::UnrepresentableNumber);
    }

    match fingerprint(&key_doc) {
        Some(key) => KeyOutcome::Key(key),
        None => KeyOutcome::Bypass(CacheReason::CanonicalizationFailed),
    }
}

fn cache_bypass_reason(request: &LlmRequest, config: &ResponseCacheConfig) -> Option<CacheReason> {
    if request.content.is_null() {
        return Some(CacheReason::UnparseableBody);
    }
    if let Some(reason) = request
        .content
        .as_object()
        .and_then(stateful_request_bypass_reason)
    {
        return Some(reason);
    }
    (!config.cache_nondeterministic
        && request_temperature(&request.content).is_none_or(|temperature| temperature > 0.0))
    .then_some(CacheReason::NondeterministicTemperature)
}

fn stateful_request_bypass_reason(object: &Map<String, Json>) -> Option<CacheReason> {
    if object
        .get("store")
        .is_some_and(|value| !matches!(value, Json::Bool(false) | Json::Null))
    {
        return Some(CacheReason::StatefulStore);
    }
    if object.contains_key("previous_response_id") {
        return Some(CacheReason::StatefulPreviousResponseId);
    }
    if object.contains_key("conversation") || object.contains_key("container") {
        return Some(CacheReason::StatefulConversation);
    }
    let responses_surface = object.contains_key("input")
        || object.contains_key("instructions")
        || object.get("prompt").is_some_and(Json::is_object);
    let explicitly_stateless = object
        .get("store")
        .is_some_and(|store| store == &Json::Bool(false));
    (responses_surface && !explicitly_stateless).then_some(CacheReason::StatefulStore)
}

/// Preserves which OpenAI Chat token-cap field the caller sent.
///
/// The Chat codec normalizes both spellings into `GenerationParams.max_tokens`,
/// but providers do not treat them interchangeably. Dual-field requests already
/// use raw-body fallback, so only a single present spelling needs a discriminator.
fn openai_chat_token_cap_spelling(provider: &str, request: &LlmRequest) -> Option<&'static str> {
    if detect_request_surface_with_hint(&request.content, Some(provider))
        != Some(ProviderSurface::OpenAIChat)
    {
        return None;
    }
    let object = request.content.as_object()?;
    match (
        object.contains_key("max_tokens"),
        object.contains_key("max_completion_tokens"),
    ) {
        (true, false) => Some("max_tokens"),
        (false, true) => Some("max_completion_tokens"),
        _ => None,
    }
}

/// True when any integer in `value` lies outside ±2^53: RFC 8785 serializes
/// numbers as f64, so distinct integers beyond that range can canonicalize to
/// the same bytes and must never share a trusted key.
fn contains_unrepresentable_int(value: &Json) -> bool {
    const MAX_EXACT: u64 = 1 << 53;
    match value {
        Json::Number(number) => {
            if let Some(unsigned) = number.as_u64() {
                unsigned > MAX_EXACT
            } else if let Some(signed) = number.as_i64() {
                signed.unsigned_abs() > MAX_EXACT
            } else {
                number
                    .as_f64()
                    .is_some_and(|value| value.abs() > MAX_EXACT as f64)
            }
        }
        Json::Array(items) => items.iter().any(contains_unrepresentable_int),
        Json::Object(map) => map.values().any(contains_unrepresentable_int),
        _ => false,
    }
}

/// Canonicalizes straight into SHA-256; byte-identical output to
/// `sha256_hex(&canonicalize_value(doc)?)` (proven by test).
fn fingerprint<T: serde::Serialize>(doc: &T) -> Option<String> {
    let mut hasher = Sha256::new();
    serde_json_canonicalizer::to_writer(doc, &mut HashWriter(&mut hasher)).ok()?;
    let digest = hasher.finalize();
    let mut out = String::with_capacity(7 + 64);
    out.push_str("sha256:");
    for byte in digest {
        out.push(char::from(HEX[(byte >> 4) as usize]));
        out.push(char::from(HEX[(byte & 0x0f) as usize]));
    }
    Some(out)
}

const HEX: [u8; 16] = *b"0123456789abcdef";

/// Feeds canonical bytes straight into the hasher (`digest` 0.11 no longer
/// implements `io::Write` for hashers).
struct HashWriter<'a>(&'a mut Sha256);

impl std::io::Write for HashWriter<'_> {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.0.update(buf);
        Ok(buf.len())
    }

    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

/// Builds a tool-result key from its name, version, canonicalized arguments,
/// and the effective cache policies.
#[cfg_attr(not(test), allow(dead_code))]
pub fn build_tool_cache_key(
    namespace: &str,
    tool_name: &str,
    tool_version: Option<&str>,
    args: &Json,
    arg_skip: &[String],
    cache_errors: bool,
) -> KeyOutcome {
    let partition = match current_session_partition() {
        Some(partition) => partition,
        None => return KeyOutcome::Bypass(CacheReason::IdentityUnavailable),
    };
    build_tool_cache_key_with_partition(
        namespace,
        tool_name,
        tool_version,
        args,
        arg_skip,
        cache_errors,
        &partition,
    )
}

fn current_session_partition() -> Option<String> {
    let stack = current_scope_stack();
    let stack = stack.read().ok()?;
    fingerprint(&json!({
        "scope": "session",
        "session_id": stack.root_uuid(),
        "policy_epoch": null,
    }))
}

pub(crate) fn build_tool_cache_key_with_partition(
    namespace: &str,
    tool_name: &str,
    tool_version: Option<&str>,
    args: &Json,
    arg_skip: &[String],
    cache_errors: bool,
    identity_partition: &str,
) -> KeyOutcome {
    let arg_skip = normalized_arg_skip(arg_skip);
    let mut args = args.clone();
    if !arg_skip.is_empty()
        && let Some(object) = args.as_object_mut()
    {
        for key in &arg_skip {
            object.remove(key);
        }
    }

    if contains_unrepresentable_int(&args) {
        return KeyOutcome::Bypass(CacheReason::UnrepresentableNumber);
    }

    let key_doc = json!({
        "v": CACHE_SCHEMA_VERSION,
        "surface": "tool_result",
        "ns": namespace,
        "identity_partition": identity_partition,
        "tool": tool_name,
        "tool_version": tool_version,
        "arg_skip": arg_skip,
        "cache_errors": cache_errors,
        "args": args,
    });

    match fingerprint(&key_doc) {
        Some(key) => KeyOutcome::Key(key),
        None => KeyOutcome::Bypass(CacheReason::CanonicalizationFailed),
    }
}

/// The body to fingerprint plus the codec that actually produced it.
///
/// The surface is auto-detected from the request shape, hinted by the provider
/// name — the same detector the streaming path uses. `(raw clone, None)` when
/// nothing detects or decodes.
fn resolved_body(provider: &str, request: &LlmRequest) -> (Json, Option<&'static str>) {
    let surface = detect_request_surface_with_hint(&request.content, Some(provider));
    let decoded = surface.and_then(|surface| {
        let annotated = decode_surface(surface, request)?;
        let body = serde_json::to_value(&annotated).ok()?;
        Some((body, surface.codec_name()))
    });
    match decoded {
        Some((body, name)) => (body, Some(name)),
        None => (request.content.clone(), None),
    }
}

/// Decodes the raw request via the surface's codec. Returns `None` on a decode
/// failure (the caller falls back to raw-body fingerprinting).
fn decode_surface(surface: ProviderSurface, request: &LlmRequest) -> Option<AnnotatedLlmRequest> {
    // Known-lossy shapes stay raw-keyed: a fallback only ever costs a miss.
    if lossy_request_shape(surface, &request.content) {
        return None;
    }
    let annotated = request_codec(surface).decode(request).ok()?;
    // The chat/anthropic codecs parse `messages` with `unwrap_or_default()`, so a
    // message carrying content the normalized type cannot represent (Anthropic
    // `tool_use`/`tool_result`/`image`, OpenAI `input_audio`/`file`) collapses the
    // WHOLE array to empty — silently dropping answer-affecting content from the
    // key, so two such requests would collide. If the raw request carried messages
    // but the decode produced none, reject the decode so the caller falls back to
    // raw-body fingerprinting, which keeps distinct requests distinct (lower
    // normalization, but never a wrong reuse).
    if annotated.messages.is_empty() && raw_has_messages(request) {
        return None;
    }
    // The closed tool types drop unmodeled fields (`function.strict`,
    // server-tool settings); trust the decode only if it round-trips.
    if let Some(raw_tools) = request.content.get("tools") {
        let decoded_tools = serde_json::to_value(&annotated.tools).ok()?;
        if decoded_tools != *raw_tools {
            return None;
        }
    }
    // Same round-trip rule for `tool_choice`.
    if let Some(raw_tool_choice) = request.content.get("tool_choice") {
        let decoded_tool_choice = serde_json::to_value(&annotated.tool_choice).ok()?;
        if decoded_tool_choice != *raw_tool_choice {
            return None;
        }
    }
    // Closed message types drop `function_call`/`refusal`; legitimately
    // restructured shapes (synthesized system) just key raw — a dedup loss only.
    if let Some(raw_conversation) = request
        .content
        .get("messages")
        .or_else(|| request.content.get("input"))
    {
        let decoded_messages = serde_json::to_value(&annotated.messages).ok()?;
        if decoded_messages != *raw_conversation {
            return None;
        }
    }
    Some(annotated)
}

/// Raw shapes the built-in codecs are known to decode lossily — answer-affecting
/// fields the normalized types drop or merge.
fn lossy_request_shape(surface: ProviderSurface, content: &Json) -> bool {
    let Some(object) = content.as_object() else {
        return false;
    };
    // Shapes the decode silently drops: a raw `params` object overwrites the
    // typed field via the flattened extra; wrong-typed scalars vanish entirely.
    if object.contains_key("params") {
        return true;
    }
    let non_number = |key: &str| {
        object
            .get(key)
            .is_some_and(|value| value.as_f64().is_none())
    };
    let non_u64 = |key: &str| {
        object
            .get(key)
            .is_some_and(|value| value.as_u64().is_none())
    };
    let non_bool = |key: &str| {
        object
            .get(key)
            .is_some_and(|value| value.as_bool().is_none())
    };
    if non_number("temperature")
        || non_number("top_p")
        || non_u64("max_tokens")
        || non_u64("max_completion_tokens")
        || non_u64("max_output_tokens")
        || non_u64("top_logprobs")
        || non_bool("parallel_tool_calls")
    {
        return true;
    }
    match surface {
        // `stop` is modeled only as an array of strings — any other present
        // form (a bare string, a mixed array, an object) is dropped on decode.
        // And when both token caps are present the decode keeps one.
        ProviderSurface::OpenAIChat => {
            object
                .get("stop")
                .is_some_and(|stop| !is_string_array(stop))
                || (object.contains_key("max_tokens")
                    && object.contains_key("max_completion_tokens"))
        }
        // Same for `stop_sequences`; and system content blocks are flattened
        // to their text on decode, so any non-text block, non-string text, or
        // block metadata beyond the provider cache hint is lost.
        ProviderSurface::AnthropicMessages => {
            object
                .get("stop_sequences")
                .is_some_and(|stop| !is_string_array(stop))
                || object
                    .get("system")
                    .and_then(Json::as_array)
                    .is_some_and(|blocks| blocks.iter().any(lossy_system_block))
        }
        ProviderSurface::OpenAIResponses => false,
        // OCI GenAI requests carry an envelope (`compartmentId`, `servingMode`)
        // whose unmodeled fields the decode does not preserve in `extra`, and
        // the generic scalar checks above target OpenAI-shaped keys rather
        // than OCI camelCase. Keep OCI raw-keyed — a fallback only ever costs
        // a miss.
        ProviderSurface::OCIGenAI => true,
        ProviderSurface::GeminiGenerateContent => {
            object
                .get("generationConfig")
                .is_some_and(|generation_config| {
                    let Some(generation_config) = generation_config.as_object() else {
                        return true;
                    };
                    generation_config.keys().any(|key| {
                        !matches!(
                            key.as_str(),
                            "temperature" | "topP" | "maxOutputTokens" | "stopSequences"
                        )
                    })
                })
                || object
                    .get("systemInstruction")
                    .is_some_and(lossy_gemini_system_instruction)
                || object
                    .get("contents")
                    .and_then(Json::as_array)
                    .is_some_and(|items| items.iter().any(lossy_gemini_content_item))
        }
    }
}

/// Whether `value` is an array whose items are all strings — the only `stop` /
/// `stop_sequences` form the normalized types keep faithfully.
fn is_string_array(value: &Json) -> bool {
    value
        .as_array()
        .is_some_and(|items| items.iter().all(Json::is_string))
}

/// Whether an Anthropic `system` content block carries anything the decode's
/// text-flattening would lose.
fn lossy_system_block(block: &Json) -> bool {
    let Some(fields) = block.as_object() else {
        return true;
    };
    fields.get("type").and_then(Json::as_str) != Some("text")
        || !fields.get("text").is_some_and(Json::is_string)
        || fields
            .keys()
            .any(|key| !matches!(key.as_str(), "type" | "text" | "cache_control"))
}

/// Whether a Gemini `systemInstruction` would lose detail in the normalized
/// request key. The Gemini codec flattens it to a single system text string, so
/// only one non-empty plain text part without sibling fields is lossless.
fn lossy_gemini_system_instruction(value: &Json) -> bool {
    let Some(object) = value.as_object() else {
        return true;
    };
    if object.keys().any(|key| key != "parts") {
        return true;
    }
    let Some(parts) = object.get("parts").and_then(Json::as_array) else {
        return true;
    };
    let [part] = parts.as_slice() else {
        return true;
    };
    let Some(part_object) = part.as_object() else {
        return true;
    };
    if part_object.len() != 1 {
        return true;
    }
    part_object
        .get("text")
        .and_then(Json::as_str)
        .is_none_or(str::is_empty)
}

fn lossy_gemini_content_item(item: &Json) -> bool {
    let Some(object) = item.as_object() else {
        return true;
    };
    if object
        .keys()
        .any(|key| !matches!(key.as_str(), "role" | "parts"))
    {
        return true;
    }
    let Some(parts) = object.get("parts").and_then(Json::as_array) else {
        return true;
    };

    let mut plain_text_parts = 0usize;
    for part in parts {
        if lossy_gemini_part(part, &mut plain_text_parts) {
            return true;
        }
    }
    plain_text_parts > 1
}

fn lossy_gemini_part(part: &Json, plain_text_parts: &mut usize) -> bool {
    let Some(object) = part.as_object() else {
        return true;
    };
    if object.get("thought").and_then(Json::as_bool) == Some(true) {
        return true;
    }
    let data_keys = object
        .keys()
        .filter(|key| is_gemini_part_data_key(key))
        .collect::<Vec<_>>();
    if data_keys.len() > 1 {
        return true;
    }
    let Some(data_key) = data_keys.first().map(|key| key.as_str()) else {
        return true;
    };
    match data_key {
        "text" => lossy_gemini_text_part(object, plain_text_parts),
        "functionCall" => lossy_gemini_function_call_part(object),
        "functionResponse" => lossy_gemini_function_response_part(object),
        _ => false,
    }
}

fn lossy_gemini_text_part(
    object: &serde_json::Map<String, Json>,
    plain_text_parts: &mut usize,
) -> bool {
    if !object.get("text").is_some_and(Json::is_string) {
        return true;
    }
    if object.len() == 1 {
        *plain_text_parts += 1;
    }
    false
}

fn lossy_gemini_function_call_part(object: &serde_json::Map<String, Json>) -> bool {
    object.keys().any(|key| key != "functionCall")
        || match object.get("functionCall").and_then(Json::as_object) {
            Some(call) => {
                call.keys()
                    .any(|key| !matches!(key.as_str(), "name" | "id" | "args"))
                    || call.get("args").is_some_and(|args| !args.is_object())
            }
            None => true,
        }
}

fn lossy_gemini_function_response_part(object: &serde_json::Map<String, Json>) -> bool {
    object.keys().any(|key| key != "functionResponse")
        || match object.get("functionResponse").and_then(Json::as_object) {
            Some(response) => {
                response
                    .keys()
                    .any(|key| !matches!(key.as_str(), "id" | "name" | "response" | "parts"))
                    || match (
                        response.get("id").and_then(Json::as_str),
                        response.get("name").and_then(Json::as_str),
                    ) {
                        (Some(id), Some(name)) => id != name,
                        _ => false,
                    }
            }
            None => true,
        }
}

fn is_gemini_part_data_key(key: &str) -> bool {
    matches!(
        key,
        "text"
            | "inlineData"
            | "fileData"
            | "functionCall"
            | "functionResponse"
            | "executableCode"
            | "codeExecutionResult"
    )
}

/// Whether the raw request body carries a non-empty `messages` (chat) or `input`
/// (Responses) array — the content a decode is expected to preserve.
fn raw_has_messages(request: &LlmRequest) -> bool {
    let non_empty_array = |key: &str| {
        request
            .content
            .get(key)
            .and_then(Json::as_array)
            .is_some_and(|items| !items.is_empty())
    };
    non_empty_array("messages") || non_empty_array("input")
}

fn request_temperature(content: &Json) -> Option<f64> {
    content
        .get("temperature")
        .and_then(Json::as_f64)
        .or_else(|| {
            content
                .pointer("/params/temperature")
                .and_then(Json::as_f64)
        })
}

/// Keeps only allowlisted headers, matched case-insensitively and emitted with
/// lowercased names so header-case noise does not change the key.
fn allowlisted_headers(headers: &Map<String, Json>, allowlist: &[String]) -> Map<String, Json> {
    let mut kept = Map::new();
    for name in allowlist {
        for (header_name, value) in headers {
            if header_name.eq_ignore_ascii_case(name) {
                kept.insert(header_name.to_ascii_lowercase(), value.clone());
            }
        }
    }
    kept
}

/// Normalizes case-insensitive header policy names before keying them.
fn normalized_header_allowlist(allowlist: &[String]) -> Vec<String> {
    allowlist
        .iter()
        .map(|name| name.to_ascii_lowercase())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect()
}

/// Normalizes the case-sensitive tool argument keys dropped before keying.
fn normalized_arg_skip(arg_skip: &[String]) -> Vec<String> {
    arg_skip
        .iter()
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect()
}

/// Builds the key's header partition from configured headers plus the
/// Relay-owned routing backend ID.
fn cache_key_headers(headers: &Map<String, Json>, allowlist: &[String]) -> Map<String, Json> {
    let mut kept = allowlisted_headers(headers, allowlist);
    for (header_name, value) in headers {
        if header_name.eq_ignore_ascii_case(INTERNAL_DISPATCH_BACKEND_HEADER) {
            kept.insert(INTERNAL_DISPATCH_BACKEND_HEADER.to_string(), value.clone());
        }
    }
    kept
}

/// Renumbers tool-call IDs consistently so random IDs do not cause misses.
///
/// Tool calls and their results carry random IDs; what matters is which result
/// pairs with which call, not the literal value. We map IDs to `tcid_0`,
/// `tcid_1`, … in first-seen order across `messages`, rewriting both
/// `tool_calls[].id` and `tool_call_id`. Shapes without these keys are left
/// untouched (this only affects hit-rate, never correctness).
fn normalize_tool_call_ids(body: &mut Map<String, Json>) {
    let Some(messages) = body.get_mut("messages").and_then(Json::as_array_mut) else {
        return;
    };

    let mut mapping: Map<String, Json> = Map::new();
    for message in messages.iter_mut() {
        let Some(object) = message.as_object_mut() else {
            continue;
        };
        if let Some(tool_calls) = object.get_mut("tool_calls").and_then(Json::as_array_mut) {
            for call in tool_calls.iter_mut() {
                if let Some(id_value) = call.get_mut("id") {
                    rewrite_id(id_value, &mut mapping);
                }
            }
        }
        if let Some(id_value) = object.get_mut("tool_call_id") {
            rewrite_id(id_value, &mut mapping);
        }
    }
}

/// Rewrites a single JSON string id in place to its stable, first-seen mapping.
fn rewrite_id(id_value: &mut Json, mapping: &mut Map<String, Json>) {
    let Some(original) = id_value.as_str().map(str::to_string) else {
        return;
    };
    let stable = match mapping.get(&original) {
        Some(Json::String(existing)) => existing.clone(),
        _ => {
            let stable = format!("tcid_{}", mapping.len());
            mapping.insert(original, Json::String(stable.clone()));
            stable
        }
    };
    *id_value = Json::String(stable);
}

/// Fingerprint of the tool set for the `logical` strategy: each tool keeps its
/// full definition minus string-valued `description` keys (stripped
/// recursively), and the array is sorted so tool order does not key.
fn structural_tool_schema(tools: &Json) -> Json {
    let Some(array) = tools.as_array() else {
        return tools.clone();
    };
    let mut entries: Vec<Json> = array
        .iter()
        .map(|tool| {
            let mut entry = tool.clone();
            strip_descriptions(&mut entry);
            entry
        })
        .collect();
    entries
        .sort_by_cached_key(|entry| serde_json_canonicalizer::to_string(entry).unwrap_or_default());
    Json::Array(entries)
}

/// Removes every string-valued `description` key, at any depth. A non-string
/// value under that key (e.g. a schema property named `description`) is
/// interface, not prose, and stays.
fn strip_descriptions(value: &mut Json) {
    match value {
        Json::Object(object) => {
            if object.get("description").is_some_and(Json::is_string) {
                object.remove("description");
            }
            for nested in object.values_mut() {
                strip_descriptions(nested);
            }
        }
        Json::Array(items) => {
            for item in items {
                strip_descriptions(item);
            }
        }
        _ => {}
    }
}

#[cfg(test)]
#[path = "../../tests/unit/response_cache/key_tests.rs"]
mod tests;
