// SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Contract-driven capability execution for the experimental hardening ABI.
//!
//! This module is deliberately small. Relay owns classification and routing;
//! Correct-Once, Effect Fabric, workers, and DLP implementations remain
//! external providers of the contracts defined by the hardening crates.

use std::collections::HashMap;
use std::time::Duration;

use nemo_relay_authority::unstable::{
    AuthorityDecision, AuthorityProvider, GrantVerifier, VerifiedGrant, request_from_identity,
};
use nemo_relay_executor::unstable::{
    CapabilityIdentity, ExecutionBackend, ExecutionClass, ExecutionIdentity, ExecutionRequest,
    ExecutionResult, ReconciliationProvider, ReconciliationRequest, ReconciliationResult,
    RuntimeIdentity,
};
use nemo_relay_ledger::unstable::{
    ActionEvidenceBinding, ActionLease, ActionPreparation, ActionRecord, ActionStore,
    DurableEffectStore, EffectFinalizeResult, EffectStore, ExecutionState, LeaseAcquireResult,
    LeaseConfiguration, LeaseReleaseResult, LeaseRenewResult, LeaseStatus,
    PreDispatchFailureEvidence, PrepareActionResult, ReceiptConflict, ReceiptRecord,
    TerminalEvidence, is_valid_generic_transition, is_valid_leased_transition,
};
use serde_json::Value as Json;
use sha2::{Digest, Sha256};
use uuid::Uuid;

/// Typed failures produced before a backend crosses an execution boundary.
#[derive(Debug, thiserror::Error)]
pub enum KernelError {
    /// The requested capability is absent from the kernel registry.
    #[error("capability is not registered: {0}")]
    CapabilityUnknown(String),
    /// The registered capability is not currently admitted.
    #[error("capability is not currently admitted: {0}")]
    CapabilityNotAdmitted(String),
    /// A capability identifier was registered more than once.
    #[error("capability is already registered: {0}")]
    CapabilityAlreadyRegistered(String),
    /// A production kernel was requested outside the production environment.
    #[error("production composition requires a production runtime environment")]
    ProductionEnvironmentMismatch,
    /// A development kernel was requested with a production runtime identity.
    ///
    /// The profile decides which admission checks apply, so a caller must not
    /// be able to hold a production identity while composing through the
    /// development constructor and skipping them.
    #[error("development composition cannot use a production runtime identity")]
    DevelopmentEnvironmentMismatch,
    /// A production kernel was requested without any consequential capability.
    #[error(
        "production composition requires at least one admitted MUTATION or CRITICAL capability"
    )]
    ProductionRequiresConsequentialCapability,
    /// The durable effect store did not attest production readiness.
    #[error("durable effect store is not production-ready: {0}")]
    EffectStoreNotProductionReady(String),
    /// Registry sealing failed because a registration is not internally consistent.
    #[error("capability registration digest failed: {0}")]
    RegistrationDigestFailed(String),
    /// The trusted runtime host supplied an ambiguous durable identity.
    #[error("runtime identity is invalid: {0}")]
    RuntimeIdentityInvalid(String),
    /// Arguments did not satisfy the immutable capability schema.
    #[error("capability arguments failed schema validation: {0}")]
    SchemaValidationFailed(String),
    /// Argument canonicalization failed before an execution identity was bound.
    #[error("could not canonicalize invocation arguments: {0}")]
    ArgumentCanonicalization(String),
    /// The authority provider could not evaluate the request.
    #[error("authority provider unavailable: {0}")]
    AuthorityUnavailable(String),
    /// The authority artifact could not be cryptographically verified.
    #[error("authority grant could not be verified: {0}")]
    GrantVerificationFailed(String),
    /// A cryptographically valid authority artifact did not bind to the action.
    #[error("authority grant does not bind to the exact execution request")]
    GrantBindingFailure,
    /// A fresh approval is required before the effect can proceed.
    #[error("authority requires approval")]
    ApprovalRequired,
    /// An action store failed while claiming or transitioning an effect.
    #[error("action store failed: {0}")]
    ActionStore(String),
    /// Consequential work requires a stable caller retry identity.
    #[error("consequential capability invocations require request_id")]
    RequestIdRequired,
    /// A claimed action remains safely resumable before external dispatch.
    #[error("action remains pending before dispatch: {action:?}: {cause:?}")]
    ActionPending {
        /// Durable action identity and recovery guidance.
        action: Box<ActionStatus>,
        /// Authority or persistence failure that left the action pending.
        cause: ActionPendingCause,
    },
    /// Authority rejected an action before it crossed an external boundary.
    #[error("authority rejected action: {action:?}: {cause:?}")]
    ActionRejected {
        /// Durable action identity, now terminally cancelled.
        action: Box<ActionStatus>,
        /// Machine-readable rejection reason.
        cause: ActionRejectionCause,
    },
    /// Authority requested a normalized replacement invocation.
    #[error("authority requires a new normalized invocation: {action:?}")]
    ActionModificationRequired {
        /// Durable original action, now terminally cancelled.
        action: Box<ActionStatus>,
        /// Authority-owned constraints for the replacement invocation.
        modification: Json,
    },
    /// The idempotency key is bound to a different logical action.
    #[error("idempotency key conflicts with an existing action")]
    IdempotencyConflict,
    /// A generated action identifier collided with an existing durable action.
    #[error("action identifier conflicts with an existing action: {0:?}")]
    ActionIdConflict(Box<ActionStatus>),
    /// An effect backend completed without the authoritative receipt required for an effect.
    #[error("consequential execution completed without an authoritative receipt")]
    ReceiptMissing,
    /// An effect receipt did not bind to the exact action executed by the kernel.
    #[error("effect receipt does not bind to the exact execution request")]
    ReceiptBindingFailure,
    /// The aggregate effect store rejected an evidence operation.
    #[error("effect store failed: {0}")]
    EffectStore(String),
    /// Contradictory terminal evidence requires operator evidence repair.
    #[error("terminal evidence is contradictory: {action:?}: {conflicts:?}")]
    EvidenceIntegrityConflict {
        /// Durable action status with repair-only guidance.
        action: Box<ActionStatus>,
        /// Persisted conflicting evidence identities.
        conflicts: Vec<ReceiptConflict>,
    },
    /// The store rejected the kernel's bounded lease configuration request.
    #[error("store rejected configured lease duration: {0}")]
    LeaseConfiguration(String),
    /// An effect definitely failed after the kernel claimed its logical action.
    #[error("effect failed after durable action claim: {action:?}: {cause}")]
    EffectFailed {
        /// Durable action identity and terminal state.
        action: Box<ActionStatus>,
        /// Typed backend diagnostic.
        cause: String,
    },
    /// A consequential effect may have crossed the external boundary.
    #[error("effect outcome is unknown and requires reconciliation: {action:?}: {cause}")]
    EffectUnknown {
        /// Durable action identity and reconciliation guidance.
        action: Box<ActionStatus>,
        /// Backend, transport, receipt, or reconciliation failure.
        cause: String,
    },
    /// Durable state could not be advanced after evidence was persisted.
    #[error(
        "durable effect state requires recovery toward {intended_state:?}: {action:?}: {cause}"
    )]
    StateRecoveryRequired {
        /// Durable action identity and recovery guidance.
        action: Box<ActionStatus>,
        /// State that could not be durably recorded.
        intended_state: ExecutionState,
        /// Underlying persistence failure.
        cause: String,
    },
    /// A terminal action claimed `COMMITTED` without its required receipt evidence.
    #[error("durable action evidence is internally inconsistent: {action:?}: {cause}")]
    EvidenceIntegrityFailure {
        /// Durable action identity requiring operator repair.
        action: Box<ActionStatus>,
        /// Missing or mismatched evidence detail.
        cause: String,
    },
    /// The kernel attempted to skip a lifecycle boundary.
    #[error("invalid effect state transition: {expected:?} -> {next:?}")]
    InvalidStateTransition {
        /// State the kernel expected to be current.
        expected: ExecutionState,
        /// State the kernel attempted to write.
        next: ExecutionState,
    },
    /// The requested action is not currently eligible for reconciliation.
    #[error("action is not in UNKNOWN state: {0}")]
    ActionNotUnknown(String),
    /// Reconciliation returned an invalid nonterminal effect state.
    #[error("reconciliation returned invalid state: {0:?}")]
    ReconciliationInvalidState(ExecutionState),
    /// The fast-path backend failed before an external effect boundary.
    #[error("function hooks backend failed: {0}")]
    FunctionBackend(String),
    /// The effect backend returned a structured dispatch outcome.
    #[error("effect backend failed: {0}")]
    EffectBackend(#[from] nemo_relay_executor::unstable::EffectExecutionError),
}

/// Structured cause for a pre-dispatch action that may safely be resumed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ActionPendingCause {
    /// Correct-Once could not be reached or complete evaluation.
    AuthorityUnavailable(String),
    /// Correct-Once intentionally deferred the decision.
    AuthorityDeferred,
    /// Another worker still holds the action lease.
    LeaseHeld,
    /// A local state write failed before dispatch.
    StatePersistenceFailure(String),
}

/// Structured terminal reason for an action cancelled before dispatch.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ActionRejectionCause {
    /// Correct-Once explicitly denied the exact action.
    AuthorityDenied,
    /// A grant could not be verified.
    GrantVerificationFailed(String),
    /// A verified grant did not bind the exact action.
    GrantBindingFailure,
}

/// The only invocation data accepted from an agent harness.
///
/// The harness chooses an admitted capability and supplies its arguments. It
/// cannot set an execution class, runtime identity, route, admission, policy,
/// digest, grant, or backend.
#[derive(Debug, Clone, PartialEq)]
pub struct InvocationRequest {
    /// Identifier of the registered capability to invoke.
    pub capability_id: String,
    /// Untrusted arguments that the kernel validates against the descriptor.
    pub args: Json,
    /// Optional trace correlation identifier with no authority semantics.
    pub trace_id: Option<String>,
    /// Optional caller retry identity. It is only an idempotency key; all
    /// security-sensitive fields remain kernel-derived.
    pub request_id: Option<String>,
}

/// Public recovery handle for one consequential logical action.
///
/// This is deliberately returned instead of an ephemeral attempt identifier so
/// a harness can retry, observe, or reconcile the durable action actually
/// claimed by the action store.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ActionStatus {
    /// Canonical durable action identifier.
    pub action_id: String,
    /// Kernel-scoped idempotency identity.
    pub idempotency_key: String,
    /// Last observed durable lifecycle state. This is never an unpersisted
    /// intended transition.
    pub state: ExecutionState,
    /// Lifecycle state the kernel attempted but could not confirm persisted.
    pub intended_state: Option<ExecutionState>,
    /// The safe protocol action for this durable state.
    pub next_action: ActionNextStep,
    /// Whether the kernel can safely resume this action without dispatching.
    pub safe_to_retry: bool,
    /// Whether provider evidence must be reconciled before another dispatch.
    pub reconciliation_required: bool,
    /// Persisted receipt when the action is already committed.
    pub receipt: Option<ReceiptRecord>,
    /// Durable terminal evidence for committed or failed actions.
    pub terminal_evidence: Option<TerminalEvidence>,
    /// Whether `state` was freshly loaded from durable action storage.
    pub durable_state_confirmed: bool,
}

/// Evidence-aware outcome of a recovery attempt.
///
/// Recovery never treats lease expiry as proof that no external effect ran.
/// The terminal variants require a fully bound immutable receipt; the unknown
/// variant requires provider reconciliation before a retry can be considered.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RecoveryDecision {
    /// Evidence proves the action committed and the durable state was repaired.
    RecoverCommitted(ActionStatus),
    /// Evidence proves the action failed and the durable state was repaired.
    RecoverFailed(ActionStatus),
    /// The action was deliberately cancelled before external dispatch.
    RecoverCancelled(ActionStatus),
    /// A valid owner still holds the action lease.
    HeldByOther(ActionStatus),
    /// Lease expiry left no terminal evidence; external outcome remains unknown.
    RecoverUnknown(ActionStatus),
    /// No dispatch occurred and the action may safely resume preparation.
    RecoverRetry(ActionStatus),
    /// State and terminal evidence contradict each other and need intervention.
    ContradictoryEvidence {
        /// Last known durable action identity and state.
        action: ActionStatus,
        /// Persisted immutable conflicts that block automatic recovery.
        conflicts: Vec<ReceiptConflict>,
        /// Integrity diagnostic; callers must not retry based on this alone.
        cause: String,
    },
}

/// State-specific protocol guidance returned to a harness.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ActionNextStep {
    /// Re-submit the same bound invocation to retry authority evaluation.
    RetryAuthority,
    /// Re-submit the same bound invocation to resume work before dispatch.
    ResumePreDispatch,
    /// Supply an approval reference through the durable approval resume API.
    AwaitApproval,
    /// A live dispatch or reconciliation lease is still held by another worker.
    WaitForOwner,
    /// Invoke recovery after a dispatch lease expires.
    Recover,
    /// Invoke provider reconciliation.
    Reconcile,
    /// Return the verified committed receipt without redispatching.
    ReturnReceipt,
    /// The action is terminal and cannot be retried under its identity.
    Terminal,
    /// The durable record and its evidence need repair rather than dispatch.
    RepairEvidence,
}

/// Immutable data registered for a capability before any harness invocation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CapabilityDefinition {
    /// Stable capability identifier.
    pub capability_id: String,
    /// Monotonic generation of this registration.
    pub capability_generation: u64,
    /// Digest of the immutable registration descriptor.
    pub registration_digest: String,
    /// Kernel-owned execution classification.
    pub execution_class: ExecutionClass,
    /// Registered operation name.
    pub operation: String,
    /// Digest of the immutable registered route.
    pub route_digest: String,
    /// Current admission identifier for this capability registration.
    pub admission_id: String,
    /// Policy version associated with the current admission.
    pub policy_version: String,
    /// Policy epoch associated with the current admission.
    pub policy_epoch: String,
    /// Whether the capability is currently admitted for execution.
    pub admitted: bool,
}

impl CapabilityDefinition {
    fn identity(&self) -> CapabilityIdentity {
        CapabilityIdentity {
            capability_id: self.capability_id.clone(),
            capability_generation: self.capability_generation,
            registration_digest: self.registration_digest.clone(),
            execution_class: self.execution_class,
            operation: self.operation.clone(),
            route_digest: self.route_digest.clone(),
        }
    }
}

/// Restricted-schema validation supplied at capability registration time.
///
/// A production registry can delegate this to the same strict schema engine
/// that admitted the capability. The kernel records only the validator result;
/// it does not own a second schema language.
pub trait SchemaValidator: Send + Sync {
    /// Validate untrusted invocation arguments.
    fn validate(&self, args: &Json) -> Result<(), String>;
}

impl<F> SchemaValidator for F
where
    F: Fn(&Json) -> Result<(), String> + Send + Sync,
{
    fn validate(&self, args: &Json) -> Result<(), String> {
        self(args)
    }
}

struct RegisteredCapability {
    definition: CapabilityDefinition,
    validator: Box<dyn SchemaValidator>,
}

/// Kernel-owned registry of immutable capability definitions.
///
/// Definitions are moved into the registry at startup. A harness can resolve a
/// capability by identifier but cannot supply or alter its security semantics.
#[derive(Default)]
pub struct CapabilityRegistry {
    capabilities: HashMap<String, RegisteredCapability>,
}

impl CapabilityRegistry {
    /// Create an empty registry.
    pub fn new() -> Self {
        Self::default()
    }

    /// Register one immutable capability and its schema validator.
    pub fn register<V>(
        &mut self,
        definition: CapabilityDefinition,
        validator: V,
    ) -> Result<(), KernelError>
    where
        V: SchemaValidator + 'static,
    {
        let capability_id = definition.capability_id.clone();
        if self.capabilities.contains_key(&capability_id) {
            return Err(KernelError::CapabilityAlreadyRegistered(capability_id));
        }
        self.capabilities.insert(
            capability_id,
            RegisteredCapability {
                definition,
                validator: Box::new(validator),
            },
        );
        Ok(())
    }

    /// Validate the registrations and seal the registry for runtime use.
    ///
    /// Sealing consumes the builder, so there is no value left to mutate: the
    /// running kernel can only be handed an immutable registry. The seal also
    /// computes one digest over every security-relevant registration field, so
    /// a whole-registry identity exists to bind alongside per-capability
    /// registration digests.
    pub fn seal(self) -> Result<SealedCapabilityRegistry, KernelError> {
        let digest = self.compute_digest()?;
        Ok(SealedCapabilityRegistry {
            capabilities: self.capabilities,
            digest,
        })
    }

    /// Return the canonical whole-registry digest of the current registrations.
    fn compute_digest(&self) -> Result<String, KernelError> {
        let mut entries: Vec<Json> = self
            .capabilities
            .values()
            .map(|registered| {
                let definition = &registered.definition;
                serde_json::json!({
                    "capability_id": definition.capability_id,
                    "capability_generation": definition.capability_generation,
                    "registration_digest": definition.registration_digest,
                    "execution_class": format!("{:?}", definition.execution_class),
                    "operation": definition.operation,
                    "route_digest": definition.route_digest,
                    "admission_id": definition.admission_id,
                    "policy_version": definition.policy_version,
                    "policy_epoch": definition.policy_epoch,
                    "admitted": definition.admitted,
                })
            })
            .collect();
        entries.sort_by(|left, right| {
            left["capability_id"]
                .as_str()
                .unwrap_or_default()
                .cmp(right["capability_id"].as_str().unwrap_or_default())
        });
        let canonical = serde_json_canonicalizer::to_vec(&entries)
            .map_err(|error| KernelError::RegistrationDigestFailed(error.to_string()))?;
        Ok(sha256_hex(&canonical))
    }
}

/// An immutable capability registry handed to a running kernel.
///
/// This type exposes no mutation: `CapabilityRegistry::seal` consumed the
/// builder, so a running kernel cannot have its classification semantics,
/// routes, or generations changed after boot.
pub struct SealedCapabilityRegistry {
    capabilities: HashMap<String, RegisteredCapability>,
    digest: String,
}

impl SealedCapabilityRegistry {
    /// Return the digest over every security-relevant registration field.
    pub fn digest(&self) -> &str {
        &self.digest
    }

    /// Return how many capabilities the sealed registry holds.
    pub fn len(&self) -> usize {
        self.capabilities.len()
    }

    /// Return whether the sealed registry holds no capabilities.
    pub fn is_empty(&self) -> bool {
        self.capabilities.is_empty()
    }

    /// Return whether an admitted capability of a given class is registered.
    ///
    /// Production composition requires this to be true for at least one
    /// consequential class, so a kernel cannot be composed for production with
    /// only `PURE` or `READ` capabilities registered.
    fn has_admitted_consequential_capability(&self) -> bool {
        self.capabilities.values().any(|registered| {
            registered.definition.admitted
                && matches!(
                    registered.definition.execution_class,
                    ExecutionClass::Mutation | ExecutionClass::Critical
                )
        })
    }

    fn resolve(&self, capability_id: &str) -> Result<&RegisteredCapability, KernelError> {
        self.capabilities
            .get(capability_id)
            .ok_or_else(|| KernelError::CapabilityUnknown(capability_id.to_owned()))
    }
}

/// A request bound by the kernel after registry, schema, identity, and digest
/// checks have completed.
///
/// Its fields and constructor are deliberately private. External harnesses
/// cannot manufacture a bound request or substitute a weaker execution class
/// before backend routing.
#[derive(Clone)]
pub struct BoundExecutionRequest {
    request: ExecutionRequest,
}

impl BoundExecutionRequest {
    fn backend_request(&self) -> &ExecutionRequest {
        &self.request
    }

    fn attach_grant(&mut self, grant: VerifiedGrant) {
        self.request.identity.grant_digest = Some(grant.digest.clone());
        self.request.grant = Some(grant.token);
    }

    fn attach_approval(&mut self, approval_reference: String) {
        self.request.identity.approval_reference = Some(approval_reference);
    }

    fn rebind_to_claimed_action(&mut self, action: &ActionRecord) {
        let identity = &mut self.request.identity;
        identity.action_id = action.preparation.action_id.clone();
        identity.execution_id = action.preparation.execution_id.clone();
        identity.invocation_id = action.preparation.execution_id.clone();
        identity.idempotency_key = action.preparation.idempotency_key.clone();
        identity.grant_digest = None;
        identity.approval_reference = None;
        self.request.grant = None;
    }

    fn action_preparation(&self) -> ActionPreparation {
        let identity = &self.request.identity;
        let capability = &identity.capability;
        let fingerprint = serde_json::json!({
            "tenant_id": identity.runtime.tenant_id,
            "principal_id": identity.runtime.principal_id,
            "runtime_id": identity.runtime.runtime_id,
            "runtime_binding_digest": identity.runtime_binding_digest,
            "capability_id": capability.capability_id,
            "capability_generation": capability.capability_generation,
            "registration_digest": capability.registration_digest,
            "operation": capability.operation,
            "execution_class": capability.execution_class,
            "route_digest": capability.route_digest,
            "args_digest": identity.args_digest,
            "admission_id": identity.admission_id,
            "policy_version": identity.policy_version,
            "policy_epoch": identity.policy_epoch,
        });
        let bytes = serde_json_canonicalizer::to_vec(&fingerprint)
            .expect("kernel-owned action fingerprint must canonicalize");
        ActionPreparation {
            action_id: identity.action_id.clone(),
            idempotency_key: identity.idempotency_key.clone(),
            fingerprint: sha256_hex(&bytes),
            execution_id: identity.execution_id.clone(),
            tenant_id: identity.runtime.tenant_id.clone(),
            principal_id: identity.runtime.principal_id.clone(),
            runtime_id: identity.runtime.runtime_id.clone(),
            runtime_binding_digest: identity.runtime_binding_digest.clone(),
            capability_id: capability.capability_id.clone(),
            capability_generation: capability.capability_generation,
            registration_digest: capability.registration_digest.clone(),
            execution_class: execution_class_name(capability.execution_class).into(),
            operation: capability.operation.clone(),
            route_digest: capability.route_digest.clone(),
            args_digest: identity.args_digest.clone(),
            admission_id: identity.admission_id.clone(),
            policy_version: identity.policy_version.clone(),
            policy_epoch: identity.policy_epoch.clone(),
            grant_digest: identity.grant_digest.clone(),
            approval_reference: identity.approval_reference.clone(),
        }
    }
}

/// Opaque continuation returned when authority approval is required.
///
/// The in-process convenience handle for an approval wait.
///
/// Durable callers should prefer [`Kernel::resume_approval`] with the action
/// identifier and the original invocation, so a process restart does not lose
/// the continuation identity.
pub struct PendingAction {
    request: BoundExecutionRequest,
    state: ExecutionState,
}

impl PendingAction {
    /// Return the stable action identifier to present to the approval system.
    pub fn action_id(&self) -> &str {
        &self.request.request.identity.action_id
    }

    /// Return the stable idempotency identity for this logical action.
    pub fn idempotency_key(&self) -> &str {
        &self.request.request.identity.idempotency_key
    }

    /// Return durable approval-wait guidance for the original action.
    pub fn status(&self) -> ActionStatus {
        let preparation = self.request.action_preparation();
        ActionStatus {
            action_id: preparation.action_id,
            idempotency_key: preparation.idempotency_key,
            state: self.state,
            intended_state: None,
            next_action: ActionNextStep::AwaitApproval,
            safe_to_retry: false,
            reconciliation_required: false,
            receipt: None,
            terminal_evidence: None,
            durable_state_confirmed: true,
        }
    }
}

/// Authority approval supplied only when resuming an opaque pending action.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ApprovalContinuation {
    /// Exact authority approval reference for the original action.
    pub approval_reference: String,
}

/// Outcome of beginning or resuming an invocation.
pub enum InvocationOutcome {
    /// The capability completed and returned a backend result.
    Completed(ExecutionResult),
    /// The exact bound action awaits external approval before it can execute.
    PendingApproval(PendingAction),
    /// An existing logical action was returned without redispatching it.
    ExistingAction(Box<ActionStatus>),
}

enum AuthorizationOutcome {
    FastPath,
    Granted(Box<VerifiedGrant>),
    PendingApproval,
    Denied,
    Deferred,
    Modify(Json),
}

/// Deterministic backend router owned by the Relay kernel.
///
/// This is a post-binding component, not a public harness entry point.
/// [`Kernel::invoke`] creates the opaque bound request that this router accepts.
pub struct BackendRouter<A, F, E> {
    authority: A,
    function_hooks: F,
    effect_fabric: E,
}

impl<A, F, E> BackendRouter<A, F, E> {
    /// Construct a router from external authority and execution providers.
    pub const fn new(authority: A, function_hooks: F, effect_fabric: E) -> Self {
        Self {
            authority,
            function_hooks,
            effect_fabric,
        }
    }

    /// Borrow the configured authority provider.
    pub const fn authority(&self) -> &A {
        &self.authority
    }
}

impl<A, F, E> BackendRouter<A, F, E>
where
    A: AuthorityProvider,
    A::Error: std::fmt::Display,
    F: ExecutionBackend,
    E: ExecutionBackend,
{
    /// Evaluate authority for a bound invocation without selecting a backend.
    fn authorize_bound(
        &self,
        request: &BoundExecutionRequest,
    ) -> Result<AuthorizationOutcome, KernelError> {
        let request = request.backend_request();
        match request.identity.capability.execution_class {
            ExecutionClass::Pure | ExecutionClass::Read => Ok(AuthorizationOutcome::FastPath),
            ExecutionClass::Mutation | ExecutionClass::Critical => {
                let authority_request = request_from_identity(&request.identity);
                let decision = self
                    .authority
                    .decide(&authority_request)
                    .map_err(|error| KernelError::AuthorityUnavailable(error.to_string()))?;
                match decision {
                    AuthorityDecision::Allow(grant) => {
                        let grant = *grant;
                        self.authority
                            .verify_grant(&authority_request, &grant)
                            .map_err(|error| {
                                KernelError::GrantVerificationFailed(error.to_string())
                            })?;
                        if !grant.binds(&authority_request)
                            || (request.identity.capability.execution_class
                                == ExecutionClass::Critical
                                && grant.approval_reference.is_none())
                        {
                            return Err(KernelError::GrantBindingFailure);
                        }
                        Ok(AuthorizationOutcome::Granted(Box::new(grant)))
                    }
                    AuthorityDecision::Deny => Ok(AuthorizationOutcome::Denied),
                    AuthorityDecision::RequireApproval => Ok(AuthorizationOutcome::PendingApproval),
                    AuthorityDecision::Defer => Ok(AuthorizationOutcome::Deferred),
                    AuthorityDecision::Modify(modification) => {
                        Ok(AuthorizationOutcome::Modify(modification))
                    }
                }
            }
        }
    }

    /// Execute a request only after the kernel completed binding and authority.
    fn execute_bound(
        &self,
        request: &BoundExecutionRequest,
    ) -> Result<ExecutionResult, KernelError> {
        match request
            .backend_request()
            .identity
            .capability
            .execution_class
        {
            ExecutionClass::Pure | ExecutionClass::Read => self
                .function_hooks
                .execute(request.backend_request())
                .map_err(|error| KernelError::FunctionBackend(error.to_string())),
            ExecutionClass::Mutation | ExecutionClass::Critical => self
                .effect_fabric
                .execute(request.backend_request())
                .map_err(KernelError::from),
        }
    }

    fn execute_effect_bound(
        &self,
        request: &BoundExecutionRequest,
    ) -> Result<ExecutionResult, nemo_relay_executor::unstable::EffectExecutionError> {
        self.effect_fabric.execute(request.backend_request())
    }

    /// Ask the external effect implementation to reconcile an unknown action.
    fn reconcile(
        &self,
        request: &ReconciliationRequest,
    ) -> Result<ReconciliationResult, KernelError>
    where
        E: ReconciliationProvider,
    {
        self.effect_fabric
            .reconcile(request)
            .map_err(KernelError::from)
    }
}

/// Public capability kernel entry point.
///
/// The kernel accepts only an unbound capability invocation, resolves its
/// immutable descriptor, validates its arguments, and constructs the opaque
/// request consumed by [`BackendRouter`]. Authority and execution mechanisms
/// remain external adapters.
pub struct Kernel<A, F, E, ES> {
    runtime: RuntimeIdentity,
    registry: SealedCapabilityRegistry,
    router: BackendRouter<A, F, E>,
    effect_store: ES,
}

impl<A, F, E, ES> Kernel<A, F, E, ES> {
    /// Assemble a kernel from an already-sealed registry.
    ///
    /// This is the single assembly step behind every constructor, and it
    /// performs no admission checks of its own. It stays private so the only
    /// reachable entry points are [`Self::new_development`] and
    /// [`Self::new_production`], each of which applies the rules for its
    /// profile before assembling.
    fn assemble(
        runtime: RuntimeIdentity,
        registry: SealedCapabilityRegistry,
        router: BackendRouter<A, F, E>,
        effect_store: ES,
    ) -> Self {
        Self {
            runtime,
            registry,
            router,
            effect_store,
        }
    }

    /// Assemble a kernel without any admission check.
    ///
    /// Unit tests use this to prove that later stages still reject what
    /// composition would have rejected. It is compiled only for this crate's
    /// own test builds, so no downstream crate can reach an unchecked
    /// constructor.
    #[cfg(test)]
    fn new_unchecked_for_tests(
        runtime: RuntimeIdentity,
        registry: SealedCapabilityRegistry,
        router: BackendRouter<A, F, E>,
        effect_store: ES,
    ) -> Self {
        Self::assemble(runtime, registry, router, effect_store)
    }

    /// Construct a development kernel after validating the runtime identity.
    ///
    /// The registry is sealed here so a development kernel has exactly the same
    /// post-boot immutability as a production one. Use [`Self::new_production`]
    /// for anything that will hold consequential authority: this constructor
    /// accepts any store, including an in-memory one.
    pub fn new_development(
        runtime: RuntimeIdentity,
        registry: CapabilityRegistry,
        router: BackendRouter<A, F, E>,
        effect_store: ES,
    ) -> Result<Self, KernelError> {
        let sealed = registry.seal()?;
        Self::new_production_identity_check(&runtime)?;
        if runtime.environment == "production" {
            return Err(KernelError::DevelopmentEnvironmentMismatch);
        }
        Ok(Self::assemble(runtime, sealed, router, effect_store))
    }

    fn new_production_identity_check(runtime: &RuntimeIdentity) -> Result<(), KernelError> {
        runtime
            .validate()
            .map_err(|error| KernelError::RuntimeIdentityInvalid(error.to_string()))?;
        Ok(())
    }

    /// Return the sealed registry digest this kernel is running with.
    pub fn registry_digest(&self) -> &str {
        self.registry.digest()
    }

    /// Construct the production kernel.
    ///
    /// Three things must hold, and none of them can be satisfied by a harness
    /// that assembles its own components:
    ///
    /// * the runtime identity must validate *and* declare the production
    ///   environment;
    /// * the registry must already be sealed and must contain at least one
    ///   admitted `MUTATION` or `CRITICAL` capability, so a kernel cannot be
    ///   composed for production with only `PURE`/`READ` routes;
    /// * the effect store must implement
    ///   [`nemo_relay_ledger::unstable::ProductionEffectStore`], a sealed trait
    ///   that only the durable PostgreSQL adapter implements, and it must
    ///   attest production readiness.
    ///
    /// The store bound is the load-bearing one: the seal makes it impossible for
    /// another crate to implement the trait for its own type, so the durable
    /// effect store cannot be substituted.
    pub fn new_production(
        runtime: RuntimeIdentity,
        registry: SealedCapabilityRegistry,
        router: BackendRouter<A, F, E>,
        effect_store: ES,
    ) -> Result<Self, KernelError>
    where
        ES: nemo_relay_ledger::unstable::ProductionEffectStore,
    {
        Self::new_production_identity_check(&runtime)?;
        if runtime.environment != "production" {
            return Err(KernelError::ProductionEnvironmentMismatch);
        }
        if !registry.has_admitted_consequential_capability() {
            return Err(KernelError::ProductionRequiresConsequentialCapability);
        }
        effect_store
            .verify_production_readiness()
            .map_err(|error| KernelError::EffectStoreNotProductionReady(error.to_string()))?;
        Ok(Self::assemble(runtime, registry, router, effect_store))
    }

    fn bind(&self, invocation: &InvocationRequest) -> Result<BoundExecutionRequest, KernelError> {
        self.runtime
            .validate()
            .map_err(|error| KernelError::RuntimeIdentityInvalid(error.to_string()))?;
        let registered = self.registry.resolve(&invocation.capability_id)?;
        if !registered.definition.admitted {
            return Err(KernelError::CapabilityNotAdmitted(
                invocation.capability_id.clone(),
            ));
        }
        registered
            .validator
            .validate(&invocation.args)
            .map_err(KernelError::SchemaValidationFailed)?;

        let canonical = serde_json_canonicalizer::to_vec(&invocation.args)
            .map_err(|error| KernelError::ArgumentCanonicalization(error.to_string()))?;
        let args_digest = sha256_hex(&canonical);
        let execution_id = Uuid::now_v7().to_string();
        let action_id = Uuid::now_v7().to_string();
        let definition = &registered.definition;
        let idempotency_key = match definition.execution_class {
            ExecutionClass::Mutation | ExecutionClass::Critical => invocation
                .request_id
                .as_deref()
                .map(|request_id| scoped_idempotency_key(&self.runtime, request_id))
                .ok_or(KernelError::RequestIdRequired)?,
            ExecutionClass::Pure | ExecutionClass::Read => action_id.clone(),
        };
        let deadline_unix_ms = kernel_deadline_unix_ms();
        Ok(BoundExecutionRequest {
            request: ExecutionRequest {
                identity: ExecutionIdentity {
                    execution_id: execution_id.clone(),
                    invocation_id: execution_id,
                    action_id: action_id.clone(),
                    // The action store claims this identity before any effect
                    // crosses the provider boundary. Effect Fabric owns its
                    // durable implementation and recovery semantics.
                    idempotency_key,
                    runtime: self.runtime.clone(),
                    runtime_binding_digest: runtime_binding_digest(&self.runtime),
                    capability: definition.identity(),
                    admission_id: definition.admission_id.clone(),
                    policy_version: definition.policy_version.clone(),
                    policy_epoch: definition.policy_epoch.clone(),
                    args_digest,
                    grant_digest: None,
                    approval_reference: None,
                    deadline_unix_ms,
                },
                args: invocation.args.clone(),
                grant: None,
                trace_id: invocation.trace_id.clone(),
                // The kernel's own managed path asserts no middleware
                // provenance — its middleware is the kernel itself.
                mediation: None,
            },
        })
    }
}

impl<A, F, E, ES> Kernel<A, F, E, ES>
where
    A: AuthorityProvider,
    <A as GrantVerifier>::Error: std::fmt::Display,
    F: ExecutionBackend,
    E: ExecutionBackend + ReconciliationProvider,
    ES: DurableEffectStore,
    <ES as ActionStore>::Error: std::fmt::Display,
    <ES as EffectStore>::Error: std::fmt::Display,
{
    /// Begin an admitted capability invocation through the secure kernel.
    ///
    /// Consequential actions are claimed in `PROPOSED` state before authority
    /// evaluation. `PREPARED` is written only after an exact grant exists.
    pub fn begin(&self, invocation: &InvocationRequest) -> Result<InvocationOutcome, KernelError> {
        let mut request = self.bind(invocation)?;
        if matches!(
            request
                .backend_request()
                .identity
                .capability
                .execution_class,
            ExecutionClass::Mutation | ExecutionClass::Critical
        ) && let Some(existing) = self.claim_action(&request)?
        {
            return self.resume_existing_action(&mut request, existing);
        }
        self.authorize_and_execute(&mut request, ExecutionState::Proposed)
    }

    /// Recover an action from immutable evidence without redispatching it.
    ///
    /// Lease expiry permits recovery work; it is never evidence that the prior
    /// worker did not cross the provider boundary.
    pub fn recover(&self, action_id: &str) -> Result<RecoveryDecision, KernelError> {
        let action = self
            .effect_store
            .load_action(action_id)
            .map_err(|error| KernelError::ActionStore(error.to_string()))?
            .ok_or_else(|| KernelError::ActionNotUnknown(action_id.to_owned()))?;

        let conflicts = self.load_receipt_conflicts(&action)?;
        if !conflicts.is_empty() {
            return Ok(RecoveryDecision::ContradictoryEvidence {
                action: self.action_status_with_next_action(
                    &action.preparation,
                    action.state,
                    ActionNextStep::RepairEvidence,
                    None,
                ),
                conflicts,
                cause: "immutable receipt conflict requires evidence repair".into(),
            });
        }

        match action.state {
            ExecutionState::Committed | ExecutionState::Failed => {
                return self.recover_terminal_action(&action);
            }
            ExecutionState::Proposed | ExecutionState::Authorized => {
                return Ok(RecoveryDecision::RecoverRetry(
                    self.action_status(&action, None),
                ));
            }
            ExecutionState::Prepared => {
                return match self.lease_status(&action.preparation.action_id)? {
                    LeaseStatus::HeldByOther(_) => Ok(RecoveryDecision::HeldByOther(
                        self.action_status_wait_for_owner(&action, None),
                    )),
                    LeaseStatus::Available => Ok(RecoveryDecision::RecoverRetry(
                        self.action_status(&action, None),
                    )),
                };
            }
            ExecutionState::Dispatching | ExecutionState::Reconciling | ExecutionState::Unknown => {
            }
            ExecutionState::Cancelled => {
                return Ok(RecoveryDecision::RecoverCancelled(
                    self.action_status(&action, None),
                ));
            }
        }

        let (_, requested_duration_ms) =
            self.lease_request_for_deadline(kernel_deadline_unix_ms())?;
        let lease = match self.claim_lease(
            &action,
            action.state,
            "recovery",
            Some(requested_duration_ms),
        )? {
            Some(lease) => lease,
            None => {
                return Ok(RecoveryDecision::HeldByOther(
                    self.action_status_wait_for_owner(&action, None),
                ));
            }
        };
        let snapshot = self
            .effect_store
            .evidence_snapshot(action_id)
            .map_err(|error| {
                self.state_recovery_required(
                    &action.preparation,
                    action.state,
                    ExecutionState::Unknown,
                    error.to_string(),
                )
            })?;
        let conflicts = snapshot.conflicts;
        if !conflicts.is_empty() {
            self.release_lease(&action, action.state, &lease)?;
            return Ok(RecoveryDecision::ContradictoryEvidence {
                action: self.action_status_with_next_action(
                    &action.preparation,
                    action.state,
                    ActionNextStep::RepairEvidence,
                    None,
                ),
                conflicts,
                cause: "immutable receipt conflict requires evidence repair".into(),
            });
        }
        let receipt = snapshot.receipt;
        if let Some(receipt) = receipt {
            if !matches!(
                receipt.final_state,
                ExecutionState::Committed | ExecutionState::Failed
            ) || !self.receipt_matches_action(&receipt, &action.preparation)
            {
                self.release_lease(&action, action.state, &lease)?;
                return Ok(RecoveryDecision::ContradictoryEvidence {
                    action: self.action_status_with_next_action(
                        &action.preparation,
                        action.state,
                        ActionNextStep::RepairEvidence,
                        None,
                    ),
                    conflicts: Vec::new(),
                    cause: "persisted terminal receipt does not bind to the action".into(),
                });
            }
            self.release_lease(&action, action.state, &lease)?;
            return Ok(RecoveryDecision::ContradictoryEvidence {
                action: self.action_status_with_next_action(
                    &action.preparation,
                    action.state,
                    ActionNextStep::RepairEvidence,
                    Some(receipt),
                ),
                conflicts: Vec::new(),
                cause: "non-terminal action has primary terminal evidence".into(),
            });
        }

        if action.state != ExecutionState::Unknown {
            self.transition_action_with_lease(
                &action,
                action.state,
                &lease,
                ExecutionState::Unknown,
            )
            .map_err(|error| {
                self.state_recovery_required(
                    &action.preparation,
                    action.state,
                    ExecutionState::Unknown,
                    error.to_string(),
                )
            })?;
        } else {
            self.release_lease(&action, ExecutionState::Unknown, &lease)?;
        }
        Ok(RecoveryDecision::RecoverUnknown(
            self.action_status_with_state(&action.preparation, ExecutionState::Unknown, None),
        ))
    }

    /// Resume an exact pending action with its authority-issued approval.
    ///
    /// A caller cannot replace its capability, arguments, route, runtime
    /// identity, action identity, or idempotency key. The authority must issue
    /// and verify a new grant bound to this same opaque request.
    pub fn resume(
        &self,
        mut pending: PendingAction,
        continuation: ApprovalContinuation,
    ) -> Result<InvocationOutcome, KernelError> {
        pending
            .request
            .attach_approval(continuation.approval_reference);
        self.authorize_and_execute(&mut pending.request, pending.state)
    }

    /// Resume an approval wait after restart using the durable action identity.
    ///
    /// The caller resubmits the original invocation so the kernel can recompute
    /// and compare every bound digest. NEMO never stores raw arguments merely
    /// to reconstruct a pending approval; Effect Fabric owns durable payload
    /// retention when that is required.
    pub fn resume_approval(
        &self,
        action_id: &str,
        invocation: &InvocationRequest,
        continuation: ApprovalContinuation,
    ) -> Result<InvocationOutcome, KernelError> {
        let action = self
            .effect_store
            .load_action(action_id)
            .map_err(|error| KernelError::ActionStore(error.to_string()))?
            .ok_or_else(|| KernelError::ActionNotUnknown(action_id.to_owned()))?;
        if !matches!(
            action.state,
            ExecutionState::Proposed | ExecutionState::Authorized | ExecutionState::Prepared
        ) {
            return Ok(InvocationOutcome::ExistingAction(Box::new(
                self.action_status(&action, None),
            )));
        }
        let mut request = self.bind(invocation)?;
        let candidate = request.action_preparation();
        if candidate.idempotency_key != action.preparation.idempotency_key
            || candidate.fingerprint != action.preparation.fingerprint
        {
            return Err(KernelError::GrantBindingFailure);
        }
        request.rebind_to_claimed_action(&action);
        request.attach_approval(continuation.approval_reference);
        self.authorize_and_execute(&mut request, action.state)
    }

    /// Reconcile one external action already recorded as `UNKNOWN`.
    pub fn reconcile(&self, action_id: &str) -> Result<ReconciliationResult, KernelError> {
        let action = self
            .effect_store
            .load_action(action_id)
            .map_err(|error| KernelError::ActionStore(error.to_string()))?;
        let action = action.ok_or_else(|| KernelError::ActionNotUnknown(action_id.to_owned()))?;
        if action.state != ExecutionState::Unknown {
            return Err(KernelError::ActionNotUnknown(action_id.to_owned()));
        }
        let deadline_unix_ms = kernel_deadline_unix_ms();
        let (configuration, requested_duration_ms) =
            self.lease_request_for_deadline(deadline_unix_ms)?;
        let lease = match self.claim_lease(
            &action,
            ExecutionState::Unknown,
            "reconcile",
            Some(requested_duration_ms),
        )? {
            Some(lease) => lease,
            None => {
                return Err(KernelError::ActionPending {
                    action: Box::new(self.action_status_wait_for_owner(&action, None)),
                    cause: ActionPendingCause::LeaseHeld,
                });
            }
        };

        let start =
            match self.effect_store.begin_reconciliation(action_id, &lease) {
                Ok(start) => start,
                Err(error) => {
                    let snapshot = self.effect_store.evidence_snapshot(action_id).map_err(
                        |snapshot_error| KernelError::EffectStore(snapshot_error.to_string()),
                    )?;
                    if snapshot.action.state == ExecutionState::Unknown
                        && snapshot.action.lease.as_ref() == Some(&lease)
                    {
                        self.release_lease(&snapshot.action, ExecutionState::Unknown, &lease)?;
                    }
                    if !snapshot.conflicts.is_empty() {
                        return Err(KernelError::EvidenceIntegrityConflict {
                            action: Box::new(self.action_status_with_next_action(
                                &snapshot.action.preparation,
                                snapshot.action.state,
                                ActionNextStep::RepairEvidence,
                                snapshot.receipt,
                            )),
                            conflicts: snapshot.conflicts,
                        });
                    }
                    if let Some(receipt) = snapshot.receipt {
                        return Err(KernelError::EvidenceIntegrityFailure {
                            action: Box::new(self.action_status_with_next_action(
                                &snapshot.action.preparation,
                                snapshot.action.state,
                                ActionNextStep::RepairEvidence,
                                Some(receipt),
                            )),
                            cause: "non-terminal action has primary terminal evidence".into(),
                        });
                    }
                    return Err(self.state_recovery_required(
                        &action.preparation,
                        ExecutionState::Unknown,
                        ExecutionState::Reconciling,
                        error.to_string(),
                    ));
                }
            };
        let leased_action = start.action;
        let evidence_revision = start.evidence.revision;
        let lease = self.renew_reconciliation_lease(
            &leased_action,
            &lease,
            configuration,
            requested_duration_ms,
        )?;
        let result = match self.router.reconcile(&ReconciliationRequest {
            action_id: action_id.to_owned(),
            deadline_unix_ms,
        }) {
            Ok(result) => result,
            Err(error) => {
                return Err(self.reconciliation_unknown(
                    &leased_action,
                    &lease,
                    evidence_revision,
                    error.to_string(),
                ));
            }
        };
        if !matches!(
            result.state,
            ExecutionState::Committed | ExecutionState::Failed | ExecutionState::Unknown
        ) {
            return Err(self.reconciliation_unknown(
                &leased_action,
                &lease,
                evidence_revision,
                format!("reconciliation returned invalid state: {:?}", result.state),
            ));
        }
        if matches!(
            result.state,
            ExecutionState::Committed | ExecutionState::Failed
        ) && result.receipt.is_none()
        {
            return Err(self.reconciliation_unknown(
                &leased_action,
                &lease,
                evidence_revision,
                "reconciliation terminal result requires authoritative evidence".into(),
            ));
        }
        if let Some(receipt) = result.receipt.as_ref() {
            if receipt.action_id != action_id
                || receipt.final_state != result.state
                || !self.receipt_matches_action(receipt, &leased_action.preparation)
            {
                return Err(self.reconciliation_unknown(
                    &leased_action,
                    &lease,
                    evidence_revision,
                    "reconciled receipt does not bind to the original action".into(),
                ));
            }
            match self
                .effect_store
                .finalize_reconciliation_receipt(action_id, &lease, evidence_revision, receipt)
                .map_err(|error| {
                    self.state_recovery_required(
                        &leased_action.preparation,
                        ExecutionState::Reconciling,
                        receipt.final_state,
                        error.to_string(),
                    )
                })? {
                EffectFinalizeResult::Finalized(_) | EffectFinalizeResult::AlreadyFinalized(_) => {}
                EffectFinalizeResult::FinalizationConflict(conflict)
                | EffectFinalizeResult::ConflictAlreadyRecorded(conflict) => {
                    return Err(self.evidence_conflict_after_reconciling(
                        &leased_action,
                        &lease,
                        evidence_revision,
                        conflict,
                    ));
                }
            }
            return Ok(result);
        }
        debug_assert_eq!(result.state, ExecutionState::Unknown);
        self.effect_store
            .complete_reconciliation_unknown(action_id, &lease, evidence_revision)
            .map_err(|error| {
                self.state_recovery_required(
                    &action.preparation,
                    ExecutionState::Reconciling,
                    ExecutionState::Unknown,
                    error.to_string(),
                )
            })?;
        Ok(result)
    }

    fn authorize_and_execute(
        &self,
        request: &mut BoundExecutionRequest,
        current_state: ExecutionState,
    ) -> Result<InvocationOutcome, KernelError> {
        if current_state == ExecutionState::Prepared
            && matches!(
                request
                    .backend_request()
                    .identity
                    .capability
                    .execution_class,
                ExecutionClass::Mutation | ExecutionClass::Critical
            )
            && matches!(
                self.lease_status(&request.action_preparation().action_id)?,
                LeaseStatus::HeldByOther(_)
            )
        {
            return Err(KernelError::ActionPending {
                action: Box::new(self.action_status_with_next_action(
                    &request.action_preparation(),
                    ExecutionState::Prepared,
                    ActionNextStep::WaitForOwner,
                    None,
                )),
                cause: ActionPendingCause::LeaseHeld,
            });
        }
        let authorization = match self.router.authorize_bound(request) {
            Ok(authorization) => authorization,
            Err(error) => return Err(self.handle_authority_error(request, current_state, error)),
        };
        match authorization {
            AuthorizationOutcome::FastPath => Ok(InvocationOutcome::Completed(
                self.router.execute_bound(request)?,
            )),
            AuthorizationOutcome::Granted(grant) => {
                request.attach_grant(*grant);
                let identity = &request.backend_request().identity;
                let grant_digest = match identity
                    .grant_digest
                    .as_deref()
                    .filter(|digest| !digest.trim().is_empty())
                {
                    Some(digest) => digest,
                    None => {
                        return Err(self.cancel_after_authority_error(
                            request,
                            current_state,
                            ActionRejectionCause::GrantBindingFailure,
                        ));
                    }
                };
                let mut state = current_state;
                if state == ExecutionState::Proposed {
                    self.effect_store
                        .authorize_action(
                            &identity.action_id,
                            ExecutionState::Proposed,
                            grant_digest,
                            identity.approval_reference.as_deref(),
                        )
                        .map_err(|error| {
                            self.pending_after_authority_failure(
                                request,
                                ExecutionState::Proposed,
                                ActionPendingCause::StatePersistenceFailure(error.to_string()),
                            )
                        })?;
                    state = ExecutionState::Authorized;
                } else if matches!(state, ExecutionState::Authorized | ExecutionState::Prepared) {
                    self.effect_store
                        .refresh_authorization(
                            &identity.action_id,
                            state,
                            grant_digest,
                            identity.approval_reference.as_deref(),
                        )
                        .map_err(|error| {
                            self.pending_after_authority_failure(
                                request,
                                state,
                                ActionPendingCause::StatePersistenceFailure(error.to_string()),
                            )
                        })?;
                }
                if state == ExecutionState::Authorized {
                    self.transition(
                        request,
                        ExecutionState::Authorized,
                        ExecutionState::Prepared,
                    )
                    .map_err(|error| {
                        self.pending_after_state_failure(request, ExecutionState::Authorized, error)
                    })?;
                    state = ExecutionState::Prepared;
                }
                if state != ExecutionState::Prepared {
                    return Err(self.pending_after_state_failure(
                        request,
                        state,
                        KernelError::InvalidStateTransition {
                            expected: state,
                            next: ExecutionState::Prepared,
                        },
                    ));
                }
                let (lease_configuration, requested_duration_ms) = self
                    .lease_request_for_deadline(
                        request.backend_request().identity.deadline_unix_ms,
                    )?;
                let lease = match self.claim_lease_for_request(
                    request,
                    ExecutionState::Prepared,
                    requested_duration_ms,
                )? {
                    Some(lease) => lease,
                    None => {
                        return Err(KernelError::ActionPending {
                            action: Box::new(self.action_status_with_next_action(
                                &request.action_preparation(),
                                ExecutionState::Prepared,
                                ActionNextStep::WaitForOwner,
                                None,
                            )),
                            cause: ActionPendingCause::LeaseHeld,
                        });
                    }
                };
                self.transition_with_lease(
                    request,
                    ExecutionState::Prepared,
                    &lease,
                    ExecutionState::Dispatching,
                )
                .map_err(|error| {
                    self.pending_after_state_failure(request, ExecutionState::Prepared, error)
                })?;
                let lease = self.renew_dispatch_lease(
                    request,
                    &lease,
                    lease_configuration,
                    requested_duration_ms,
                )?;
                Ok(InvocationOutcome::Completed(
                    self.execute_effect(request, &lease)?,
                ))
            }
            AuthorizationOutcome::PendingApproval => {
                Ok(InvocationOutcome::PendingApproval(PendingAction {
                    request: request.clone(),
                    state: current_state,
                }))
            }
            AuthorizationOutcome::Denied => self.cancel_rejected_action(
                request,
                current_state,
                ActionRejectionCause::AuthorityDenied,
            ),
            AuthorizationOutcome::Deferred => Err(self.pending_after_authority_failure(
                request,
                current_state,
                ActionPendingCause::AuthorityDeferred,
            )),
            AuthorizationOutcome::Modify(modification) => {
                self.cancel_modified_action(request, current_state, modification)
            }
        }
    }

    fn resume_existing_action(
        &self,
        request: &mut BoundExecutionRequest,
        action: ActionRecord,
    ) -> Result<InvocationOutcome, KernelError> {
        if matches!(
            action.state,
            ExecutionState::Proposed | ExecutionState::Authorized | ExecutionState::Prepared
        ) {
            request.rebind_to_claimed_action(&action);
            return self.authorize_and_execute(request, action.state);
        }
        let conflicts = self.load_receipt_conflicts(&action)?;
        if !conflicts.is_empty() {
            return Err(KernelError::EvidenceIntegrityConflict {
                action: Box::new(self.action_status_with_next_action(
                    &action.preparation,
                    action.state,
                    ActionNextStep::RepairEvidence,
                    None,
                )),
                conflicts,
            });
        }
        if matches!(
            action.state,
            ExecutionState::Committed | ExecutionState::Failed
        ) {
            return match self.recover_terminal_action(&action)? {
                RecoveryDecision::RecoverCommitted(status)
                | RecoveryDecision::RecoverFailed(status)
                | RecoveryDecision::RecoverCancelled(status) => {
                    Ok(InvocationOutcome::ExistingAction(Box::new(status)))
                }
                RecoveryDecision::ContradictoryEvidence {
                    action,
                    conflicts,
                    cause,
                } if conflicts.is_empty() => Err(KernelError::EvidenceIntegrityFailure {
                    action: Box::new(action),
                    cause,
                }),
                RecoveryDecision::ContradictoryEvidence {
                    action, conflicts, ..
                } => Err(KernelError::EvidenceIntegrityConflict {
                    action: Box::new(action),
                    conflicts,
                }),
                _ => unreachable!("terminal recovery only returns terminal or integrity states"),
            };
        }
        Ok(InvocationOutcome::ExistingAction(Box::new(
            self.action_status(&action, None),
        )))
    }

    fn handle_authority_error(
        &self,
        request: &BoundExecutionRequest,
        state: ExecutionState,
        error: KernelError,
    ) -> KernelError {
        match request
            .backend_request()
            .identity
            .capability
            .execution_class
        {
            ExecutionClass::Mutation | ExecutionClass::Critical => match error {
                KernelError::AuthorityUnavailable(cause) => self.pending_after_authority_failure(
                    request,
                    state,
                    ActionPendingCause::AuthorityUnavailable(cause),
                ),
                KernelError::GrantVerificationFailed(cause) => self.cancel_after_authority_error(
                    request,
                    state,
                    ActionRejectionCause::GrantVerificationFailed(cause),
                ),
                KernelError::GrantBindingFailure => self.cancel_after_authority_error(
                    request,
                    state,
                    ActionRejectionCause::GrantBindingFailure,
                ),
                other => self.pending_after_authority_failure(
                    request,
                    state,
                    ActionPendingCause::AuthorityUnavailable(other.to_string()),
                ),
            },
            ExecutionClass::Pure | ExecutionClass::Read => error,
        }
    }

    fn pending_after_authority_failure(
        &self,
        request: &BoundExecutionRequest,
        state: ExecutionState,
        cause: ActionPendingCause,
    ) -> KernelError {
        KernelError::ActionPending {
            action: Box::new(self.action_status_with_state(
                &request.action_preparation(),
                state,
                None,
            )),
            cause,
        }
    }

    fn pending_after_state_failure(
        &self,
        request: &BoundExecutionRequest,
        state: ExecutionState,
        error: KernelError,
    ) -> KernelError {
        KernelError::ActionPending {
            action: Box::new(self.action_status_with_state(
                &request.action_preparation(),
                state,
                None,
            )),
            cause: ActionPendingCause::StatePersistenceFailure(error.to_string()),
        }
    }

    fn claim_action(
        &self,
        request: &BoundExecutionRequest,
    ) -> Result<Option<ActionRecord>, KernelError> {
        match self
            .effect_store
            .claim_action(&request.action_preparation())
            .map_err(|error| KernelError::ActionStore(error.to_string()))?
        {
            PrepareActionResult::NewAction => Ok(None),
            PrepareActionResult::ExistingSameAction(action) => Ok(Some(*action)),
            PrepareActionResult::ActionIdConflict(action) => Err(KernelError::ActionIdConflict(
                Box::new(self.action_status(&action, None)),
            )),
            PrepareActionResult::IdempotencyConflict => Err(KernelError::IdempotencyConflict),
        }
    }

    fn cancel_rejected_action(
        &self,
        request: &BoundExecutionRequest,
        state: ExecutionState,
        cause: ActionRejectionCause,
    ) -> Result<InvocationOutcome, KernelError> {
        self.transition(request, state, ExecutionState::Cancelled)
            .map_err(|error| self.pending_after_state_failure(request, state, error))?;
        Err(KernelError::ActionRejected {
            action: Box::new(self.action_status_with_state(
                &request.action_preparation(),
                ExecutionState::Cancelled,
                None,
            )),
            cause,
        })
    }

    fn cancel_after_authority_error(
        &self,
        request: &BoundExecutionRequest,
        state: ExecutionState,
        cause: ActionRejectionCause,
    ) -> KernelError {
        match self.cancel_rejected_action(request, state, cause) {
            Err(error) => error,
            Ok(_) => unreachable!("rejected action cannot complete"),
        }
    }

    fn cancel_modified_action(
        &self,
        request: &BoundExecutionRequest,
        state: ExecutionState,
        modification: Json,
    ) -> Result<InvocationOutcome, KernelError> {
        self.transition(request, state, ExecutionState::Cancelled)
            .map_err(|error| self.pending_after_state_failure(request, state, error))?;
        Err(KernelError::ActionModificationRequired {
            action: Box::new(self.action_status_with_state(
                &request.action_preparation(),
                ExecutionState::Cancelled,
                None,
            )),
            modification,
        })
    }

    fn execute_effect(
        &self,
        request: &BoundExecutionRequest,
        lease: &ActionLease,
    ) -> Result<ExecutionResult, KernelError> {
        let result = match self.router.execute_effect_bound(request) {
            Ok(result) => result,
            Err(error) => {
                let state = nemo_relay_executor::unstable::state_for_error(&error);
                if state == ExecutionState::Unknown {
                    return Err(self.unknown_after_dispatching(request, lease, error.to_string()));
                }
                let evidence =
                    pre_dispatch_failure_evidence(&request.action_preparation(), &error)?;
                self.finalize_from_dispatching(request, lease, &evidence)?;
                return Err(KernelError::EffectFailed {
                    // `finalize_from_dispatching` has durably recorded the
                    // pre-dispatch failure. Preserve that exact evidence on
                    // the immediate public error just as a later replay does;
                    // callers must never have to retry merely to learn why a
                    // terminal failure is authoritative.
                    action: Box::new(self.action_status_with_terminal_evidence(
                        &request.action_preparation(),
                        ExecutionState::Failed,
                        None,
                        TerminalEvidence::PreDispatchFailure(evidence),
                    )),
                    cause: error.to_string(),
                });
            }
        };
        let receipt = match result.receipt.as_ref() {
            Some(receipt) => receipt,
            None => {
                return Err(self.unknown_after_dispatching(
                    request,
                    lease,
                    "effect result omitted receipt".into(),
                ));
            }
        };
        if self
            .verify_receipt(request.backend_request(), receipt, &result)
            .is_err()
        {
            return Err(self.unknown_after_dispatching(
                request,
                lease,
                "effect receipt does not bind to the execution identity".into(),
            ));
        }
        // Finalization is the last place a database wait can outlive the action
        // it serves, so it is bounded by what is left of the trusted deadline
        // rather than by the store's static maximum. An exhausted budget means
        // the outcome cannot be persisted inside the action, which is exactly
        // the case `UNKNOWN` plus reconciliation exists to cover.
        let Some(remaining) =
            remaining_action_budget(request.backend_request().identity.deadline_unix_ms)
        else {
            return Err(self.unknown_after_dispatching(
                request,
                lease,
                "trusted action budget was exhausted before the terminal receipt could \
                 be persisted"
                    .into(),
            ));
        };
        let finalization = self.effect_store.finalize_terminal_receipt_within_budget(
            &request.backend_request().identity.action_id,
            ExecutionState::Dispatching,
            lease,
            receipt,
            remaining,
        );
        match finalization {
            Err(error) => {
                return Err(self.unknown_after_dispatching(request, lease, error.to_string()));
            }
            Ok(result) => match result {
                EffectFinalizeResult::Finalized(_) | EffectFinalizeResult::AlreadyFinalized(_) => {}
                EffectFinalizeResult::FinalizationConflict(conflict)
                | EffectFinalizeResult::ConflictAlreadyRecorded(conflict) => {
                    return Err(self.evidence_conflict_after_dispatching(request, lease, conflict));
                }
            },
        }
        Ok(result)
    }

    fn transition(
        &self,
        request: &BoundExecutionRequest,
        expected: ExecutionState,
        next: ExecutionState,
    ) -> Result<(), KernelError> {
        if !is_valid_generic_transition(expected, next) {
            return Err(KernelError::InvalidStateTransition { expected, next });
        }
        self.effect_store
            .transition(
                &request.backend_request().identity.action_id,
                Some(expected),
                next,
            )
            .map_err(|error| KernelError::ActionStore(error.to_string()))
    }

    fn transition_from_dispatching(
        &self,
        request: &BoundExecutionRequest,
        lease: &ActionLease,
        next: ExecutionState,
    ) -> Result<(), KernelError> {
        debug_assert_eq!(next, ExecutionState::Unknown);
        self.transition_with_lease(request, ExecutionState::Dispatching, lease, next)
            .map_err(|error| {
                self.state_recovery_required(
                    &request.action_preparation(),
                    ExecutionState::Dispatching,
                    next,
                    error.to_string(),
                )
            })
    }

    fn finalize_from_dispatching(
        &self,
        request: &BoundExecutionRequest,
        lease: &ActionLease,
        evidence: &PreDispatchFailureEvidence,
    ) -> Result<(), KernelError> {
        self.finalize_pre_dispatch_failure(&request.action_preparation(), lease, evidence)
    }

    fn finalize_pre_dispatch_failure(
        &self,
        action: &ActionPreparation,
        lease: &ActionLease,
        evidence: &PreDispatchFailureEvidence,
    ) -> Result<(), KernelError> {
        let binds_action = evidence
            .binds_action(action)
            .map_err(|_| KernelError::GrantBindingFailure)?;
        if !binds_action {
            return Err(KernelError::InvalidStateTransition {
                expected: ExecutionState::Dispatching,
                next: ExecutionState::Failed,
            });
        }
        self.effect_store
            .finalize_pre_dispatch_failure(&action.action_id, lease, evidence)
            .map_err(|error| {
                self.state_recovery_required(
                    action,
                    ExecutionState::Dispatching,
                    ExecutionState::Failed,
                    error.to_string(),
                )
            })
    }

    fn transition_with_lease(
        &self,
        request: &BoundExecutionRequest,
        expected: ExecutionState,
        lease: &ActionLease,
        next: ExecutionState,
    ) -> Result<(), KernelError> {
        if !is_valid_leased_transition(expected, next) {
            return Err(KernelError::InvalidStateTransition { expected, next });
        }
        self.effect_store
            .transition_with_lease(
                &request.backend_request().identity.action_id,
                expected,
                lease,
                next,
            )
            .map_err(|error| KernelError::ActionStore(error.to_string()))
    }

    fn transition_action_with_lease(
        &self,
        action: &ActionRecord,
        expected: ExecutionState,
        lease: &ActionLease,
        next: ExecutionState,
    ) -> Result<(), KernelError> {
        if !is_valid_leased_transition(expected, next) {
            return Err(KernelError::InvalidStateTransition { expected, next });
        }
        self.effect_store
            .transition_with_lease(&action.preparation.action_id, expected, lease, next)
            .map_err(|error| KernelError::ActionStore(error.to_string()))
    }

    fn unknown_after_dispatching(
        &self,
        request: &BoundExecutionRequest,
        lease: &ActionLease,
        cause: String,
    ) -> KernelError {
        match self.transition_from_dispatching(request, lease, ExecutionState::Unknown) {
            Ok(()) => KernelError::EffectUnknown {
                action: Box::new(self.action_status_with_state(
                    &request.action_preparation(),
                    ExecutionState::Unknown,
                    None,
                )),
                cause,
            },
            Err(error) => error,
        }
    }

    fn reconciliation_unknown(
        &self,
        action: &ActionRecord,
        lease: &ActionLease,
        expected_evidence_revision: u64,
        cause: String,
    ) -> KernelError {
        match self.effect_store.complete_reconciliation_unknown(
            &action.preparation.action_id,
            lease,
            expected_evidence_revision,
        ) {
            Ok(()) => KernelError::EffectUnknown {
                action: Box::new(self.action_status_with_state(
                    &action.preparation,
                    ExecutionState::Unknown,
                    None,
                )),
                cause,
            },
            Err(error) => self.state_recovery_required(
                &action.preparation,
                ExecutionState::Reconciling,
                ExecutionState::Unknown,
                error.to_string(),
            ),
        }
    }

    fn evidence_conflict_after_dispatching(
        &self,
        request: &BoundExecutionRequest,
        lease: &ActionLease,
        conflict: ReceiptConflict,
    ) -> KernelError {
        match self.transition_from_dispatching(request, lease, ExecutionState::Unknown) {
            Ok(()) => KernelError::EvidenceIntegrityConflict {
                action: Box::new(self.action_status_with_next_action(
                    &request.action_preparation(),
                    ExecutionState::Unknown,
                    ActionNextStep::RepairEvidence,
                    None,
                )),
                conflicts: vec![conflict],
            },
            Err(error) => error,
        }
    }

    fn evidence_conflict_after_reconciling(
        &self,
        action: &ActionRecord,
        lease: &ActionLease,
        expected_evidence_revision: u64,
        conflict: ReceiptConflict,
    ) -> KernelError {
        match self.effect_store.complete_reconciliation_unknown(
            &action.preparation.action_id,
            lease,
            expected_evidence_revision,
        ) {
            Ok(()) => KernelError::EvidenceIntegrityConflict {
                action: Box::new(self.action_status_with_next_action(
                    &action.preparation,
                    ExecutionState::Unknown,
                    ActionNextStep::RepairEvidence,
                    None,
                )),
                conflicts: vec![conflict],
            },
            Err(error) => self.state_recovery_required(
                &action.preparation,
                ExecutionState::Reconciling,
                ExecutionState::Unknown,
                error.to_string(),
            ),
        }
    }

    fn state_recovery_required(
        &self,
        action: &ActionPreparation,
        observed_state: ExecutionState,
        intended_state: ExecutionState,
        cause: String,
    ) -> KernelError {
        let status = match self.effect_store.load_action(&action.action_id) {
            Ok(Some(current)) => {
                self.action_status_recovery(&current.preparation, current.state, intended_state)
            }
            Ok(None) | Err(_) => {
                let mut status =
                    self.action_status_recovery(action, observed_state, intended_state);
                status.durable_state_confirmed = false;
                status
            }
        };
        KernelError::StateRecoveryRequired {
            action: Box::new(status),
            intended_state,
            cause,
        }
    }

    fn claim_lease_for_request(
        &self,
        request: &BoundExecutionRequest,
        expected: ExecutionState,
        requested_duration_ms: u64,
    ) -> Result<Option<ActionLease>, KernelError> {
        let action = ActionRecord {
            preparation: request.action_preparation(),
            state: expected,
            lease: None,
            lease_generation: 0,
            terminal_evidence: None,
        };
        self.claim_lease(&action, expected, "execute", Some(requested_duration_ms))
    }

    fn lease_request_for_deadline(
        &self,
        deadline_unix_ms: u64,
    ) -> Result<(LeaseConfiguration, u64), KernelError> {
        const LEASE_MARGIN_MS: u64 = 1_000;
        let configuration = self
            .effect_store
            .lease_configuration()
            .map_err(|error| KernelError::ActionStore(error.to_string()))?;
        let now = chrono::Utc::now().timestamp_millis().max(0) as u64;
        let requested_duration_ms = deadline_unix_ms
            .saturating_sub(now)
            .saturating_add(LEASE_MARGIN_MS);
        if requested_duration_ms > configuration.maximum_duration_ms {
            return Err(KernelError::LeaseConfiguration(format!(
                "maximum lease {}ms cannot cover {}ms execution deadline plus {}ms margin",
                configuration.maximum_duration_ms,
                deadline_unix_ms.saturating_sub(now),
                LEASE_MARGIN_MS
            )));
        }
        Ok((configuration, requested_duration_ms))
    }

    fn renew_dispatch_lease(
        &self,
        request: &BoundExecutionRequest,
        lease: &ActionLease,
        configuration: LeaseConfiguration,
        requested_duration_ms: u64,
    ) -> Result<ActionLease, KernelError> {
        if !configuration.renewal_enabled {
            return Ok(lease.clone());
        }
        match self
            .effect_store
            .renew_lease(
                &request.backend_request().identity.action_id,
                ExecutionState::Dispatching,
                lease,
                Some(requested_duration_ms),
            )
            .map_err(|error| KernelError::ActionStore(error.to_string()))?
        {
            LeaseRenewResult::Renewed(lease) => Ok(lease),
            LeaseRenewResult::LeaseLost => Err(self.state_recovery_required(
                &request.action_preparation(),
                ExecutionState::Dispatching,
                ExecutionState::Unknown,
                "lease ownership changed before effect dispatch".into(),
            )),
            LeaseRenewResult::RenewalNotPermitted => Ok(lease.clone()),
            LeaseRenewResult::DurationRejected(error) => {
                Err(KernelError::LeaseConfiguration(format!("{error:?}")))
            }
        }
    }

    fn renew_reconciliation_lease(
        &self,
        action: &ActionRecord,
        lease: &ActionLease,
        configuration: LeaseConfiguration,
        requested_duration_ms: u64,
    ) -> Result<ActionLease, KernelError> {
        if !configuration.renewal_enabled {
            return Ok(lease.clone());
        }
        match self
            .effect_store
            .renew_lease(
                &action.preparation.action_id,
                ExecutionState::Reconciling,
                lease,
                Some(requested_duration_ms),
            )
            .map_err(|error| KernelError::ActionStore(error.to_string()))?
        {
            LeaseRenewResult::Renewed(lease) => Ok(lease),
            LeaseRenewResult::LeaseLost => Err(self.state_recovery_required(
                &action.preparation,
                ExecutionState::Reconciling,
                ExecutionState::Unknown,
                "lease ownership changed before provider reconciliation".into(),
            )),
            LeaseRenewResult::RenewalNotPermitted => Ok(lease.clone()),
            LeaseRenewResult::DurationRejected(error) => {
                Err(KernelError::LeaseConfiguration(format!("{error:?}")))
            }
        }
    }

    /// Return `None` when another unexpired owner holds the lease.
    fn claim_lease(
        &self,
        action: &ActionRecord,
        expected: ExecutionState,
        purpose: &str,
        requested_duration_ms: Option<u64>,
    ) -> Result<Option<ActionLease>, KernelError> {
        let owner = format!("{}:{purpose}:{}", self.runtime.runtime_id, Uuid::now_v7());
        match self
            .effect_store
            .claim_lease(
                &action.preparation.action_id,
                expected,
                &owner,
                requested_duration_ms,
            )
            .map_err(|error| KernelError::ActionStore(error.to_string()))?
        {
            LeaseAcquireResult::Acquired(lease) | LeaseAcquireResult::ExpiredReclaimed(lease) => {
                Ok(Some(lease))
            }
            LeaseAcquireResult::HeldByOther(_) => Ok(None),
            LeaseAcquireResult::DurationRejected(error) => {
                Err(KernelError::LeaseConfiguration(format!("{error:?}")))
            }
        }
    }

    fn lease_status(&self, action_id: &str) -> Result<LeaseStatus, KernelError> {
        self.effect_store
            .lease_status(action_id)
            .map_err(|error| KernelError::ActionStore(error.to_string()))
    }

    fn release_lease(
        &self,
        action: &ActionRecord,
        expected: ExecutionState,
        lease: &ActionLease,
    ) -> Result<(), KernelError> {
        match self
            .effect_store
            .release_lease(&action.preparation.action_id, expected, lease)
            .map_err(|error| KernelError::ActionStore(error.to_string()))?
        {
            LeaseReleaseResult::Released => Ok(()),
            LeaseReleaseResult::LeaseLost => Err(self.state_recovery_required(
                &action.preparation,
                expected,
                expected,
                "lease ownership changed before release".into(),
            )),
        }
    }

    fn recover_terminal_action(
        &self,
        action: &ActionRecord,
    ) -> Result<RecoveryDecision, KernelError> {
        let receipt = self
            .effect_store
            .evidence_snapshot(&action.preparation.action_id)
            .map_err(|error| {
                self.state_recovery_required(
                    &action.preparation,
                    action.state,
                    action.state,
                    error.to_string(),
                )
            })?
            .receipt;
        match (action.state, &action.terminal_evidence, receipt) {
            (
                ExecutionState::Committed,
                Some(TerminalEvidence::Receipt(evidence)),
                Some(receipt),
            ) if receipt.final_state == ExecutionState::Committed
                && self.receipt_matches_action(&receipt, &action.preparation)
                && evidence == &receipt.identity() =>
            {
                Ok(RecoveryDecision::RecoverCommitted(
                    self.action_status(action, Some(receipt)),
                ))
            }
            (ExecutionState::Failed, Some(TerminalEvidence::Receipt(evidence)), Some(receipt))
                if receipt.final_state == ExecutionState::Failed
                    && self.receipt_matches_action(&receipt, &action.preparation)
                    && evidence == &receipt.identity() =>
            {
                Ok(RecoveryDecision::RecoverFailed(
                    self.action_status(action, Some(receipt)),
                ))
            }
            (ExecutionState::Failed, Some(TerminalEvidence::PreDispatchFailure(_)), None) => Ok(
                RecoveryDecision::RecoverFailed(self.action_status(action, None)),
            ),
            (_, _, receipt) => Ok(RecoveryDecision::ContradictoryEvidence {
                action: self.action_status_with_next_action(
                    &action.preparation,
                    action.state,
                    ActionNextStep::RepairEvidence,
                    None,
                ),
                conflicts: Vec::new(),
                cause: match receipt {
                    Some(_) => "terminal receipt does not match durable action state".into(),
                    None => "terminal action has no matching immutable evidence".into(),
                },
            }),
        }
    }

    fn load_receipt_conflicts(
        &self,
        action: &ActionRecord,
    ) -> Result<Vec<ReceiptConflict>, KernelError> {
        self.effect_store
            .evidence_snapshot(&action.preparation.action_id)
            .map_err(|error| {
                self.state_recovery_required(
                    &action.preparation,
                    action.state,
                    action.state,
                    error.to_string(),
                )
            })
            .map(|snapshot| snapshot.conflicts)
    }

    fn action_status(&self, action: &ActionRecord, receipt: Option<ReceiptRecord>) -> ActionStatus {
        ActionStatus {
            terminal_evidence: action.terminal_evidence.clone(),
            ..self.action_status_with_state(&action.preparation, action.state, receipt)
        }
    }

    fn action_status_with_state(
        &self,
        action: &ActionPreparation,
        state: ExecutionState,
        receipt: Option<ReceiptRecord>,
    ) -> ActionStatus {
        ActionStatus {
            action_id: action.action_id.clone(),
            idempotency_key: action.idempotency_key.clone(),
            state,
            intended_state: None,
            next_action: action_next_step(state),
            safe_to_retry: matches!(
                state,
                ExecutionState::Proposed | ExecutionState::Authorized | ExecutionState::Prepared
            ),
            reconciliation_required: state == ExecutionState::Unknown,
            receipt,
            terminal_evidence: None,
            durable_state_confirmed: true,
        }
    }

    /// Build a terminal status immediately after a successful evidence-gated
    /// store finalization. The evidence transition itself confirms persistence,
    /// so this does not require a second store read before returning the
    /// consequential error to the harness.
    fn action_status_with_terminal_evidence(
        &self,
        action: &ActionPreparation,
        state: ExecutionState,
        receipt: Option<ReceiptRecord>,
        evidence: TerminalEvidence,
    ) -> ActionStatus {
        ActionStatus {
            terminal_evidence: Some(evidence),
            ..self.action_status_with_state(action, state, receipt)
        }
    }

    fn action_status_recovery(
        &self,
        action: &ActionPreparation,
        observed_state: ExecutionState,
        intended_state: ExecutionState,
    ) -> ActionStatus {
        ActionStatus {
            intended_state: Some(intended_state),
            next_action: ActionNextStep::RepairEvidence,
            ..self.action_status_with_state(action, observed_state, None)
        }
    }

    fn action_status_wait_for_owner(
        &self,
        action: &ActionRecord,
        receipt: Option<ReceiptRecord>,
    ) -> ActionStatus {
        ActionStatus {
            next_action: ActionNextStep::WaitForOwner,
            safe_to_retry: false,
            ..self.action_status(action, receipt)
        }
    }

    fn action_status_with_next_action(
        &self,
        action: &ActionPreparation,
        state: ExecutionState,
        next_action: ActionNextStep,
        receipt: Option<ReceiptRecord>,
    ) -> ActionStatus {
        ActionStatus {
            next_action,
            safe_to_retry: false,
            ..self.action_status_with_state(action, state, receipt)
        }
    }

    fn receipt_matches_action(&self, receipt: &ReceiptRecord, action: &ActionPreparation) -> bool {
        let Ok(binding) = ActionEvidenceBinding::try_from(action) else {
            return false;
        };
        receipt.action_id == action.action_id
            && receipt.idempotency_key == action.idempotency_key
            && receipt.identity().action_binding() == binding
            && receipt.principal_id == action.principal_id
            && receipt.capability_id == action.capability_id
            && receipt.capability_generation == action.capability_generation
            && receipt.registration_digest == action.registration_digest
            && receipt.operation == action.operation
            && receipt.execution_class == action.execution_class
            && receipt.args_digest == action.args_digest
            && receipt.route_digest == action.route_digest
            && receipt.tenant_id == action.tenant_id
            && receipt.runtime_id == action.runtime_id
            && receipt.runtime_binding_digest == action.runtime_binding_digest
            && receipt.admission_id == action.admission_id
            && receipt.policy_version == action.policy_version
            && receipt.policy_epoch == action.policy_epoch
    }

    fn verify_receipt(
        &self,
        request: &ExecutionRequest,
        receipt: &ReceiptRecord,
        result: &ExecutionResult,
    ) -> Result<(), KernelError> {
        let identity = &request.identity;
        let capability = &identity.capability;
        let class = match capability.execution_class {
            ExecutionClass::Pure => "PURE",
            ExecutionClass::Read => "READ",
            ExecutionClass::Mutation => "MUTATION",
            ExecutionClass::Critical => "CRITICAL",
        };
        if receipt.action_id != identity.action_id
            || receipt.idempotency_key != identity.idempotency_key
            || identity.grant_digest.as_deref() != Some(receipt.grant_digest.as_str())
            || receipt.principal_id != identity.runtime.principal_id
            || receipt.tenant_id != identity.runtime.tenant_id
            || receipt.runtime_id != identity.runtime.runtime_id
            || receipt.runtime_binding_digest != identity.runtime_binding_digest
            || receipt.capability_id != capability.capability_id
            || receipt.capability_generation != capability.capability_generation
            || receipt.registration_digest != capability.registration_digest
            || receipt.operation != capability.operation
            || receipt.execution_class != class
            || receipt.args_digest != identity.args_digest
            || receipt.route_digest != capability.route_digest
            || receipt.admission_id != identity.admission_id
            || receipt.policy_version != identity.policy_version
            || receipt.policy_epoch != identity.policy_epoch
            || receipt.final_state != ExecutionState::Committed
            || result.receipt_digest.as_deref() != Some(receipt.evidence_digest.as_str())
        {
            return Err(KernelError::ReceiptBindingFailure);
        }
        Ok(())
    }
}

fn sha256_hex(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

/// The kernel's own ceiling for one operation.
///
/// A ceiling rather than the policy. An operation's deadline is the smallest of what the
/// caller published and what this kernel is willing to take, so a caller can shorten an
/// operation and nothing can lengthen it. The ceiling exists because a store call needs
/// *some* bound even when nobody above this layer stated one: an unbounded kernel
/// operation is a transaction that can outlive the request that asked for it, and the
/// store waits derived from this number are what the kernel's own `UNKNOWN` handling
/// exists to cover.
const KERNEL_OPERATION_CEILING_MILLIS: u64 = 29_000;

/// The deadline one kernel operation runs under, as an absolute instant.
///
/// Inherited from the trusted budget the caller published, narrowed by the kernel's own
/// ceiling. This used to be a local constant, which made every kernel operation run under
/// a deadline the runtime had never agreed to: a caller that published two seconds got
/// twenty-nine, and a caller that published a minute got twenty-nine as well. The
/// arithmetic is [`ExecutionBudget::narrowed_to`]'s, because that is the only arithmetic
/// a layer is allowed to do with a budget — a cap can shorten and cannot lengthen.
fn kernel_deadline_unix_ms() -> u64 {
    let now = nemo_relay::api::runtime::budget_now_unix_ms();
    let budget = nemo_relay::api::runtime::current_execution_budget().map_or_else(
        || {
            nemo_relay::api::runtime::ExecutionBudget::new(
                now.saturating_add(KERNEL_OPERATION_CEILING_MILLIS),
                KERNEL_OPERATION_CEILING_MILLIS,
            )
        },
        |inherited| inherited.narrowed_to(KERNEL_OPERATION_CEILING_MILLIS, now),
    );
    budget.deadline_unix_ms.unwrap_or(u64::MAX)
}

/// Remaining trusted action budget, or `None` once the deadline has passed.
///
/// The store derives its PostgreSQL waits from this, so an exhausted budget has
/// to be refused here rather than handed over as zero: a zero-budget store call
/// would fail inside the transaction it was supposed to bound.
fn remaining_action_budget(deadline_unix_ms: u64) -> Option<Duration> {
    let now = chrono::Utc::now().timestamp_millis().max(0) as u64;
    let remaining_ms = deadline_unix_ms.saturating_sub(now);
    (remaining_ms > 0).then(|| Duration::from_millis(remaining_ms))
}

fn runtime_binding_digest(runtime: &RuntimeIdentity) -> String {
    let binding = serde_json::json!({
        "runtime_id": runtime.runtime_id,
        "environment": runtime.environment,
        "session_id": runtime.session_id,
    });
    let bytes = serde_json_canonicalizer::to_vec(&binding)
        .expect("kernel-owned runtime binding must canonicalize");
    sha256_hex(&bytes)
}

fn pre_dispatch_failure_evidence(
    action: &ActionPreparation,
    error: &nemo_relay_executor::unstable::EffectExecutionError,
) -> Result<PreDispatchFailureEvidence, KernelError> {
    let evidence = serde_json::json!({
        "code": error.code,
        "dispatch_state": error.dispatch_state,
        "outcome_certainty": error.outcome_certainty,
        "message": error.message,
    });
    let bytes = serde_json_canonicalizer::to_vec(&evidence)
        .expect("kernel-owned failure evidence must canonicalize");
    Ok(PreDispatchFailureEvidence {
        action_binding: ActionEvidenceBinding::try_from(action)
            .map_err(|_| KernelError::GrantBindingFailure)?,
        code: error.code.clone(),
        evidence_digest: sha256_hex(&bytes),
    })
}

fn scoped_idempotency_key(runtime: &RuntimeIdentity, request_id: &str) -> String {
    let namespace = serde_json::json!({
        "tenant_id": runtime.tenant_id,
        "principal_id": runtime.principal_id,
        "request_id": request_id,
    });
    let bytes = serde_json_canonicalizer::to_vec(&namespace)
        .expect("kernel-owned idempotency namespace must canonicalize");
    sha256_hex(&bytes)
}

fn action_next_step(state: ExecutionState) -> ActionNextStep {
    match state {
        ExecutionState::Proposed => ActionNextStep::RetryAuthority,
        ExecutionState::Authorized | ExecutionState::Prepared => ActionNextStep::ResumePreDispatch,
        ExecutionState::Dispatching => ActionNextStep::Recover,
        ExecutionState::Unknown => ActionNextStep::Reconcile,
        ExecutionState::Reconciling => ActionNextStep::WaitForOwner,
        ExecutionState::Committed => ActionNextStep::ReturnReceipt,
        ExecutionState::Failed | ExecutionState::Cancelled => ActionNextStep::Terminal,
    }
}

fn execution_class_name(class: ExecutionClass) -> &'static str {
    match class {
        ExecutionClass::Pure => "PURE",
        ExecutionClass::Read => "READ",
        ExecutionClass::Mutation => "MUTATION",
        ExecutionClass::Critical => "CRITICAL",
    }
}

/// How a plugin invocation failure is described at the effect boundary.
///
/// A registration that may have dispatched is an effect that may have happened.
/// A durable action records that as `UNKNOWN`: not a failure it may retry,
/// because the plugin may already have reached the external system, and not a
/// success, because nothing proves one. A registration the runtime refused
/// *before* the backend never ran, so the same action may be finished as a
/// definite failure with no reconciliation.
///
/// The conversion copies the dispatch state and the certainty the plugin
/// boundary already established rather than deriving them again from the failure
/// code. A second derivation would be a second place to get certainty wrong, and
/// certainty is the value here that must never be softened: the code says what
/// went wrong, the certainty says whether anyone can still say it did not
/// happen. `HostCrashed` and `MalformedResponse` are different things to a
/// plugin author and the same thing to an action deciding whether its effect is
/// still unaccounted for.
///
/// The effect vocabulary lives in this crate rather than the SDK — `UNKNOWN`
/// means nothing to a build that has no durable action to record it on.
///
/// `None` means the error is not a plugin invocation failure, and the caller
/// classifies it by its own rules rather than by these.
pub fn plugin_failure_as_effect_error(
    error: &nemo_relay::error::FlowError,
) -> Option<nemo_relay_executor::unstable::EffectExecutionError> {
    use nemo_relay_executor::unstable::{EffectExecutionError, OutcomeCertainty, state_for_error};
    use nemo_relay_ledger::unstable::ExecutionState;

    let nemo_relay::error::FlowError::PluginInvocation {
        registration,
        failure,
        dispatch,
        certainty,
    } = error
    else {
        return None;
    };
    let mut translated = EffectExecutionError {
        code: match certainty {
            OutcomeCertainty::Unknown => "PLUGIN_DISPATCH_UNATTESTED",
            _ => "PLUGIN_REFUSED_BEFORE_BACKEND",
        }
        .to_owned(),
        dispatch_state: *dispatch,
        outcome_certainty: *certainty,
        provider_request_id: None,
        retryable: false,
        reconciliation_required: false,
        message: format!(
            "plugin registration '{registration}' reported {:?}: {}",
            failure.code, failure.message
        ),
    };
    // Derived rather than asserted, from the same function the kernel uses to
    // classify a backend error: the flag has to agree with the state the kernel
    // will derive from this error, or two readers of one failure would disagree
    // about whether anyone can still say what happened.
    translated.reconciliation_required =
        matches!(state_for_error(&translated), ExecutionState::Unknown);
    Some(translated)
}

#[cfg(test)]
mod tests {
    use super::*;
    use nemo_relay_authority::unstable::AuthorityRequest;
    use nemo_relay_executor::unstable::{EffectExecutionError, OutcomeCertainty};
    use nemo_relay_ledger::unstable::{
        ActionRecord, FinalizeResult, ManualStoreClock, ReceiptStore,
    };
    use serde_json::json;
    use std::collections::HashMap;
    use std::sync::{
        Arc, Barrier, Mutex,
        atomic::{AtomicUsize, Ordering},
    };

    /// A kernel operation runs under the budget its caller published, capped by the
    /// kernel's own ceiling.
    ///
    /// This is the difference between a policy constant and a policy: a caller that has
    /// two seconds left cannot be given twenty-nine, and a caller that has a minute cannot
    /// extend the kernel's own bound either. The budget is a task-local, so the three
    /// cases are three calls under three budgets.
    #[tokio::test]
    async fn a_kernel_operation_runs_under_the_budget_it_inherited() {
        use nemo_relay::api::runtime::{
            ExecutionBudget, budget_now_unix_ms, with_execution_budget,
        };

        let now = budget_now_unix_ms();

        // Nothing published: the kernel's ceiling is the whole policy.
        let bare = kernel_deadline_unix_ms();
        assert!(
            bare >= now + KERNEL_OPERATION_CEILING_MILLIS - 100
                && bare <= now + KERNEL_OPERATION_CEILING_MILLIS + 100,
            "with nothing published the ceiling applies: {bare}"
        );

        // A shorter budget shortens it.
        let inherited = with_execution_budget(ExecutionBudget::new(now + 2_000, 2_000), async {
            kernel_deadline_unix_ms()
        })
        .await;
        assert!(
            inherited >= now + 1_900 && inherited <= now + 2_100,
            "a shorter published deadline wins: {inherited}"
        );

        // A longer one cannot lengthen it.
        let capped = with_execution_budget(ExecutionBudget::new(now + 120_000, 120_000), async {
            kernel_deadline_unix_ms()
        })
        .await;
        assert!(
            capped <= now + KERNEL_OPERATION_CEILING_MILLIS + 100,
            "a published budget cannot extend the kernel's own ceiling: {capped}"
        );
    }

    #[derive(Clone, Copy)]
    enum Decision {
        Allow,
        ApproveOnContinuation,
        MismatchedGrant,
        MismatchedRuntimeBinding,
        Deny,
        Defer,
        Modify,
    }

    #[derive(Clone)]
    struct TestAuthority {
        decision: Decision,
        calls: Arc<AtomicUsize>,
    }

    impl GrantVerifier for TestAuthority {
        type Error = String;

        fn verify_grant(
            &self,
            request: &AuthorityRequest,
            grant: &VerifiedGrant,
        ) -> Result<(), Self::Error> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            grant
                .binds(request)
                .then_some(())
                .ok_or_else(|| "grant does not bind".into())
        }
    }

    impl AuthorityProvider for TestAuthority {
        fn decide(
            &self,
            request: &AuthorityRequest,
        ) -> Result<AuthorityDecision, <Self as GrantVerifier>::Error> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            Ok(match self.decision {
                Decision::Allow => AuthorityDecision::Allow(Box::new(grant(request))),
                Decision::ApproveOnContinuation => {
                    if request.approval_reference.is_some() {
                        AuthorityDecision::Allow(Box::new(grant(request)))
                    } else {
                        AuthorityDecision::RequireApproval
                    }
                }
                Decision::MismatchedGrant => {
                    let mut grant = grant(request);
                    grant.route_digest = "wrong-route".into();
                    AuthorityDecision::Allow(Box::new(grant))
                }
                Decision::MismatchedRuntimeBinding => {
                    let mut grant = grant(request);
                    grant.runtime_binding_digest = "wrong-runtime-binding".into();
                    AuthorityDecision::Allow(Box::new(grant))
                }
                Decision::Deny => AuthorityDecision::Deny,
                Decision::Defer => AuthorityDecision::Defer,
                Decision::Modify => AuthorityDecision::Modify(json!({"max_value": 1})),
            })
        }
    }

    fn grant(request: &AuthorityRequest) -> VerifiedGrant {
        VerifiedGrant {
            token: "correct-once-token".into(),
            digest: "grant-digest".into(),
            action_id: request.action_id.clone(),
            idempotency_key: request.idempotency_key.clone(),
            tenant_id: request.tenant_id.clone(),
            principal_id: request.principal_id.clone(),
            runtime_binding_digest: request.runtime_binding_digest.clone(),
            admission_id: request.admission_id.clone(),
            capability_id: request.capability_id.clone(),
            capability_generation: request.capability_generation,
            registration_digest: request.registration_digest.clone(),
            execution_class: request.execution_class,
            operation: request.operation.clone(),
            route_digest: request.route_digest.clone(),
            args_digest: request.args_digest.clone(),
            policy_version: request.policy_version.clone(),
            policy_epoch: request.policy_epoch.clone(),
            approval_reference: request.approval_reference.clone(),
        }
    }

    #[derive(Clone, Default)]
    struct TestActionStore {
        prepare_calls: Arc<AtomicUsize>,
        renew_calls: Arc<AtomicUsize>,
        states: Arc<Mutex<HashMap<String, ExecutionState>>>,
        records: Arc<Mutex<HashMap<String, ActionRecord>>>,
        lease_configuration: Arc<Mutex<LeaseConfiguration>>,
        /// Inject a persistence failure only when trying to record an
        /// ambiguous post-dispatch outcome. Earlier lifecycle boundaries must
        /// remain writable so this test double can exercise the exact crash
        /// window that matters.
        fail_unknown_transition: Arc<Mutex<Option<String>>>,
        /// Simulates a competing writer that persisted `UNKNOWN` before this
        /// worker learned its stale compare-and-set failed.
        persist_unknown_then_fail: Arc<Mutex<Option<String>>>,
        /// Pauses reconciliation immediately after its fenced lease is
        /// persisted so race tests can inject late immutable evidence.
        reconciliation_claim_barrier: Arc<Mutex<Option<Arc<Barrier>>>>,
    }

    impl ActionStore for TestActionStore {
        type Error = String;

        fn claim_action(
            &self,
            action: &ActionPreparation,
        ) -> Result<PrepareActionResult, Self::Error> {
            self.prepare_calls.fetch_add(1, Ordering::SeqCst);
            let mut records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            if let Some(existing) = records.get(&action.action_id).cloned() {
                return Ok(if existing.preparation == *action {
                    PrepareActionResult::ExistingSameAction(Box::new(existing))
                } else {
                    PrepareActionResult::ActionIdConflict(Box::new(existing))
                });
            }
            if let Some(existing) = records
                .values()
                .find(|record| record.preparation.idempotency_key == action.idempotency_key)
            {
                return Ok(if existing.preparation.fingerprint == action.fingerprint {
                    PrepareActionResult::ExistingSameAction(Box::new(existing.clone()))
                } else {
                    PrepareActionResult::IdempotencyConflict
                });
            }
            records.insert(
                action.action_id.clone(),
                ActionRecord {
                    preparation: action.clone(),
                    state: ExecutionState::Proposed,
                    lease: None,
                    lease_generation: 0,
                    terminal_evidence: None,
                },
            );
            self.states
                .lock()
                .map_err(|_| "test action state lock poisoned".to_owned())?
                .insert(action.action_id.clone(), ExecutionState::Proposed);
            Ok(PrepareActionResult::NewAction)
        }

        fn load_action(&self, action_id: &str) -> Result<Option<ActionRecord>, Self::Error> {
            Ok(self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?
                .get(action_id)
                .cloned()
                .or_else(|| {
                    self.states
                        .lock()
                        .ok()?
                        .get(action_id)
                        .copied()
                        .map(|state| ActionRecord {
                            preparation: ActionPreparation {
                                action_id: action_id.to_owned(),
                                idempotency_key: "reconciled-idempotency".into(),
                                fingerprint: "reconciled-fingerprint".into(),
                                execution_id: "reconciled-execution".into(),
                                tenant_id: Some("tenant".into()),
                                principal_id: "alice".into(),
                                runtime_id: "runtime-1".into(),
                                runtime_binding_digest: "runtime-binding".into(),
                                capability_id: "capability.test".into(),
                                capability_generation: 7,
                                registration_digest: "registration-7".into(),
                                execution_class: "CRITICAL".into(),
                                operation: "test".into(),
                                route_digest: "route-7".into(),
                                args_digest: "args".into(),
                                admission_id: "admission-7".into(),
                                policy_version: "policy-7".into(),
                                policy_epoch: "epoch-7".into(),
                                grant_digest: Some("reconciled-grant".into()),
                                approval_reference: None,
                            },
                            state,
                            lease: None,
                            lease_generation: 0,
                            terminal_evidence: None,
                        })
                }))
        }

        fn load_state(&self, action_id: &str) -> Result<Option<ExecutionState>, Self::Error> {
            Ok(self
                .states
                .lock()
                .map_err(|_| "test action state lock poisoned".to_owned())?
                .get(action_id)
                .copied())
        }

        fn transition(
            &self,
            action_id: &str,
            expected: Option<ExecutionState>,
            next: ExecutionState,
        ) -> Result<(), Self::Error> {
            if expected == Some(ExecutionState::Dispatching)
                && next == ExecutionState::Unknown
                && let Some(error) = self
                    .fail_unknown_transition
                    .lock()
                    .map_err(|_| "test action transition failure lock poisoned".to_owned())?
                    .clone()
            {
                return Err(error);
            }
            let mut states = self
                .states
                .lock()
                .map_err(|_| "test action state lock poisoned".to_owned())?;
            if states.get(action_id).copied() != expected {
                return Err("unexpected state transition".into());
            }
            states.insert(action_id.to_owned(), next);
            if let Ok(mut records) = self.records.lock()
                && let Some(record) = records.get_mut(action_id)
            {
                record.state = next;
            }
            Ok(())
        }

        fn authorize_action(
            &self,
            action_id: &str,
            expected: ExecutionState,
            grant_digest: &str,
            approval_reference: Option<&str>,
        ) -> Result<(), Self::Error> {
            let mut records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            let record = records
                .get_mut(action_id)
                .ok_or_else(|| "unknown action authorization binding".to_owned())?;
            if record.state != expected {
                return Err("unexpected authorization state".into());
            }
            record.preparation.grant_digest = Some(grant_digest.to_owned());
            record.preparation.approval_reference = approval_reference.map(ToOwned::to_owned);
            record.state = ExecutionState::Authorized;
            drop(records);
            self.states
                .lock()
                .map_err(|_| "test action state lock poisoned".to_owned())?
                .insert(action_id.to_owned(), ExecutionState::Authorized);
            Ok(())
        }

        fn refresh_authorization(
            &self,
            action_id: &str,
            expected: ExecutionState,
            grant_digest: &str,
            approval_reference: Option<&str>,
        ) -> Result<(), Self::Error> {
            let mut records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            let record = records
                .get_mut(action_id)
                .ok_or_else(|| "unknown action authorization refresh".to_owned())?;
            if record.state != expected {
                return Err("unexpected authorization refresh state".into());
            }
            record.preparation.grant_digest = Some(grant_digest.to_owned());
            record.preparation.approval_reference = approval_reference.map(ToOwned::to_owned);
            Ok(())
        }

        fn lease_configuration(
            &self,
        ) -> Result<nemo_relay_ledger::unstable::LeaseConfiguration, Self::Error> {
            self.lease_configuration
                .lock()
                .map(|configuration| *configuration)
                .map_err(|_| "test lease configuration lock poisoned".to_owned())
        }

        fn lease_status(
            &self,
            action_id: &str,
        ) -> Result<nemo_relay_ledger::unstable::LeaseStatus, Self::Error> {
            let now_unix_ms = chrono::Utc::now().timestamp_millis().max(0) as u64;
            let records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            let record = records
                .get(action_id)
                .ok_or_else(|| "unknown action lease status".to_owned())?;
            Ok(match record.lease.as_ref() {
                Some(lease) if lease.expires_at_unix_ms > now_unix_ms => {
                    LeaseStatus::HeldByOther(lease.clone())
                }
                _ => LeaseStatus::Available,
            })
        }

        fn claim_lease(
            &self,
            action_id: &str,
            expected: ExecutionState,
            owner_id: &str,
            requested_duration_ms: Option<u64>,
        ) -> Result<LeaseAcquireResult, Self::Error> {
            let now_unix_ms = chrono::Utc::now().timestamp_millis().max(0) as u64;
            let lease_duration_ms = requested_duration_ms.unwrap_or(30_000);
            let mut records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            let record = records
                .get_mut(action_id)
                .ok_or_else(|| "unknown action lease".to_owned())?;
            if record.state != expected {
                return Err("unexpected lease state".into());
            }
            if let Some(lease) = record.lease.as_ref()
                && lease.expires_at_unix_ms > now_unix_ms
            {
                return Ok(LeaseAcquireResult::HeldByOther(lease.clone()));
            }
            let reclaimed = record.lease.is_some();
            let generation = record
                .lease_generation
                .checked_add(1)
                .ok_or_else(|| "fencing generation exhausted".to_owned())?;
            let lease = ActionLease {
                owner_id: owner_id.to_owned(),
                generation,
                expires_at_unix_ms: now_unix_ms.saturating_add(lease_duration_ms),
            };
            record.lease = Some(lease.clone());
            record.lease_generation = generation;
            let result = if reclaimed {
                LeaseAcquireResult::ExpiredReclaimed(lease)
            } else {
                LeaseAcquireResult::Acquired(lease)
            };
            drop(records);
            if owner_id.contains(":reconcile:")
                && let Some(barrier) = self
                    .reconciliation_claim_barrier
                    .lock()
                    .map_err(|_| "test reconciliation barrier lock poisoned".to_owned())?
                    .clone()
            {
                // First rendezvous proves the recovery lease has been
                // acquired. The second keeps reconciliation from re-reading
                // receipts until the test has persisted the late evidence.
                // This models the exact race boundary without relying on
                // scheduler timing.
                barrier.wait();
                barrier.wait();
            }
            Ok(result)
        }

        fn renew_lease(
            &self,
            action_id: &str,
            expected: ExecutionState,
            lease: &ActionLease,
            requested_duration_ms: Option<u64>,
        ) -> Result<nemo_relay_ledger::unstable::LeaseRenewResult, Self::Error> {
            self.renew_calls.fetch_add(1, Ordering::SeqCst);
            let now_unix_ms = chrono::Utc::now().timestamp_millis().max(0) as u64;
            let mut records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            let record = records
                .get_mut(action_id)
                .ok_or_else(|| "unknown action lease renewal".to_owned())?;
            if record.state != expected
                || record.lease.as_ref() != Some(lease)
                || lease.expires_at_unix_ms <= now_unix_ms
            {
                return Ok(nemo_relay_ledger::unstable::LeaseRenewResult::LeaseLost);
            }
            let renewed = ActionLease {
                expires_at_unix_ms: now_unix_ms
                    .saturating_add(requested_duration_ms.unwrap_or(30_000)),
                ..lease.clone()
            };
            record.lease = Some(renewed.clone());
            Ok(nemo_relay_ledger::unstable::LeaseRenewResult::Renewed(
                renewed,
            ))
        }

        fn release_lease(
            &self,
            action_id: &str,
            expected: ExecutionState,
            lease: &ActionLease,
        ) -> Result<nemo_relay_ledger::unstable::LeaseReleaseResult, Self::Error> {
            let mut records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            let record = records
                .get_mut(action_id)
                .ok_or_else(|| "unknown action lease release".to_owned())?;
            if record.state != expected || record.lease.as_ref() != Some(lease) {
                return Ok(nemo_relay_ledger::unstable::LeaseReleaseResult::LeaseLost);
            }
            record.lease = None;
            Ok(nemo_relay_ledger::unstable::LeaseReleaseResult::Released)
        }

        fn transition_with_lease(
            &self,
            action_id: &str,
            expected: ExecutionState,
            lease: &ActionLease,
            next: ExecutionState,
        ) -> Result<(), Self::Error> {
            if expected == ExecutionState::Dispatching
                && next == ExecutionState::Unknown
                && let Some(error) = self
                    .fail_unknown_transition
                    .lock()
                    .map_err(|_| "test action transition failure lock poisoned".to_owned())?
                    .clone()
            {
                return Err(error);
            }
            let mut records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            let record = records
                .get_mut(action_id)
                .ok_or_else(|| "unknown action fenced transition".to_owned())?;
            if record.state != expected || record.lease.as_ref() != Some(lease) {
                return Err("stale or unexpected action lease".into());
            }
            if expected == ExecutionState::Dispatching
                && next == ExecutionState::Unknown
                && let Some(error) = self
                    .persist_unknown_then_fail
                    .lock()
                    .map_err(|_| "test stale transition failure lock poisoned".to_owned())?
                    .clone()
            {
                record.state = ExecutionState::Unknown;
                record.lease = None;
                drop(records);
                self.states
                    .lock()
                    .map_err(|_| "test action state lock poisoned".to_owned())?
                    .insert(action_id.to_owned(), ExecutionState::Unknown);
                return Err(error);
            }
            record.state = next;
            if next != ExecutionState::Dispatching && next != ExecutionState::Reconciling {
                record.lease = None;
            }
            drop(records);
            self.states
                .lock()
                .map_err(|_| "test action state lock poisoned".to_owned())?
                .insert(action_id.to_owned(), next);
            Ok(())
        }

        fn finalize_pre_dispatch_failure(
            &self,
            action_id: &str,
            lease: &ActionLease,
            evidence: &PreDispatchFailureEvidence,
        ) -> Result<(), Self::Error> {
            let mut records = self
                .records
                .lock()
                .map_err(|_| "test action record lock poisoned".to_owned())?;
            let record = records
                .get_mut(action_id)
                .ok_or_else(|| "unknown action terminal evidence".to_owned())?;
            if record.state != ExecutionState::Dispatching || record.lease.as_ref() != Some(lease) {
                return Err("stale or unexpected terminal evidence lease".into());
            }
            let binds_action = evidence
                .binds_action(&record.preparation)
                .map_err(|_| "invalid grant digest in terminal evidence".to_owned())?;
            if !binds_action {
                return Err("invalid terminal evidence transition".into());
            }
            record.terminal_evidence = Some(TerminalEvidence::PreDispatchFailure(evidence.clone()));
            record.state = ExecutionState::Failed;
            record.lease = None;
            drop(records);
            self.states
                .lock()
                .map_err(|_| "test action state lock poisoned".to_owned())?
                .insert(action_id.to_owned(), ExecutionState::Failed);
            Ok(())
        }
    }

    #[derive(Clone, Default)]
    struct TestReceiptStore {
        receipts: Arc<Mutex<Vec<ReceiptRecord>>>,
        conflicts: Arc<Mutex<HashMap<String, Vec<ReceiptConflict>>>>,
        fail_store: Arc<Mutex<Option<String>>>,
        inject_finalization_conflict: Arc<AtomicUsize>,
    }

    impl ReceiptStore for TestReceiptStore {
        type Error = String;

        fn finalize(&self, receipt: &ReceiptRecord) -> Result<FinalizeResult, Self::Error> {
            if let Some(error) = self
                .fail_store
                .lock()
                .map_err(|_| "test receipt failure lock poisoned".to_owned())?
                .clone()
            {
                return Err(error);
            }
            let mut receipts = self
                .receipts
                .lock()
                .map_err(|_| "test receipt lock poisoned".to_owned())?;
            if self
                .inject_finalization_conflict
                .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |count| {
                    count.checked_sub(1)
                })
                .is_ok()
                && !receipts
                    .iter()
                    .any(|existing| existing.action_id == receipt.action_id)
            {
                let mut existing = receipt.clone();
                existing.receipt_id = "conflicting-existing-receipt".into();
                existing.evidence_digest = "conflicting-evidence".into();
                receipts.push(existing);
            }
            match receipts
                .iter()
                .find(|existing| existing.action_id == receipt.action_id)
                .cloned()
            {
                None => {
                    receipts.push(receipt.clone());
                    Ok(FinalizeResult::Finalized(receipt.clone()))
                }
                Some(existing) if existing.identity() == receipt.identity() => {
                    Ok(FinalizeResult::AlreadyFinalized(existing))
                }
                Some(existing) => {
                    let conflict = ReceiptConflict::new(&existing, receipt);
                    drop(receipts);
                    self.conflicts
                        .lock()
                        .map_err(|_| "test receipt conflict lock poisoned".to_owned())?
                        .entry(receipt.action_id.clone())
                        .or_default()
                        .push(conflict.clone());
                    Ok(FinalizeResult::FinalizationConflict(conflict))
                }
            }
        }

        fn load(&self, action_id: &str) -> Result<Option<ReceiptRecord>, Self::Error> {
            Ok(self
                .receipts
                .lock()
                .map_err(|_| "test receipt lock poisoned".to_owned())?
                .iter()
                .find(|receipt| receipt.action_id == action_id)
                .cloned())
        }

        fn load_conflicts(&self, action_id: &str) -> Result<Vec<ReceiptConflict>, Self::Error> {
            Ok(self
                .conflicts
                .lock()
                .map_err(|_| "test receipt conflict lock poisoned".to_owned())?
                .get(action_id)
                .cloned()
                .unwrap_or_default())
        }
    }

    #[derive(Clone, Default)]
    struct TestEffectStore {
        actions: TestActionStore,
        receipts: TestReceiptStore,
        evidence_revisions: Arc<Mutex<HashMap<String, u64>>>,
    }

    impl ActionStore for TestEffectStore {
        type Error = String;

        fn claim_action(
            &self,
            action: &ActionPreparation,
        ) -> Result<PrepareActionResult, Self::Error> {
            self.actions.claim_action(action)
        }

        fn load_action(&self, action_id: &str) -> Result<Option<ActionRecord>, Self::Error> {
            self.actions.load_action(action_id)
        }

        fn authorize_action(
            &self,
            action_id: &str,
            expected: ExecutionState,
            grant_digest: &str,
            approval_reference: Option<&str>,
        ) -> Result<(), Self::Error> {
            self.actions
                .authorize_action(action_id, expected, grant_digest, approval_reference)
        }

        fn refresh_authorization(
            &self,
            action_id: &str,
            expected: ExecutionState,
            grant_digest: &str,
            approval_reference: Option<&str>,
        ) -> Result<(), Self::Error> {
            self.actions.refresh_authorization(
                action_id,
                expected,
                grant_digest,
                approval_reference,
            )
        }

        fn lease_configuration(&self) -> Result<LeaseConfiguration, Self::Error> {
            self.actions.lease_configuration()
        }

        fn lease_status(&self, action_id: &str) -> Result<LeaseStatus, Self::Error> {
            self.actions.lease_status(action_id)
        }

        fn claim_lease(
            &self,
            action_id: &str,
            expected: ExecutionState,
            owner_id: &str,
            requested_duration_ms: Option<u64>,
        ) -> Result<LeaseAcquireResult, Self::Error> {
            self.actions
                .claim_lease(action_id, expected, owner_id, requested_duration_ms)
        }

        fn renew_lease(
            &self,
            action_id: &str,
            expected: ExecutionState,
            lease: &ActionLease,
            requested_duration_ms: Option<u64>,
        ) -> Result<LeaseRenewResult, Self::Error> {
            self.actions
                .renew_lease(action_id, expected, lease, requested_duration_ms)
        }

        fn release_lease(
            &self,
            action_id: &str,
            expected: ExecutionState,
            lease: &ActionLease,
        ) -> Result<LeaseReleaseResult, Self::Error> {
            self.actions.release_lease(action_id, expected, lease)
        }

        fn transition_with_lease(
            &self,
            action_id: &str,
            expected: ExecutionState,
            lease: &ActionLease,
            next: ExecutionState,
        ) -> Result<(), Self::Error> {
            self.actions
                .transition_with_lease(action_id, expected, lease, next)
        }

        fn finalize_pre_dispatch_failure(
            &self,
            action_id: &str,
            lease: &ActionLease,
            evidence: &PreDispatchFailureEvidence,
        ) -> Result<(), Self::Error> {
            self.actions
                .finalize_pre_dispatch_failure(action_id, lease, evidence)
        }

        fn transition(
            &self,
            action_id: &str,
            expected: Option<ExecutionState>,
            next: ExecutionState,
        ) -> Result<(), Self::Error> {
            self.actions.transition(action_id, expected, next)
        }
    }

    impl EffectStore for TestEffectStore {
        type Error = String;

        fn evidence_snapshot(
            &self,
            action_id: &str,
        ) -> Result<nemo_relay_ledger::unstable::EvidenceSnapshot, Self::Error> {
            Ok(nemo_relay_ledger::unstable::EvidenceSnapshot {
                action: self
                    .actions
                    .load_action(action_id)?
                    .ok_or_else(|| "unknown action evidence snapshot".to_owned())?,
                revision: self
                    .evidence_revisions
                    .lock()
                    .map_err(|_| "test evidence revision lock poisoned".to_owned())?
                    .get(action_id)
                    .copied()
                    .unwrap_or_default(),
                receipt: self.receipts.load(action_id)?,
                conflicts: self.receipts.load_conflicts(action_id)?,
            })
        }

        fn observe_terminal_evidence(
            &self,
            action_id: &str,
            receipt: &ReceiptRecord,
        ) -> Result<nemo_relay_ledger::unstable::EvidenceObservationResult, Self::Error> {
            if self.receipts.load(action_id)?.is_none() {
                return Err("primary terminal evidence requires fenced finalization".into());
            }
            match self.receipts.finalize(receipt)? {
                FinalizeResult::Finalized(_) => {
                    Err("observation unexpectedly established primary evidence".into())
                }
                FinalizeResult::AlreadyFinalized(_) => {
                    Ok(nemo_relay_ledger::unstable::EvidenceObservationResult::AlreadyObserved)
                }
                FinalizeResult::FinalizationConflict(conflict) => {
                    *self
                        .evidence_revisions
                        .lock()
                        .map_err(|_| "test evidence revision lock poisoned".to_owned())?
                        .entry(action_id.to_owned())
                        .or_default() += 1;
                    Ok(
                        nemo_relay_ledger::unstable::EvidenceObservationResult::ConflictRecorded(
                            conflict,
                        ),
                    )
                }
                FinalizeResult::ConflictAlreadyRecorded(conflict) => Ok(
                    nemo_relay_ledger::unstable::EvidenceObservationResult::ConflictAlreadyRecorded(
                        conflict,
                    ),
                ),
            }
        }

        fn begin_reconciliation(
            &self,
            action_id: &str,
            lease: &ActionLease,
        ) -> Result<nemo_relay_ledger::unstable::ReconciliationStart, Self::Error> {
            let snapshot = self.evidence_snapshot(action_id)?;
            if snapshot.receipt.is_some() || !snapshot.conflicts.is_empty() {
                return Err("reconciliation cannot start with terminal evidence".into());
            }
            self.actions.transition_with_lease(
                action_id,
                ExecutionState::Unknown,
                lease,
                ExecutionState::Reconciling,
            )?;
            let action = self
                .actions
                .load_action(action_id)?
                .ok_or_else(|| "unknown reconciliation action".to_owned())?;
            Ok(nemo_relay_ledger::unstable::ReconciliationStart {
                action: action.clone(),
                evidence: nemo_relay_ledger::unstable::EvidenceSnapshot { action, ..snapshot },
            })
        }

        fn finalize_reconciliation_receipt(
            &self,
            action_id: &str,
            lease: &ActionLease,
            expected_evidence_revision: u64,
            receipt: &ReceiptRecord,
        ) -> Result<EffectFinalizeResult, Self::Error> {
            let actual = self
                .evidence_revisions
                .lock()
                .map_err(|_| "test evidence revision lock poisoned".to_owned())?
                .get(action_id)
                .copied()
                .unwrap_or_default();
            if actual != expected_evidence_revision {
                return Err("reconciliation evidence changed".into());
            }
            self.finalize_terminal_receipt(action_id, ExecutionState::Reconciling, lease, receipt)
        }

        fn complete_reconciliation_unknown(
            &self,
            action_id: &str,
            lease: &ActionLease,
            expected_evidence_revision: u64,
        ) -> Result<(), Self::Error> {
            let actual = self
                .evidence_revisions
                .lock()
                .map_err(|_| "test evidence revision lock poisoned".to_owned())?
                .get(action_id)
                .copied()
                .unwrap_or_default();
            if actual != expected_evidence_revision {
                return Err("reconciliation evidence changed".into());
            }
            self.actions.transition_with_lease(
                action_id,
                ExecutionState::Reconciling,
                lease,
                ExecutionState::Unknown,
            )
        }

        fn finalize_terminal_receipt(
            &self,
            action_id: &str,
            expected: ExecutionState,
            lease: &ActionLease,
            receipt: &ReceiptRecord,
        ) -> Result<EffectFinalizeResult, Self::Error> {
            if let Some(action) = self.actions.load_action(action_id)?
                && action.state == receipt.final_state
                && action.terminal_evidence == Some(TerminalEvidence::Receipt(receipt.identity()))
                && self
                    .receipts
                    .load(action_id)?
                    .is_some_and(|existing| existing.identity() == receipt.identity())
            {
                return Ok(EffectFinalizeResult::AlreadyFinalized(receipt.clone()));
            }
            let finalized = self.receipts.finalize(receipt)?;
            match finalized {
                FinalizeResult::Finalized(stored) | FinalizeResult::AlreadyFinalized(stored) => {
                    let mut records = self
                        .actions
                        .records
                        .lock()
                        .map_err(|_| "test action record lock poisoned".to_owned())?;
                    let action = records
                        .get_mut(action_id)
                        .ok_or_else(|| "unknown action terminal receipt".to_owned())?;
                    if action.state != expected || action.lease.as_ref() != Some(lease) {
                        return Err("stale or unexpected terminal receipt lease".into());
                    }
                    if !stored
                        .identity()
                        .action_binding()
                        .eq(&ActionEvidenceBinding::try_from(&action.preparation)
                            .map_err(|_| "invalid grant digest in terminal receipt".to_owned())?)
                    {
                        return Err("terminal receipt does not bind action".into());
                    }
                    action.terminal_evidence = Some(TerminalEvidence::Receipt(stored.identity()));
                    action.state = stored.final_state;
                    action.lease = None;
                    drop(records);
                    self.actions
                        .states
                        .lock()
                        .map_err(|_| "test action state lock poisoned".to_owned())?
                        .insert(action_id.to_owned(), stored.final_state);
                    *self
                        .evidence_revisions
                        .lock()
                        .map_err(|_| "test evidence revision lock poisoned".to_owned())?
                        .entry(action_id.to_owned())
                        .or_default() += 1;
                    Ok(EffectFinalizeResult::Finalized(stored))
                }
                FinalizeResult::FinalizationConflict(conflict) => {
                    Ok(EffectFinalizeResult::FinalizationConflict(conflict))
                }
                FinalizeResult::ConflictAlreadyRecorded(conflict) => {
                    Ok(EffectFinalizeResult::ConflictAlreadyRecorded(conflict))
                }
            }
        }
    }

    #[derive(Clone, Default)]
    struct TestBackend {
        calls: Arc<AtomicUsize>,
        reconciliation_calls: Arc<AtomicUsize>,
        requests: Arc<Mutex<Vec<ExecutionRequest>>>,
        effect_error: Arc<Mutex<Option<EffectExecutionError>>>,
        reconciliation_result: Arc<Mutex<Option<ReconciliationResult>>>,
        reconciliation_error: Arc<Mutex<Option<EffectExecutionError>>>,
    }

    impl ExecutionBackend for TestBackend {
        fn execute(
            &self,
            request: &ExecutionRequest,
        ) -> Result<ExecutionResult, EffectExecutionError> {
            self.calls.fetch_add(1, Ordering::SeqCst);
            self.requests
                .lock()
                .expect("test request lock should not be poisoned")
                .push(request.clone());
            let consequential = matches!(
                request.identity.capability.execution_class,
                ExecutionClass::Mutation | ExecutionClass::Critical
            );
            if consequential
                && let Some(error) = self
                    .effect_error
                    .lock()
                    .expect("test effect error lock should not be poisoned")
                    .clone()
            {
                return Err(error);
            }
            let receipt = consequential.then(|| receipt(request));
            Ok(ExecutionResult {
                output: json!({"ok": true}),
                outcome_certainty: OutcomeCertainty::ConfirmedSuccess,
                receipt_digest: receipt
                    .as_ref()
                    .map(|receipt| receipt.evidence_digest.clone()),
                receipt,
            })
        }
    }

    impl ReconciliationProvider for TestBackend {
        fn reconcile(
            &self,
            reconciliation: &ReconciliationRequest,
        ) -> Result<ReconciliationResult, EffectExecutionError> {
            self.reconciliation_calls.fetch_add(1, Ordering::SeqCst);
            assert!(
                reconciliation.deadline_unix_ms
                    > chrono::Utc::now().timestamp_millis().max(0) as u64,
                "kernel must give reconciliation a bounded future deadline"
            );
            let action_id = &reconciliation.action_id;
            if let Some(error) = self
                .reconciliation_error
                .lock()
                .expect("test reconciliation error lock should not be poisoned")
                .clone()
            {
                return Err(error);
            }
            if let Some(result) = self
                .reconciliation_result
                .lock()
                .expect("test reconciliation result lock should not be poisoned")
                .clone()
            {
                return Ok(result);
            }
            if let Some(request) = self
                .requests
                .lock()
                .expect("test request lock should not be poisoned")
                .iter()
                .find(|request| request.identity.action_id == *action_id)
                .cloned()
            {
                return Ok(ReconciliationResult {
                    state: ExecutionState::Committed,
                    receipt: Some(receipt(&request)),
                });
            }
            Ok(ReconciliationResult {
                state: ExecutionState::Committed,
                receipt: Some(ReceiptRecord {
                    receipt_id: "reconciled-receipt".into(),
                    action_id: action_id.to_owned(),
                    idempotency_key: "reconciled-idempotency".into(),
                    grant_digest: "reconciled-grant".into(),
                    principal_id: "alice".into(),
                    tenant_id: Some("tenant".into()),
                    runtime_id: "runtime-1".into(),
                    runtime_binding_digest: runtime_binding_digest(&runtime()),
                    capability_id: "capability.test".into(),
                    capability_generation: 7,
                    registration_digest: "registration-7".into(),
                    operation: "test".into(),
                    execution_class: "CRITICAL".into(),
                    args_digest: "args".into(),
                    route_digest: "route-7".into(),
                    admission_id: "admission-7".into(),
                    policy_version: "policy-7".into(),
                    policy_epoch: "epoch-7".into(),
                    provider_request_id: None,
                    final_state: ExecutionState::Committed,
                    started_at_unix_ms: 1,
                    finished_at_unix_ms: 2,
                    evidence_digest: "reconciled-evidence".into(),
                }),
            })
        }
    }

    fn receipt(request: &ExecutionRequest) -> ReceiptRecord {
        let identity = &request.identity;
        let capability = &identity.capability;
        ReceiptRecord {
            receipt_id: "receipt-1".into(),
            action_id: identity.action_id.clone(),
            idempotency_key: identity.idempotency_key.clone(),
            grant_digest: identity
                .grant_digest
                .clone()
                .expect("consequential test receipt requires a verified grant digest"),
            principal_id: identity.runtime.principal_id.clone(),
            tenant_id: identity.runtime.tenant_id.clone(),
            runtime_id: identity.runtime.runtime_id.clone(),
            runtime_binding_digest: identity.runtime_binding_digest.clone(),
            capability_id: capability.capability_id.clone(),
            capability_generation: capability.capability_generation,
            registration_digest: capability.registration_digest.clone(),
            operation: capability.operation.clone(),
            execution_class: match capability.execution_class {
                ExecutionClass::Pure => "PURE",
                ExecutionClass::Read => "READ",
                ExecutionClass::Mutation => "MUTATION",
                ExecutionClass::Critical => "CRITICAL",
            }
            .into(),
            args_digest: identity.args_digest.clone(),
            route_digest: capability.route_digest.clone(),
            admission_id: identity.admission_id.clone(),
            policy_version: identity.policy_version.clone(),
            policy_epoch: identity.policy_epoch.clone(),
            provider_request_id: Some("provider-1".into()),
            final_state: ExecutionState::Committed,
            started_at_unix_ms: 1,
            finished_at_unix_ms: 2,
            evidence_digest: "receipt-evidence".into(),
        }
    }

    fn runtime() -> RuntimeIdentity {
        RuntimeIdentity {
            principal_id: "alice".into(),
            tenant_id: Some("tenant".into()),
            runtime_id: "runtime-1".into(),
            environment: "test".into(),
            session_id: None,
        }
    }

    fn registry(class: ExecutionClass) -> CapabilityRegistry {
        let mut registry = CapabilityRegistry::new();
        registry
            .register(
                CapabilityDefinition {
                    capability_id: "capability.test".into(),
                    capability_generation: 7,
                    registration_digest: "registration-7".into(),
                    execution_class: class,
                    operation: "test".into(),
                    route_digest: "route-7".into(),
                    admission_id: "admission-7".into(),
                    policy_version: "policy-7".into(),
                    policy_epoch: "epoch-7".into(),
                    admitted: true,
                },
                |args: &Json| {
                    args.get("value")
                        .is_some()
                        .then_some(())
                        .ok_or_else(|| "value is required".to_owned())
                },
            )
            .expect("test capability should register");
        registry
    }

    fn invocation() -> InvocationRequest {
        InvocationRequest {
            capability_id: "capability.test".into(),
            args: json!({"value": 1}),
            trace_id: Some("trace-1".into()),
            request_id: Some("test-request".into()),
        }
    }

    fn invocation_with_request_id(request_id: &str) -> InvocationRequest {
        InvocationRequest {
            request_id: Some(request_id.into()),
            ..invocation()
        }
    }

    type TestKernel = Kernel<TestAuthority, TestBackend, TestBackend, TestEffectStore>;
    type TestKernelParts = (
        TestKernel,
        TestAuthority,
        TestBackend,
        TestBackend,
        TestActionStore,
        TestReceiptStore,
    );

    fn kernel(class: ExecutionClass, decision: Decision) -> TestKernelParts {
        let authority = TestAuthority {
            decision,
            calls: Arc::new(AtomicUsize::new(0)),
        };
        let function = TestBackend::default();
        let effect = TestBackend::default();
        let actions = TestActionStore::default();
        let receipts = TestReceiptStore::default();
        let effects = TestEffectStore {
            actions: actions.clone(),
            receipts: receipts.clone(),
            ..TestEffectStore::default()
        };
        let kernel = Kernel::new_development(
            runtime(),
            registry(class),
            BackendRouter::new(authority.clone(), function.clone(), effect.clone()),
            effects,
        )
        .expect("development kernel");
        (kernel, authority, function, effect, actions, receipts)
    }

    #[test]
    fn fast_paths_bypass_authority_and_effect_stores() {
        let (kernel, authority, function, effect, actions, receipts) =
            kernel(ExecutionClass::Read, Decision::Allow);
        assert!(matches!(
            kernel.begin(&invocation()),
            Ok(InvocationOutcome::Completed(_))
        ));
        assert_eq!(authority.calls.load(Ordering::SeqCst), 0);
        assert_eq!(function.calls.load(Ordering::SeqCst), 1);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 0);
        assert_eq!(actions.prepare_calls.load(Ordering::SeqCst), 0);
        assert!(receipts.receipts.lock().unwrap().is_empty());
    }

    #[test]
    fn invalid_runtime_identity_is_rejected_before_any_execution() {
        let (mut runtime, read_registry, router, effects) = {
            let authority = TestAuthority {
                decision: Decision::Allow,
                calls: Arc::new(AtomicUsize::new(0)),
            };
            (
                runtime(),
                registry(ExecutionClass::Read),
                BackendRouter::new(authority, TestBackend::default(), TestBackend::default()),
                TestEffectStore::default(),
            )
        };
        runtime.tenant_id = Some(" ".into());
        assert!(
            matches!(
                Kernel::new_development(runtime.clone(), read_registry, router, effects),
                Err(KernelError::RuntimeIdentityInvalid(_))
            ),
            "an ambiguous identity must be rejected at composition time"
        );

        // Composition is not the only guard: binding re-validates, so even a
        // kernel assembled through the raw test constructor cannot execute a
        // consequential action under an ambiguous identity.
        let kernel = Kernel::new_unchecked_for_tests(
            runtime,
            registry(ExecutionClass::Read)
                .seal()
                .expect("seal registry"),
            BackendRouter::new(
                TestAuthority {
                    decision: Decision::Allow,
                    calls: Arc::new(AtomicUsize::new(0)),
                },
                TestBackend::default(),
                TestBackend::default(),
            ),
            TestEffectStore::default(),
        );
        assert!(matches!(
            kernel.begin(&invocation()),
            Err(KernelError::RuntimeIdentityInvalid(_))
        ));
    }

    #[test]
    fn consequential_actions_prepare_verify_and_persist_bound_receipts() {
        let (kernel, authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        assert!(matches!(
            kernel.begin(&invocation()),
            Ok(InvocationOutcome::Completed(_))
        ));
        assert_eq!(authority.calls.load(Ordering::SeqCst), 2);
        assert_eq!(actions.prepare_calls.load(Ordering::SeqCst), 1);
        assert_eq!(
            actions.renew_calls.load(Ordering::SeqCst),
            1,
            "the kernel renews its fenced dispatch lease immediately before backend execution"
        );
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
        assert_eq!(receipts.receipts.lock().unwrap().len(), 1);
        let state = actions.states.lock().unwrap().values().copied().next();
        assert_eq!(state, Some(ExecutionState::Committed));
    }

    #[test]
    fn remaining_action_budget_is_none_once_the_deadline_has_passed() {
        let now = chrono::Utc::now().timestamp_millis().max(0) as u64;

        assert!(remaining_action_budget(0).is_none());
        assert!(remaining_action_budget(now.saturating_sub(1)).is_none());
        assert!(remaining_action_budget(now).is_none());
    }

    #[test]
    fn remaining_action_budget_reports_what_is_left() {
        let now = chrono::Utc::now().timestamp_millis().max(0) as u64;

        let remaining = remaining_action_budget(now.saturating_add(5_000))
            .expect("a future deadline has budget left");

        // The clock moves between the two calls, so assert a window rather than
        // an exact value.
        assert!(remaining <= Duration::from_millis(5_000), "{remaining:?}");
        assert!(remaining > Duration::from_millis(4_000), "{remaining:?}");
    }

    #[test]
    fn development_composition_rejects_a_production_identity() {
        // Without this, a caller could hold a production identity and still
        // compose through the development constructor, which skips production
        // admission. The profile has to be enforced where the kernel is built,
        // not only where the runtime configuration is built.
        let mut production = runtime();
        production.environment = "production".into();
        let result = Kernel::new_development(
            production,
            registry(ExecutionClass::Mutation),
            BackendRouter::new(
                TestAuthority {
                    decision: Decision::Allow,
                    calls: Arc::new(AtomicUsize::new(0)),
                },
                TestBackend::default(),
                TestBackend::default(),
            ),
            TestEffectStore::default(),
        );
        assert!(matches!(
            result,
            Err(KernelError::DevelopmentEnvironmentMismatch)
        ));
    }

    #[test]
    fn kernel_runs_against_the_reference_effect_store_as_one_contract() {
        let authority = TestAuthority {
            decision: Decision::Allow,
            calls: Arc::new(AtomicUsize::new(0)),
        };
        let effect = TestBackend::default();
        let effects = nemo_relay_ledger::unstable::InMemoryEffectStore::with_clock(
            ManualStoreClock::new(1_000),
            LeaseConfiguration::default(),
        );
        let kernel = Kernel::new_development(
            runtime(),
            registry(ExecutionClass::Mutation),
            BackendRouter::new(authority, TestBackend::default(), effect.clone()),
            effects.clone(),
        )
        .expect("development kernel");
        assert!(matches!(
            kernel.begin(&invocation_with_request_id("reference-store-kernel")),
            Ok(InvocationOutcome::Completed(_))
        ));
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
        let action = effects
            .load_action(&effect.requests.lock().unwrap()[0].identity.action_id)
            .unwrap()
            .expect("reference action store retains the claimed action");
        assert_eq!(action.state, ExecutionState::Committed);
        assert!(matches!(
            action.terminal_evidence,
            Some(TerminalEvidence::Receipt(_))
        ));
        assert!(
            effects
                .receipt(&action.preparation.action_id)
                .unwrap()
                .is_some()
        );
        assert!(
            effects
                .conflicts(&action.preparation.action_id)
                .unwrap()
                .is_empty()
        );
    }

    #[test]
    fn stable_request_id_prevents_duplicate_dispatch_after_kernel_restart() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        let request = invocation_with_request_id("stable-request-1");
        assert!(matches!(
            kernel.begin(&request),
            Ok(InvocationOutcome::Completed(_))
        ));
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);

        let authority = TestAuthority {
            decision: Decision::Allow,
            calls: Arc::new(AtomicUsize::new(0)),
        };
        let second_effect = TestBackend::default();
        let restarted = Kernel::new_development(
            runtime(),
            registry(ExecutionClass::Mutation),
            BackendRouter::new(authority, TestBackend::default(), second_effect.clone()),
            TestEffectStore {
                actions: actions.clone(),
                receipts,
                ..TestEffectStore::default()
            },
        )
        .expect("development kernel");
        let existing = match restarted.begin(&request) {
            Ok(InvocationOutcome::ExistingAction(existing)) => existing,
            _ => panic!("expected the original completed action"),
        };
        assert_eq!(existing.state, ExecutionState::Committed);
        assert!(existing.receipt.is_some());
        assert_eq!(second_effect.calls.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn stable_request_id_rejects_a_different_effect_fingerprint() {
        let (kernel, _authority, _function, effect, _actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        let first = invocation_with_request_id("stable-request-2");
        assert!(matches!(
            kernel.begin(&first),
            Ok(InvocationOutcome::Completed(_))
        ));
        let conflicting = InvocationRequest {
            args: json!({"value": 2}),
            ..invocation_with_request_id("stable-request-2")
        };
        assert!(matches!(
            kernel.begin(&conflicting),
            Err(KernelError::IdempotencyConflict)
        ));
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn ambiguous_dispatch_is_persisted_as_unknown_then_reconciled() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: Some("provider-unknown-1".into()),
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let action_id = match kernel.begin(&invocation()) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected structured unknown effect outcome"),
        };
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );

        let result = kernel
            .reconcile(&action_id)
            .expect("reconciliation should consume exact stored action identity");
        assert_eq!(result.state, ExecutionState::Committed);
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Committed)
        );
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
        assert_eq!(receipts.receipts.lock().unwrap().len(), 1);
    }

    #[test]
    fn retry_of_an_unknown_action_returns_its_reconciliation_handle_without_redispatch() {
        let (kernel, _authority, _function, effect, _actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let request = invocation_with_request_id("unknown-retry");
        let action_id = match kernel.begin(&request) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown effect"),
        };
        let existing = match kernel.begin(&request) {
            Ok(InvocationOutcome::ExistingAction(status)) => status,
            _ => panic!("retry must return the existing unknown action"),
        };
        assert_eq!(existing.action_id, action_id);
        assert_eq!(existing.state, ExecutionState::Unknown);
        assert!(existing.reconciliation_required);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn a_plugin_failure_that_may_have_dispatched_is_unknown_and_is_never_redispatched() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        // The shape a managed call returns when a remote registration entered
        // the backend and the answer was lost: nobody can say the plugin did not
        // reach the external system.
        let plugin_failure = nemo_relay::error::FlowError::PluginInvocation {
            registration: "resize-image".into(),
            failure: nemo_relay_plugin_protocol::PluginFailure {
                code: nemo_relay_plugin_protocol::PluginFailureCode::HostCrashed,
                message: "the host exited while the call was in flight".into(),
            },
            dispatch: nemo_relay_executor::unstable::DispatchState::DispatchAttempted,
            certainty: OutcomeCertainty::Unknown,
        };
        *effect.effect_error.lock().unwrap() = Some(
            plugin_failure_as_effect_error(&plugin_failure)
                .expect("a plugin invocation failure describes an effect"),
        );

        let request = invocation_with_request_id("plugin-post-dispatch");
        let action_id = match kernel.begin(&request) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("a plugin that may have dispatched cannot be a definite failure"),
        };
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );
        assert_eq!(
            effect.calls.load(Ordering::SeqCst),
            1,
            "the plugin ran exactly once"
        );

        let existing = match kernel.begin(&request) {
            Ok(InvocationOutcome::ExistingAction(status)) => status,
            _ => panic!("a retry of an unknown action must not reach the plugin"),
        };
        assert_eq!(existing.action_id, action_id);
        assert_eq!(existing.state, ExecutionState::Unknown);
        assert!(existing.reconciliation_required);
        assert_eq!(
            effect.calls.load(Ordering::SeqCst),
            1,
            "an action whose plugin may have dispatched is never dispatched again"
        );
    }

    #[test]
    fn a_plugin_refusal_before_the_backend_is_a_definite_failure_rather_than_an_unknown() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        // The other half of the same boundary: the runtime refused the call
        // before the plugin ran, which is the one plugin failure that *is* a
        // definite outcome.
        let plugin_refusal = nemo_relay::error::FlowError::PluginInvocation {
            registration: "resize-image".into(),
            failure: nemo_relay_plugin_protocol::PluginFailure {
                code: nemo_relay_plugin_protocol::PluginFailureCode::Unavailable,
                message: "no host is serving this registration".into(),
            },
            dispatch: nemo_relay_executor::unstable::DispatchState::NotDispatched,
            certainty: OutcomeCertainty::ConfirmedFailure,
        };
        *effect.effect_error.lock().unwrap() = Some(
            plugin_failure_as_effect_error(&plugin_refusal)
                .expect("a plugin invocation failure describes an effect"),
        );

        let action_id = match kernel.begin(&invocation_with_request_id("plugin-refused")) {
            Err(KernelError::EffectFailed { action, .. }) => {
                assert_eq!(action.state, ExecutionState::Failed);
                action.action_id
            }
            _ => panic!("a refusal before the backend is a definite failure"),
        };
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Failed)
        );
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
    }

    /// The two halves of the effect-boundary contract that a kernel test cannot
    /// see: an error that is not a plugin failure is left alone, and the flag a
    /// durable reader uses is derived from the state rather than asserted
    /// separately.
    #[test]
    fn only_a_plugin_failure_is_translated_and_its_reconciliation_flag_follows_certainty() {
        assert!(
            plugin_failure_as_effect_error(&nemo_relay::error::FlowError::Internal("other".into()))
                .is_none(),
            "an error the plugin boundary did not produce has no effect-boundary meaning here"
        );

        let dispatch_attempted = nemo_relay::error::FlowError::PluginInvocation {
            registration: "resize-image".into(),
            failure: nemo_relay_plugin_protocol::PluginFailure {
                code: nemo_relay_plugin_protocol::PluginFailureCode::MalformedResponse,
                message: "the answer could not be decoded".into(),
            },
            dispatch: nemo_relay_executor::unstable::DispatchState::DispatchAttempted,
            certainty: OutcomeCertainty::Unknown,
        };
        let translated = plugin_failure_as_effect_error(&dispatch_attempted)
            .expect("a plugin invocation failure describes an effect");
        assert_eq!(translated.code, "PLUGIN_DISPATCH_UNATTESTED");
        assert!(translated.reconciliation_required);
        assert!(!translated.retryable);
        assert_eq!(
            translated.dispatch_state,
            nemo_relay_executor::unstable::DispatchState::DispatchAttempted
        );

        let refused = nemo_relay::error::FlowError::PluginInvocation {
            registration: "resize-image".into(),
            failure: nemo_relay_plugin_protocol::PluginFailure {
                code: nemo_relay_plugin_protocol::PluginFailureCode::Rejected,
                message: "the registration was refused".into(),
            },
            dispatch: nemo_relay_executor::unstable::DispatchState::NotDispatched,
            certainty: OutcomeCertainty::ConfirmedFailure,
        };
        let translated = plugin_failure_as_effect_error(&refused)
            .expect("a plugin invocation failure describes an effect");
        assert_eq!(translated.code, "PLUGIN_REFUSED_BEFORE_BACKEND");
        assert!(!translated.reconciliation_required);
    }

    #[test]
    fn mismatched_grants_cancel_the_pre_dispatch_action() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::MismatchedGrant);
        let rejected = match kernel.begin(&invocation()) {
            Err(KernelError::ActionRejected { action, cause }) => (action, cause),
            _ => panic!("a grant verification failure should cancel the proposed action"),
        };
        assert_eq!(rejected.0.state, ExecutionState::Cancelled);
        assert!(matches!(
            rejected.1,
            ActionRejectionCause::GrantVerificationFailed(_)
        ));
        assert_eq!(actions.prepare_calls.load(Ordering::SeqCst), 1);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 0);
        assert!(receipts.receipts.lock().unwrap().is_empty());
    }

    #[test]
    fn runtime_environment_and_session_binding_are_grant_bound() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::MismatchedRuntimeBinding);
        let action = match kernel.begin(&invocation_with_request_id("runtime-binding")) {
            Err(KernelError::ActionRejected { action, cause }) => {
                assert!(matches!(
                    cause,
                    ActionRejectionCause::GrantVerificationFailed(_)
                ));
                action
            }
            _ => panic!("a mismatched runtime binding must cancel before dispatch"),
        };
        assert_eq!(action.state, ExecutionState::Cancelled);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 0);
        assert_eq!(
            actions.load_state(&action.action_id).unwrap(),
            Some(ExecutionState::Cancelled)
        );
    }

    #[test]
    fn approval_resume_preserves_the_same_bound_action() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Critical, Decision::ApproveOnContinuation);
        let pending = match kernel
            .begin(&invocation())
            .expect("approval should be pending")
        {
            InvocationOutcome::PendingApproval(pending) => pending,
            InvocationOutcome::Completed(_) => panic!("critical action should await approval"),
            InvocationOutcome::ExistingAction(_) => {
                panic!("first critical action should not already exist")
            }
        };
        let action_id = pending.action_id().to_owned();
        let idempotency_key = pending.idempotency_key().to_owned();
        assert_eq!(pending.status().next_action, ActionNextStep::AwaitApproval);
        assert_eq!(actions.prepare_calls.load(Ordering::SeqCst), 1);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 0);

        let result = kernel.resume(
            pending,
            ApprovalContinuation {
                approval_reference: "approval-1".into(),
            },
        );
        assert!(matches!(result, Ok(InvocationOutcome::Completed(_))));
        let request = effect.requests.lock().unwrap().pop().unwrap();
        assert_eq!(request.identity.action_id, action_id);
        assert_eq!(request.identity.idempotency_key, idempotency_key);
        assert_eq!(
            request.identity.approval_reference.as_deref(),
            Some("approval-1")
        );
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
        assert_eq!(receipts.receipts.lock().unwrap().len(), 1);
    }

    #[test]
    fn durable_approval_resume_rebinds_the_original_action_after_restart() {
        let (kernel, _authority, _function, _effect, actions, receipts) =
            kernel(ExecutionClass::Critical, Decision::ApproveOnContinuation);
        let request = invocation_with_request_id("durable-approval-resume");
        let action_id = match kernel.begin(&request).expect("approval should be pending") {
            InvocationOutcome::PendingApproval(pending) => pending.action_id().to_owned(),
            _ => panic!("critical action should await approval"),
        };
        let resumed_effect = TestBackend::default();
        let resumed = Kernel::new_development(
            runtime(),
            registry(ExecutionClass::Critical),
            BackendRouter::new(
                TestAuthority {
                    decision: Decision::ApproveOnContinuation,
                    calls: Arc::new(AtomicUsize::new(0)),
                },
                TestBackend::default(),
                resumed_effect.clone(),
            ),
            TestEffectStore {
                actions,
                receipts,
                ..TestEffectStore::default()
            },
        )
        .expect("development kernel");
        assert!(matches!(
            resumed.resume_approval(
                &action_id,
                &request,
                ApprovalContinuation {
                    approval_reference: "approval-after-restart".into(),
                },
            ),
            Ok(InvocationOutcome::Completed(_))
        ));
        assert_eq!(resumed_effect.calls.load(Ordering::SeqCst), 1);
        assert_eq!(
            resumed_effect.requests.lock().unwrap()[0]
                .identity
                .action_id,
            action_id
        );
    }

    #[test]
    fn authorized_and_prepared_actions_resume_without_a_new_action_identity() {
        for state in [ExecutionState::Authorized, ExecutionState::Prepared] {
            let (kernel, _authority, _function, effect, actions, _receipts) =
                kernel(ExecutionClass::Mutation, Decision::Allow);
            let request = invocation_with_request_id(match state {
                ExecutionState::Authorized => "resume-authorized",
                ExecutionState::Prepared => "resume-prepared",
                _ => unreachable!(),
            });
            let bound = kernel.bind(&request).expect("request should bind");
            let action_id = bound.backend_request().identity.action_id.clone();
            actions
                .claim_action(&bound.action_preparation())
                .expect("action should claim");
            {
                let mut records = actions.records.lock().unwrap();
                let record = records.get_mut(&action_id).unwrap();
                record.state = state;
                record.preparation.grant_digest = Some("prior-grant".into());
            }
            actions
                .states
                .lock()
                .unwrap()
                .insert(action_id.clone(), state);
            assert!(matches!(
                kernel.begin(&request),
                Ok(InvocationOutcome::Completed(_))
            ));
            assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
            assert_eq!(
                effect.requests.lock().unwrap()[0].identity.action_id,
                action_id
            );
        }
    }

    #[test]
    fn explicit_denial_and_modification_cancel_the_original_action() {
        let (denied, _authority, _function, denied_effect, denied_actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Deny);
        let denied_status = match denied.begin(&invocation()) {
            Err(KernelError::ActionRejected { action, cause }) => {
                assert_eq!(cause, ActionRejectionCause::AuthorityDenied);
                action
            }
            _ => panic!("explicit denial must cancel the action"),
        };
        assert_eq!(denied_status.state, ExecutionState::Cancelled);
        assert_eq!(denied_status.next_action, ActionNextStep::Terminal);
        assert_eq!(
            denied_actions.load_state(&denied_status.action_id).unwrap(),
            Some(ExecutionState::Cancelled)
        );
        assert_eq!(denied_effect.calls.load(Ordering::SeqCst), 0);

        let (modified, _authority, _function, modified_effect, modified_actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Modify);
        let modified_status = match modified.begin(&invocation_with_request_id("modified")) {
            Err(KernelError::ActionModificationRequired {
                action,
                modification,
            }) => {
                assert_eq!(modification, json!({"max_value": 1}));
                action
            }
            _ => panic!("authority modification must cancel the original action"),
        };
        assert_eq!(modified_status.state, ExecutionState::Cancelled);
        assert_eq!(
            modified_actions
                .load_state(&modified_status.action_id)
                .unwrap(),
            Some(ExecutionState::Cancelled)
        );
        assert_eq!(modified_effect.calls.load(Ordering::SeqCst), 0);

        let (deferred, _authority, _function, deferred_effect, deferred_actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Defer);
        let deferred_status = match deferred.begin(&invocation_with_request_id("deferred")) {
            Err(KernelError::ActionPending { action, cause }) => {
                assert_eq!(cause, ActionPendingCause::AuthorityDeferred);
                action
            }
            _ => panic!("authority defer should remain resumable"),
        };
        assert_eq!(deferred_status.state, ExecutionState::Proposed);
        assert_eq!(deferred_status.next_action, ActionNextStep::RetryAuthority);
        assert_eq!(
            deferred_actions
                .load_state(&deferred_status.action_id)
                .unwrap(),
            Some(ExecutionState::Proposed)
        );
        assert_eq!(deferred_effect.calls.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn schema_failure_happens_before_action_preparation_or_authority() {
        let (kernel, authority, function, effect, actions, _receipts) =
            kernel(ExecutionClass::Critical, Decision::Allow);
        let invalid = InvocationRequest {
            capability_id: "capability.test".into(),
            args: json!({}),
            trace_id: None,
            request_id: Some("test-request".into()),
        };
        assert!(matches!(
            kernel.begin(&invalid),
            Err(KernelError::SchemaValidationFailed(_))
        ));
        assert_eq!(authority.calls.load(Ordering::SeqCst), 0);
        assert_eq!(function.calls.load(Ordering::SeqCst), 0);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 0);
        assert_eq!(actions.prepare_calls.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn consequential_actions_require_a_stable_request_id() {
        let (kernel, authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        let request = InvocationRequest {
            request_id: None,
            ..invocation()
        };
        assert!(matches!(
            kernel.begin(&request),
            Err(KernelError::RequestIdRequired)
        ));
        assert_eq!(authority.calls.load(Ordering::SeqCst), 0);
        assert_eq!(actions.prepare_calls.load(Ordering::SeqCst), 0);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn proposed_action_resumes_with_its_original_action_identity() {
        let (kernel, _authority, _function, _effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::MismatchedGrant);
        let request = invocation_with_request_id("resume-proposed");
        let original = match kernel.begin(&request) {
            Err(KernelError::ActionRejected { action, .. }) => action,
            _ => panic!("grant failure should cancel the action"),
        };
        let resumed_effect = TestBackend::default();
        let resumed = Kernel::new_development(
            runtime(),
            registry(ExecutionClass::Mutation),
            BackendRouter::new(
                TestAuthority {
                    decision: Decision::Allow,
                    calls: Arc::new(AtomicUsize::new(0)),
                },
                TestBackend::default(),
                resumed_effect.clone(),
            ),
            TestEffectStore {
                actions,
                receipts,
                ..TestEffectStore::default()
            },
        )
        .expect("development kernel");
        let existing = match resumed.begin(&request) {
            Ok(InvocationOutcome::ExistingAction(existing)) => existing,
            _ => panic!("cancelled actions must not be re-authorized"),
        };
        assert_eq!(existing.action_id, original.action_id);
        assert_eq!(existing.state, ExecutionState::Cancelled);
        assert_eq!(resumed_effect.calls.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn post_dispatch_receipt_failure_returns_a_reconciliation_handle() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *receipts.fail_store.lock().unwrap() = Some("receipt disk unavailable".into());
        let action = match kernel.begin(&invocation()) {
            Err(KernelError::EffectUnknown { action, .. }) => action,
            _ => panic!("receipt persistence failure must remain unknown"),
        };
        assert_eq!(action.state, ExecutionState::Unknown);
        assert!(action.reconciliation_required);
        assert!(!action.safe_to_retry);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
        assert_eq!(
            actions.load_state(&action.action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );
    }

    #[test]
    fn confirmed_pre_dispatch_failure_returns_the_durable_action_status() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "PROVIDER_REJECTED_BEFORE_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::NotDispatched,
            outcome_certainty: OutcomeCertainty::ConfirmedFailure,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: false,
            message: "provider rejected validation".into(),
        });
        let action = match kernel.begin(&invocation()) {
            Err(KernelError::EffectFailed { action, .. }) => action,
            _ => panic!("terminal effect failure must expose the real action"),
        };
        assert_eq!(action.state, ExecutionState::Failed);
        assert!(!action.safe_to_retry);
        assert!(!action.reconciliation_required);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
        assert_eq!(
            actions.load_state(&action.action_id).unwrap(),
            Some(ExecutionState::Failed)
        );
        assert!(matches!(
            action.terminal_evidence.as_ref(),
            Some(TerminalEvidence::PreDispatchFailure(_))
        ));

        let replay = kernel
            .begin(&invocation())
            .expect("a failed retry should replay the durable action evidence");
        match replay {
            InvocationOutcome::ExistingAction(status) => {
                assert_eq!(status.action_id, action.action_id);
                assert_eq!(status.state, ExecutionState::Failed);
                assert!(matches!(
                    status.terminal_evidence.as_ref(),
                    Some(TerminalEvidence::PreDispatchFailure(_))
                ));
            }
            _ => panic!("failed retry must replay durable terminal evidence"),
        }
        assert_eq!(effect.calls.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn failed_unknown_persistence_returns_state_recovery_with_real_action_id() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: Some("provider-unknown-2".into()),
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        *actions.fail_unknown_transition.lock().unwrap() = Some("action store unavailable".into());
        let recovery = match kernel.begin(&invocation()) {
            Err(KernelError::StateRecoveryRequired {
                action,
                intended_state,
                ..
            }) => (action, intended_state),
            _ => panic!("unknown persistence failure must preserve recovery semantics"),
        };
        assert_eq!(recovery.0.state, ExecutionState::Dispatching);
        assert_eq!(recovery.0.intended_state, Some(ExecutionState::Unknown));
        assert_eq!(recovery.0.next_action, ActionNextStep::RepairEvidence);
        assert_eq!(recovery.1, ExecutionState::Unknown);
        assert!(!recovery.0.safe_to_retry);
    }

    #[test]
    fn stale_fencing_failure_reloads_the_actual_durable_state() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        *actions.persist_unknown_then_fail.lock().unwrap() = Some("stale compare-and-set".into());
        let status = match kernel.begin(&invocation_with_request_id("stale-cas")) {
            Err(KernelError::StateRecoveryRequired { action, .. }) => action,
            _ => panic!("stale fencing loss must report recovery"),
        };
        assert_eq!(status.state, ExecutionState::Unknown);
        assert!(status.durable_state_confirmed);
        assert_eq!(status.intended_state, Some(ExecutionState::Unknown));
        assert_eq!(
            actions.load_state(&status.action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );
    }

    #[test]
    fn unsafe_lease_configuration_blocks_dispatch_before_provider_execution() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *actions.lease_configuration.lock().unwrap() = LeaseConfiguration {
            default_duration_ms: 1,
            maximum_duration_ms: 1,
            renewal_enabled: true,
        };
        assert!(matches!(
            kernel.begin(&invocation_with_request_id("lease-too-short")),
            Err(KernelError::LeaseConfiguration(_))
        ));
        assert_eq!(effect.calls.load(Ordering::SeqCst), 0);
        assert_eq!(
            actions.states.lock().unwrap().values().copied().next(),
            Some(ExecutionState::Prepared)
        );
    }

    #[test]
    fn receipt_conflict_stays_structured_and_blocks_evidence_recovery() {
        let (kernel, _authority, _function, _effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        receipts
            .inject_finalization_conflict
            .store(1, Ordering::SeqCst);
        let action = match kernel.begin(&invocation_with_request_id("receipt-conflict")) {
            Err(KernelError::EvidenceIntegrityConflict { action, conflicts }) => {
                assert_eq!(conflicts.len(), 1);
                assert_eq!(
                    conflicts[0].existing.evidence_digest,
                    "conflicting-evidence"
                );
                action
            }
            _ => panic!("receipt conflict must remain a structured integrity outcome"),
        };
        assert_eq!(action.state, ExecutionState::Unknown);
        assert_eq!(action.next_action, ActionNextStep::RepairEvidence);
        assert_eq!(
            receipts.load_conflicts(&action.action_id).unwrap().len(),
            1,
            "conflict history remains available after the reporting worker returns"
        );
        let recovered = kernel.recover(&action.action_id).unwrap();
        assert!(matches!(
            recovered,
            RecoveryDecision::ContradictoryEvidence { ref action, .. }
                if action.next_action == ActionNextStep::RepairEvidence
        ));
        assert_eq!(
            actions.load_state(&action.action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );
    }

    #[test]
    fn persisted_receipt_conflicts_block_provider_reconciliation_before_dispatch() {
        let (kernel, _authority, _function, effect, _actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        receipts
            .inject_finalization_conflict
            .store(1, Ordering::SeqCst);
        let action_id = match kernel.begin(&invocation_with_request_id("conflict-precheck")) {
            Err(KernelError::EvidenceIntegrityConflict { action, .. }) => action.action_id,
            _ => panic!("expected persisted receipt conflict"),
        };
        assert!(matches!(
            kernel.reconcile(&action_id),
            Err(KernelError::EvidenceIntegrityConflict { .. })
        ));
        assert_eq!(
            effect.reconciliation_calls.load(Ordering::SeqCst),
            0,
            "provider reconciliation must not run after immutable evidence conflicts"
        );
    }

    #[test]
    fn unfenced_primary_evidence_is_rejected_before_provider_reconciliation() {
        let (kernel, _authority, _function, effect, _actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let action_id = match kernel.begin(&invocation_with_request_id("receipt-precheck")) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown effect"),
        };
        let request = effect
            .requests
            .lock()
            .unwrap()
            .iter()
            .find(|request| request.identity.action_id == action_id)
            .cloned()
            .expect("effect request should be retained for late evidence");
        receipts
            .finalize(&receipt(&request))
            .expect("late evidence should persist");
        assert!(matches!(
            kernel.reconcile(&action_id),
            Err(KernelError::EvidenceIntegrityFailure { .. })
        ));
        assert_eq!(
            effect.reconciliation_calls.load(Ordering::SeqCst),
            0,
            "provider reconciliation must not run after valid terminal evidence exists"
        );
    }

    #[test]
    fn late_unfenced_receipt_after_reconciliation_lease_fails_closed() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let action_id = match kernel.begin(&invocation_with_request_id("receipt-race")) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown effect"),
        };
        let request = effect
            .requests
            .lock()
            .unwrap()
            .iter()
            .find(|request| request.identity.action_id == action_id)
            .cloned()
            .expect("effect request should be retained for late evidence");
        let barrier = Arc::new(Barrier::new(2));
        *actions.reconciliation_claim_barrier.lock().unwrap() = Some(Arc::clone(&barrier));
        let kernel = Arc::new(kernel);
        let worker = Arc::clone(&kernel);
        let worker_action_id = action_id.clone();
        let reconciliation = std::thread::spawn(move || worker.reconcile(&worker_action_id));

        barrier.wait();
        receipts
            .finalize(&receipt(&request))
            .expect("late evidence should persist while the reconciliation lease is held");
        barrier.wait();

        assert!(matches!(
            reconciliation
                .join()
                .expect("reconciliation worker should not panic"),
            Err(KernelError::EvidenceIntegrityFailure { .. })
        ));
        assert_eq!(
            effect.reconciliation_calls.load(Ordering::SeqCst),
            0,
            "provider reconciliation must not run when evidence appears after lease acquisition"
        );
        assert_eq!(
            actions.renew_calls.load(Ordering::SeqCst),
            1,
            "late evidence avoids a provider reconciliation renewal and never invokes recover"
        );
    }

    #[test]
    fn reconciliation_cannot_commit_without_a_bound_receipt() {
        let (kernel, _authority, _function, effect, _actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let action_id = match kernel.begin(&invocation()) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown effect"),
        };
        *effect.reconciliation_result.lock().unwrap() = Some(ReconciliationResult {
            state: ExecutionState::Committed,
            receipt: None,
        });
        let error = kernel
            .reconcile(&action_id)
            .expect_err("reconciliation must require a receipt to commit");
        assert!(matches!(error, KernelError::EffectUnknown { .. }));
    }

    #[test]
    fn reconciliation_cannot_fail_without_authoritative_evidence() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let action_id = match kernel.begin(&invocation_with_request_id("failed-evidence")) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown effect"),
        };
        *effect.reconciliation_result.lock().unwrap() = Some(ReconciliationResult {
            state: ExecutionState::Failed,
            receipt: None,
        });
        assert!(matches!(
            kernel.reconcile(&action_id),
            Err(KernelError::EffectUnknown { .. })
        ));
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );
    }

    #[test]
    fn reconciliation_receipts_bind_the_original_principal_and_grant() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let action_id = match kernel.begin(&invocation()) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown effect"),
        };
        let request = effect.requests.lock().unwrap()[0].clone();
        let mut wrong_principal = receipt(&request);
        wrong_principal.principal_id = "mallory".into();
        *effect.reconciliation_result.lock().unwrap() = Some(ReconciliationResult {
            state: ExecutionState::Committed,
            receipt: Some(wrong_principal),
        });
        assert!(matches!(
            kernel.reconcile(&action_id),
            Err(KernelError::EffectUnknown { .. })
        ));
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );

        let mut wrong_grant = receipt(&request);
        wrong_grant.grant_digest = "wrong-grant".into();
        *effect.reconciliation_result.lock().unwrap() = Some(ReconciliationResult {
            state: ExecutionState::Committed,
            receipt: Some(wrong_grant),
        });
        assert!(matches!(
            kernel.reconcile(&action_id),
            Err(KernelError::EffectUnknown { .. })
        ));
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );
        let mut wrong_runtime_binding = receipt(&request);
        wrong_runtime_binding.runtime_binding_digest = "wrong-runtime-binding".into();
        *effect.reconciliation_result.lock().unwrap() = Some(ReconciliationResult {
            state: ExecutionState::Committed,
            receipt: Some(wrong_runtime_binding),
        });
        assert!(matches!(
            kernel.reconcile(&action_id),
            Err(KernelError::EffectUnknown { .. })
        ));
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );
        assert!(receipts.receipts.lock().unwrap().is_empty());
    }

    #[test]
    fn recovery_rejects_split_receipt_and_dispatching_state() {
        let (kernel, _authority, _function, _effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        assert!(matches!(
            kernel.begin(&invocation()),
            Ok(InvocationOutcome::Completed(_))
        ));
        let action_id = actions
            .records
            .lock()
            .unwrap()
            .keys()
            .next()
            .cloned()
            .unwrap();
        actions
            .states
            .lock()
            .unwrap()
            .insert(action_id.clone(), ExecutionState::Dispatching);
        actions
            .records
            .lock()
            .unwrap()
            .get_mut(&action_id)
            .unwrap()
            .state = ExecutionState::Dispatching;
        let decision = kernel
            .recover(&action_id)
            .expect("recovery should fail closed");
        assert!(matches!(
            decision,
            RecoveryDecision::ContradictoryEvidence { .. }
        ));
        assert_eq!(receipts.receipts.lock().unwrap().len(), 1);
    }

    #[test]
    fn recovery_marks_stale_dispatching_without_a_receipt_unknown() {
        let (kernel, _authority, _function, _effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        assert!(matches!(
            kernel.begin(&invocation()),
            Ok(InvocationOutcome::Completed(_))
        ));
        let action_id = actions
            .records
            .lock()
            .unwrap()
            .keys()
            .next()
            .cloned()
            .unwrap();
        receipts.receipts.lock().unwrap().clear();
        actions
            .states
            .lock()
            .unwrap()
            .insert(action_id.clone(), ExecutionState::Dispatching);
        actions
            .records
            .lock()
            .unwrap()
            .get_mut(&action_id)
            .unwrap()
            .state = ExecutionState::Dispatching;

        let decision = kernel
            .recover(&action_id)
            .expect("missing receipt must become unknown, not redispatch");
        let status = match decision {
            RecoveryDecision::RecoverUnknown(status) => status,
            other => panic!("expected unknown recovery, got {other:?}"),
        };
        assert_eq!(status.state, ExecutionState::Unknown);
        assert!(status.reconciliation_required);
        assert!(!status.safe_to_retry);
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Unknown)
        );
    }

    #[test]
    fn recovery_rejects_unknown_with_unfenced_primary_evidence() {
        let (kernel, _authority, _function, effect, _actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "RESPONSE_LOST".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response lost".into(),
        });
        let action_id = match kernel.begin(&invocation_with_request_id("late-evidence")) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown action"),
        };
        let request = effect.requests.lock().unwrap().last().cloned().unwrap();
        receipts.finalize(&receipt(&request)).unwrap();

        assert!(matches!(
            kernel.recover(&action_id).unwrap(),
            RecoveryDecision::ContradictoryEvidence { .. }
        ));
    }

    #[test]
    fn recovery_rejects_reconciling_with_unfenced_primary_evidence() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "RESPONSE_LOST".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response lost".into(),
        });
        let action_id = match kernel.begin(&invocation_with_request_id("reconciling-evidence")) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown action"),
        };
        let request = effect.requests.lock().unwrap().last().cloned().unwrap();
        let mut failed = receipt(&request);
        failed.final_state = ExecutionState::Failed;
        failed.evidence_digest = "definite-provider-rejection".into();
        receipts.finalize(&failed).unwrap();
        actions
            .records
            .lock()
            .unwrap()
            .get_mut(&action_id)
            .unwrap()
            .state = ExecutionState::Reconciling;
        actions
            .states
            .lock()
            .unwrap()
            .insert(action_id.clone(), ExecutionState::Reconciling);

        assert!(matches!(
            kernel.recover(&action_id).unwrap(),
            RecoveryDecision::ContradictoryEvidence { .. }
        ));
    }

    #[test]
    fn recovery_reports_contradictory_evidence_without_rewriting_unknown_state() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "RESPONSE_LOST".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response lost".into(),
        });
        let action_id = match kernel.begin(&invocation_with_request_id("contradictory-evidence")) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown action"),
        };
        let request = effect.requests.lock().unwrap().last().cloned().unwrap();
        let mut conflicting = receipt(&request);
        conflicting.args_digest = "other-arguments".into();
        receipts.finalize(&conflicting).unwrap();

        assert!(matches!(
            kernel.recover(&action_id).unwrap(),
            RecoveryDecision::ContradictoryEvidence { .. }
        ));
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Unknown),
            "contradictory evidence must not manufacture a terminal state"
        );
    }

    #[test]
    fn prepared_retry_waits_for_a_live_owner_before_authority_or_cancellation() {
        let (kernel, authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Deny);
        let invocation = invocation_with_request_id("prepared-live-owner");
        let bound = kernel.bind(&invocation).unwrap();
        let action = bound.action_preparation();
        actions.claim_action(&action).unwrap();
        {
            let mut records = actions.records.lock().unwrap();
            let record = records.get_mut(&action.action_id).unwrap();
            record.state = ExecutionState::Prepared;
            record.lease = Some(ActionLease {
                owner_id: "active-dispatcher".into(),
                generation: 1,
                expires_at_unix_ms: chrono::Utc::now()
                    .timestamp_millis()
                    .max(0)
                    .saturating_add(60_000) as u64,
            });
        }
        actions
            .states
            .lock()
            .unwrap()
            .insert(action.action_id.clone(), ExecutionState::Prepared);

        let result = match kernel.begin(&invocation) {
            Err(error) => error,
            Ok(_) => panic!("a live prepared lease must prevent a second invocation"),
        };
        assert!(matches!(
            result,
            KernelError::ActionPending {
                cause: ActionPendingCause::LeaseHeld,
                ..
            }
        ));
        assert_eq!(authority.calls.load(Ordering::SeqCst), 0);
        assert_eq!(effect.calls.load(Ordering::SeqCst), 0);
        assert_eq!(
            actions.load_state(&action.action_id).unwrap(),
            Some(ExecutionState::Prepared)
        );
    }

    #[test]
    fn recovery_and_reconciliation_respect_live_leases_then_recover_stale_owners() {
        let (kernel, _authority, _function, effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let action_id = match kernel.begin(&invocation_with_request_id("lease-fence")) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown effect"),
        };
        let live = actions
            .claim_lease(
                &action_id,
                ExecutionState::Unknown,
                "live-owner",
                Some(60_000),
            )
            .expect("test lease claim should succeed");
        assert!(matches!(live, LeaseAcquireResult::Acquired(_)));
        let pending = kernel
            .reconcile(&action_id)
            .expect_err("live reconciliation owner must fence a second worker");
        let pending_status = match pending {
            KernelError::ActionPending {
                action,
                cause: ActionPendingCause::LeaseHeld,
            } => action,
            _ => panic!("live lease must return a typed wait outcome"),
        };
        assert_eq!(pending_status.next_action, ActionNextStep::WaitForOwner);
        {
            let mut records = actions.records.lock().unwrap();
            records.get_mut(&action_id).unwrap().lease = Some(ActionLease {
                owner_id: "dead-owner".into(),
                generation: 1,
                expires_at_unix_ms: chrono::Utc::now()
                    .timestamp_millis()
                    .max(0)
                    .saturating_sub(1) as u64,
            });
            records.get_mut(&action_id).unwrap().state = ExecutionState::Reconciling;
        }
        actions
            .states
            .lock()
            .unwrap()
            .insert(action_id.clone(), ExecutionState::Reconciling);
        let recovered = kernel
            .recover(&action_id)
            .expect("expired reconciliation lease should recover to unknown");
        let recovered = match recovered {
            RecoveryDecision::RecoverUnknown(status) => status,
            other => panic!("expected unknown recovery, got {other:?}"),
        };
        assert_eq!(recovered.state, ExecutionState::Unknown);
        assert_eq!(recovered.next_action, ActionNextStep::Reconcile);
    }

    #[test]
    fn lease_generation_remains_monotonic_after_a_lease_is_released() {
        let (kernel, _authority, _function, _effect, actions, _receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        let bound = kernel
            .bind(&invocation_with_request_id("monotonic-lease"))
            .expect("request should bind");
        let action = bound.action_preparation();
        actions.claim_action(&action).expect("action should claim");
        {
            let mut records = actions.records.lock().unwrap();
            let record = records.get_mut(&action.action_id).unwrap();
            record.state = ExecutionState::Prepared;
        }
        actions
            .states
            .lock()
            .unwrap()
            .insert(action.action_id.clone(), ExecutionState::Prepared);
        let first = match actions
            .claim_lease(
                &action.action_id,
                ExecutionState::Prepared,
                "first",
                Some(10),
            )
            .expect("first lease should claim")
        {
            LeaseAcquireResult::Acquired(lease) => lease,
            other => panic!("first lease cannot be held: {other:?}"),
        };
        actions
            .transition_with_lease(
                &action.action_id,
                ExecutionState::Prepared,
                &first,
                ExecutionState::Dispatching,
            )
            .expect("first fenced transition should apply");
        actions
            .transition_with_lease(
                &action.action_id,
                ExecutionState::Dispatching,
                &first,
                ExecutionState::Unknown,
            )
            .expect("terminal transition releases the first lease");
        let second = match actions
            .claim_lease(
                &action.action_id,
                ExecutionState::Unknown,
                "second",
                Some(10),
            )
            .expect("second lease should claim")
        {
            LeaseAcquireResult::Acquired(lease) => lease,
            other => panic!("released lease cannot remain held: {other:?}"),
        };
        assert!(second.generation > first.generation);
    }

    #[test]
    fn scoped_idempotency_does_not_cross_tenant_boundaries() {
        let (first, _authority, _function, first_effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        let request = invocation_with_request_id("shared-client-request-id");
        assert!(matches!(
            first.begin(&request),
            Ok(InvocationOutcome::Completed(_))
        ));
        let second_effect = TestBackend::default();
        let mut second_runtime = runtime();
        second_runtime.tenant_id = Some("other-tenant".into());
        let second = Kernel::new_development(
            second_runtime,
            registry(ExecutionClass::Mutation),
            BackendRouter::new(
                TestAuthority {
                    decision: Decision::Allow,
                    calls: Arc::new(AtomicUsize::new(0)),
                },
                TestBackend::default(),
                second_effect.clone(),
            ),
            TestEffectStore {
                actions,
                receipts,
                ..TestEffectStore::default()
            },
        )
        .expect("development kernel");
        assert!(matches!(
            second.begin(&request),
            Ok(InvocationOutcome::Completed(_))
        ));
        assert_eq!(first_effect.calls.load(Ordering::SeqCst), 1);
        assert_eq!(second_effect.calls.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn unknown_actions_reconcile_through_external_effect_fabric() {
        let (kernel, _authority, _function, effect, actions, receipts) =
            kernel(ExecutionClass::Mutation, Decision::Allow);
        *effect.effect_error.lock().unwrap() = Some(EffectExecutionError {
            code: "TRANSPORT_LOST_AFTER_DISPATCH".into(),
            dispatch_state: nemo_relay_executor::unstable::DispatchState::DispatchConfirmed,
            outcome_certainty: OutcomeCertainty::Unknown,
            provider_request_id: None,
            retryable: false,
            reconciliation_required: true,
            message: "provider response was lost".into(),
        });
        let action_id = match kernel.begin(&invocation_with_request_id("external-reconcile")) {
            Err(KernelError::EffectUnknown { action, .. }) => action.action_id,
            _ => panic!("expected unknown action"),
        };
        let result = kernel
            .reconcile(&action_id)
            .expect("unknown action should reconcile");
        assert_eq!(result.state, ExecutionState::Committed);
        assert_eq!(
            actions.load_state(&action_id).unwrap(),
            Some(ExecutionState::Committed)
        );
        assert_eq!(receipts.receipts.lock().unwrap().len(), 1);
        assert_eq!(
            actions.renew_calls.load(Ordering::SeqCst),
            2,
            "one dispatch renewal plus one reconciliation renewal proves reconciliation does not call recover first"
        );
    }
}
