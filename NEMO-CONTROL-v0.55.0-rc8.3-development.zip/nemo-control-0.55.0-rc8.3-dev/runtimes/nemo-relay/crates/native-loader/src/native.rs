// SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! Native dynamic plugin loader and host-side ABI adapter.

#[cfg(test)]
use std::cell::Cell;
use std::cell::RefCell;
#[cfg(test)]
use std::collections::HashSet;
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::ffi::c_void;
use std::future::Future;
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::path::{Path, PathBuf};
use std::pin::Pin;
use std::ptr;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, OnceLock, PoisonError, Weak};
use std::task::{Context, Poll};

use futures_util::FutureExt;

use chrono::{DateTime, Utc};
use libloading::{Library, Symbol};
use nemo_relay::api::event::{DataSchema, Event, EventSanitizeFields, LogSeverity};
use nemo_relay::api::llm::{LlmRequest, LlmRequestInterceptOutcome};
use nemo_relay::api::registry::{
    RuntimeRegistrationKind, deregister_conditional_middleware_guardrail,
    list_runtime_registrations, register_conditional_middleware_guardrail,
};
use nemo_relay::api::runtime::{
    ConditionalMiddlewareGuardrailFn, EventMetadataInjectorFn, EventSanitizeFn, EventSubscriberFn,
    LlmCodecIdentity, LlmConditionalFn, LlmExecutionFn, LlmExecutionNextFn, LlmJsonStream,
    LlmRequestInterceptFn, LlmSanitizeRequestContext, LlmSanitizeRequestFn,
    LlmSanitizeResponseContext, LlmSanitizeResponseFn, LlmStreamExecutionFn,
    LlmStreamExecutionNextFn, MiddlewareContinuationContext, ToolConditionalFn, ToolExecutionFn,
    ToolExecutionNextFn, ToolInterceptFn, ToolSanitizeFn,
};
use nemo_relay::api::runtime::{
    ScopeStackHandle, ThreadScopeStackBinding, capture_thread_scope_stack, create_scope_stack,
    current_scope_stack, restore_thread_scope_stack, scope_stack_active, set_thread_scope_stack,
    sync_thread_scope_stack, with_scope_stack,
};
use nemo_relay::api::scope::{
    EmitMarkEventParams, PopScopeParams, PushScopeParams, ScopeAttributes, ScopeHandle, ScopeType,
};
use nemo_relay::api::scope::{event as emit_scope_mark, get_handle, pop_scope, push_scope};
use nemo_relay::api::tool::{ToolExecutionInterceptOutcome, ToolExecutionResult};
use nemo_relay::codec::request::AnnotatedLlmRequest;
use nemo_relay::codec::traits::{LlmCodec, LlmResponseCodec};
use nemo_relay::error::{FlowError, Result as FlowResult};
use nemo_relay::plugin::{
    ConfigDiagnostic, DiagnosticLevel, Plugin, PluginError, PluginRegistration,
    PluginRegistrationContext,
};

use nemo_relay_native_abi::{
    NEMO_RELAY_NATIVE_ABI_VERSION, NEMO_RELAY_NATIVE_ABI_VERSION_COMPLETION_CODECS,
    NEMO_RELAY_NATIVE_ABI_VERSION_LEGACY, NemoRelayNativeAsyncCallbackState,
    NemoRelayNativeAsyncCompletion, NemoRelayNativeAsyncLlmStreamOpenCb,
    NemoRelayNativeAsyncLlmStreamPullCb, NemoRelayNativeAsyncMiddlewareCb,
    NemoRelayNativeAsyncMiddlewareKind, NemoRelayNativeAsyncNext, NemoRelayNativeAsyncNextResultCb,
    NemoRelayNativeAsyncNextStreamCb, NemoRelayNativeAsyncStream,
    NemoRelayNativeAsyncStreamMiddlewareCb, NemoRelayNativeConditionalMiddlewareCb,
    NemoRelayNativeEventSanitizeCb, NemoRelayNativeEventSubscriberCb, NemoRelayNativeFreeFn,
    NemoRelayNativeHostApiV1, NemoRelayNativeHostApiV3, NemoRelayNativeHostApiV4,
    NemoRelayNativeHostApiV5, NemoRelayNativeLlmAsyncStream, NemoRelayNativeLlmCodecKind,
    NemoRelayNativeLlmConditionalCb, NemoRelayNativeLlmExecutionCb, NemoRelayNativeLlmRequestCodec,
    NemoRelayNativeLlmRequestInterceptCb, NemoRelayNativeLlmResponseCodec,
    NemoRelayNativeLlmSanitizeRequestCb, NemoRelayNativeLlmSanitizeRequestContext,
    NemoRelayNativeLlmSanitizeResponseCb, NemoRelayNativeLlmSanitizeResponseContext,
    NemoRelayNativeLlmStreamExecutionCb, NemoRelayNativeLlmStreamV1, NemoRelayNativeMarkWindow,
    NemoRelayNativePluginContext, NemoRelayNativePluginEntry, NemoRelayNativePluginRuntime,
    NemoRelayNativePluginV1, NemoRelayNativeScopeHandle, NemoRelayNativeScopeStack,
    NemoRelayNativeScopeStackBinding, NemoRelayNativeScopeType, NemoRelayNativeString,
    NemoRelayNativeToolConditionalCb, NemoRelayNativeToolExecutionCb, NemoRelayNativeToolJsonCb,
    NemoRelayNativeWithScopeStackCb, NemoRelayStatus,
};
use serde_json::{Map, Value as Json};
use tokio::runtime::Runtime;
use tokio_stream::{Stream, StreamExt};
use uuid::Uuid;

use nemo_relay::plugin::dynamic::{
    ApprovedPluginArtifact, DYNAMIC_PLUGIN_MANIFEST_FILENAME, DynamicPluginKind,
    DynamicPluginManifest, DynamicPluginManifestLoad, NativeHostRuntime, RegistrationTeardown,
};
use nemo_relay_plugin_protocol::PluginArtifactIdentity;

/// The runtime this host participates in.
///
/// The handle carries nothing — it is the name of the kernel services a hosted
/// plugin may use — so the loader asks the runtime of the process it is running
/// in, which is the runtime whose registry, invocation and artifact decisions its
/// callbacks act on. Every kernel-touching operation below goes through it.
fn host_runtime() -> NativeHostRuntime {
    NativeHostRuntime::new()
}

/// An artifact whose bytes this side has approved.
///
/// Native plugin load request derived from host dynamic-plugin state.
///
/// Built through one of the constructors below and nowhere else, so that a load
/// says out loud which kind of load it is. The approval is private for that
/// reason: a caller cannot assemble a spec out of parts and leave the approval
/// out, because leaving it out is a thing one has to write.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NativePluginLoadSpec {
    /// Expected plugin kind.
    pub plugin_id: String,
    /// Path to the authored `relay-plugin.toml`.
    pub manifest_ref: String,
    /// The artifact this load is allowed to open, when anything was approved.
    approval: Option<ApprovedPluginArtifact>,
    /// The restricted process host may load its verified container-owned copy
    /// in place; the service retains that staged artifact for the session.
    load_approved_in_place: bool,
}

impl NativePluginLoadSpec {
    /// Build a spec whose artifact this side approves.
    ///
    /// The approval is computed here, before any load, so the caller cannot
    /// forget it: an artifact whose identity cannot be computed is one that
    /// cannot be approved, and that is a failure rather than a load without a
    /// guarantee.
    pub fn approved(
        plugin_id: impl Into<String>,
        manifest_ref: impl Into<String>,
    ) -> nemo_relay::plugin::Result<Self> {
        let manifest_ref = manifest_ref.into();
        let artifact = ApprovedPluginArtifact::approve(&manifest_ref)?;
        Ok(Self {
            plugin_id: plugin_id.into(),
            manifest_ref,
            approval: Some(artifact),
            load_approved_in_place: false,
        })
    }

    /// Build a spec around an approval another side made and sent here.
    ///
    /// This is the process boundary's constructor: the side that loads is not
    /// the side that approved, so the digests arrive with the request and the
    /// loader confirms them. It is a production constructor for that reason —
    /// there is nothing weaker about an approval made in the kernel and checked
    /// in the host than one made in the host — and it is separate from
    /// `approved` so that "who decided this artifact was the right one" is not
    /// hidden behind a boolean.
    pub fn with_approved_identity(
        plugin_id: impl Into<String>,
        manifest_ref: impl Into<String>,
        identity: PluginArtifactIdentity,
    ) -> Self {
        Self {
            plugin_id: plugin_id.into(),
            manifest_ref: manifest_ref.into(),
            approval: Some(ApprovedPluginArtifact::from_identity(identity)),
            load_approved_in_place: false,
        }
    }

    /// Build an approval whose bytes already live in this restricted host's
    /// private app container. The authenticated staging service owns the file's
    /// lifetime, so making another copy in the sandbox's temporary directory is
    /// unnecessary and can cross the sandbox's writable boundary.
    pub(crate) fn with_approved_identity_in_place(
        plugin_id: impl Into<String>,
        manifest_ref: impl Into<String>,
        identity: PluginArtifactIdentity,
    ) -> Self {
        Self {
            plugin_id: plugin_id.into(),
            manifest_ref: manifest_ref.into(),
            approval: Some(ApprovedPluginArtifact::from_identity(identity)),
            load_approved_in_place: true,
        }
    }

    /// Build a spec for an artifact nobody approved.
    ///
    /// The loader then falls back to whatever integrity the manifest itself
    /// declares, and to loading the library where it sits rather than from a
    /// staged copy. That is a weaker guarantee and it is meant to read as one:
    /// the loader's own tests use this to exercise what a load does with an
    /// artifact, and no shipped path does. Naming it is deliberate — the field
    /// it fills is private so that omitting approval is always written down.
    pub fn development(plugin_id: impl Into<String>, manifest_ref: impl Into<String>) -> Self {
        Self {
            plugin_id: plugin_id.into(),
            manifest_ref: manifest_ref.into(),
            approval: None,
            load_approved_in_place: false,
        }
    }

    /// What this load is allowed to open, when anything was approved.
    pub fn approval(&self) -> Option<&ApprovedPluginArtifact> {
        self.approval.as_ref()
    }
}

/// Owns native dynamic libraries registered into the plugin registry.
///
/// Dropping this value deregisters the native plugin kinds before unloading
/// their libraries. Clear active plugin configuration before dropping it so
/// runtime callbacks cannot outlive their code.
pub struct NativePluginActivation {
    plugins: Vec<Arc<NativePluginInstance>>,
    plugin_registrations: Vec<(String, u64)>,
}

/// One registration a native plugin made, recorded where it was made.
///
/// The attachment point is known inside the host function that installs the
/// registration and nowhere else: afterwards a registered component is a name
/// in a table, and a table of names cannot say which surface a callback answers
/// on. A host that has to describe its registrations to another process
/// therefore records them as they happen rather than reconstructing them by
/// inspection.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NativePluginRegistration {
    /// The attachment point the plugin registered at.
    pub operation: RuntimeRegistrationKind,
    /// The name the plugin authored.
    pub local_name: String,
    /// The runtime-qualified name, which is what gates match and ordering
    /// applies to.
    pub qualified_name: String,
    /// Priority the registration declared, when its hook carries one.
    pub priority: Option<i32>,
    /// Whether it may break its chain, when its hook carries that.
    pub may_break_chain: Option<bool>,
    /// The registration this one gates, when it is a conditional guardrail.
    pub gated_registration: Option<String>,
}

/// One loaded plugin as the loader knows it.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NativeLoadedPlugin {
    /// The plugin kind this activation registered.
    pub plugin_kind: String,
    /// The compatibility range the manifest declared, when it declared one.
    pub declared_compat: Option<String>,
    /// What its register callback installed, in the order it installed it.
    ///
    /// Empty until the plugin has been asked to register, because native
    /// registration is config-driven: the loader registers a plugin kind at
    /// load time and the callbacks arrive when the runtime initializes the
    /// plugin's components.
    pub registrations: Vec<NativePluginRegistration>,
}

impl NativePluginActivation {
    /// Returns `true` when no native plugins were loaded.
    pub fn is_empty(&self) -> bool {
        self.plugins.is_empty()
    }

    /// Return the plugin kinds this activation registered.
    ///
    /// A backend outside this crate holds the activation as the lifetime guard
    /// for what it loaded, and has to describe those kinds without reaching into
    /// the instances themselves.
    pub fn plugin_kinds(&self) -> Vec<String> {
        self.plugin_registrations
            .iter()
            .map(|(plugin_kind, _)| plugin_kind.clone())
            .collect()
    }

    /// Describe each loaded plugin as the loader actually knows it.
    ///
    /// Returns the registered kind, the compatibility version the plugin's
    /// manifest declares, and the registrations its callbacks made. Nothing
    /// here is inferred: a caller that needs the ABI version negotiated with
    /// the library has to say so, because this activation does not retain it
    /// and reporting the host's maximum instead would invent a guarantee the
    /// plugin never made.
    pub fn loaded_plugins(&self) -> Vec<NativeLoadedPlugin> {
        self.plugins
            .iter()
            .map(|instance| {
                let declared = if instance.relay_compat.trim().is_empty() {
                    None
                } else {
                    Some(instance.relay_compat.clone())
                };
                NativeLoadedPlugin {
                    plugin_kind: instance.plugin_kind.clone(),
                    declared_compat: declared,
                    registrations: instance
                        .registrations
                        .lock()
                        .unwrap_or_else(PoisonError::into_inner)
                        .clone(),
                }
            })
            .collect()
    }

    /// Consumes the activation and deregisters loaded plugin kinds.
    pub fn clear(self) {}

    pub(crate) fn deregister_plugin_kinds_checked(&mut self) -> RegistrationTeardown {
        host_runtime().tear_down(&mut self.plugin_registrations, "native")
    }
}

impl Drop for NativePluginActivation {
    fn drop(&mut self) {
        for (plugin_kind, registration_id) in self.plugin_registrations.iter().rev() {
            let _ = host_runtime().remove_plugin(plugin_kind, *registration_id);
        }
    }
}

/// Loads native dynamic plugins and registers their plugin kinds.
///
/// The returned activation must be kept alive until after active plugin
/// configuration has been cleared.
pub fn load_native_plugins<I>(specs: I) -> nemo_relay::plugin::Result<NativePluginActivation>
where
    I: IntoIterator<Item = NativePluginLoadSpec>,
{
    let mut activation = NativePluginActivation {
        plugins: Vec::new(),
        plugin_registrations: Vec::new(),
    };
    for spec in specs {
        let instance = load_one_native_plugin(&spec)?;
        let plugin_kind = instance.plugin_kind.clone();
        let registration_id = host_runtime().install_plugin(Arc::new(NativePluginAdapter {
            plugin_kind: plugin_kind.clone(),
            allows_multiple_components: instance.allows_multiple_components,
            instance: instance.clone(),
        }))?;
        activation.plugins.push(instance);
        activation
            .plugin_registrations
            .push((plugin_kind, registration_id));
    }
    Ok(activation)
}

struct NativePluginAdapter {
    plugin_kind: String,
    allows_multiple_components: bool,
    instance: Arc<NativePluginInstance>,
}

impl Plugin for NativePluginAdapter {
    fn plugin_kind(&self) -> &str {
        &self.plugin_kind
    }

    fn allows_multiple_components(&self) -> bool {
        self.allows_multiple_components
    }

    fn validate(&self, plugin_config: &Map<String, Json>) -> Vec<ConfigDiagnostic> {
        let plugin = self
            .instance
            .plugin
            .lock()
            .expect("native plugin lock poisoned");
        let Some(validate) = plugin.validate else {
            return vec![];
        };
        clear_native_last_error();
        let Some(config_json) = native_string_from_json(&Json::Object(plugin_config.clone()))
        else {
            return vec![native_error_diagnostic(
                &self.plugin_kind,
                "plugin.native_validate_failed",
                "failed to serialize plugin config",
            )];
        };
        let mut out = ptr::null_mut();
        let status = unsafe { validate(plugin.user_data, config_json, &mut out) };
        unsafe { native_string_free(config_json) };
        if status != NemoRelayStatus::Ok {
            if !out.is_null() {
                unsafe { native_string_free(out) };
            }
            let message = native_last_error_message()
                .unwrap_or_else(|| format!("native validate callback returned {status:?}"));
            return vec![native_error_diagnostic(
                &self.plugin_kind,
                "plugin.native_validate_failed",
                &message,
            )];
        }
        if out.is_null() {
            return vec![];
        }
        let diagnostics = read_native_string(out)
            .ok()
            .and_then(|text| serde_json::from_str::<Vec<ConfigDiagnostic>>(&text).ok())
            .unwrap_or_else(|| {
                vec![native_error_diagnostic(
                    &self.plugin_kind,
                    "plugin.native_validate_failed",
                    "native validate callback returned invalid diagnostics JSON",
                )]
            });
        unsafe { native_string_free(out) };
        diagnostics
    }

    fn register<'a>(
        &'a self,
        plugin_config: &Map<String, Json>,
        ctx: &'a mut PluginRegistrationContext,
    ) -> Pin<Box<dyn Future<Output = nemo_relay::plugin::Result<()>> + Send + 'a>> {
        let plugin_config = plugin_config.clone();
        Box::pin(async move {
            let plugin = self.instance.plugin.lock().map_err(|err| {
                PluginError::Internal(format!("native plugin lock poisoned: {err}"))
            })?;
            let register = plugin.register.ok_or_else(|| {
                PluginError::RegistrationFailed(format!(
                    "native plugin '{}' did not return a register callback",
                    self.plugin_kind
                ))
            })?;
            clear_native_last_error();
            let config_json =
                native_string_from_json(&Json::Object(plugin_config)).ok_or_else(|| {
                    PluginError::RegistrationFailed("failed to serialize plugin config".into())
                })?;
            let mut native_ctx = NativeHostPluginContext {
                ctx: ctx as *mut _,
                instance: self.instance.clone(),
            };
            let status = unsafe {
                register(
                    plugin.user_data,
                    config_json,
                    &mut native_ctx as *mut _ as *mut NemoRelayNativePluginContext,
                )
            };
            unsafe { native_string_free(config_json) };
            if status == NemoRelayStatus::Ok {
                Ok(())
            } else {
                let message = native_last_error_message()
                    .unwrap_or_else(|| format!("native register callback returned {status:?}"));
                Err(PluginError::RegistrationFailed(message))
            }
        })
    }
}

fn native_error_diagnostic(plugin_kind: &str, code: &str, message: &str) -> ConfigDiagnostic {
    ConfigDiagnostic {
        level: DiagnosticLevel::Error,
        code: code.into(),
        component: Some(plugin_kind.into()),
        field: None,
        message: message.into(),
    }
}

struct NativePluginInstance {
    plugin_kind: String,
    relay_compat: String,
    allows_multiple_components: bool,
    plugin: Mutex<NemoRelayNativePluginV1>,
    /// Where the verified copy this instance was loaded from lives.
    ///
    /// Held so the directory outlives the mapping: the file inside it is the one
    /// `dlopen` opened, and nothing else may write there.
    _staging: Option<StagedArtifact>,
    /// What this plugin's register callbacks installed.
    ///
    /// Written where the attachment point is known — inside each host
    /// registration function — and read when the activation describes itself.
    /// The lock is only ever held to record or clone a `Vec`, so recovering
    /// from a poisoned lock loses nothing: there is no half-updated invariant
    /// to preserve, and refusing to record would silently produce an incomplete
    /// description of what is loaded.
    ///
    /// A plugin's register callbacks can run more than once against one loaded
    /// instance: a session that activates, tears down and activates again runs
    /// them each time, and so does the discovery path that has to know what a
    /// serving activation would refuse. What this holds is therefore the
    /// registrations the instance *currently* has, keyed by attachment point,
    /// rather than a log of everything it ever made — a log would report a
    /// plugin that registered seventeen callbacks as one that registered
    /// thirty-four, and a description that doubles itself is a description no
    /// reader can trust.
    registrations: Mutex<Vec<NativePluginRegistration>>,
    _library: Library,
}

impl NativePluginInstance {
    /// Record one registration the plugin made.
    ///
    /// A second registration at the same attachment point replaces the first:
    /// within one activation the runtime's own registry refuses a name it
    /// already holds, so reaching here twice means the instance was asked to
    /// register again — after a teardown, or for an inspection — and what the
    /// instance has now is what the second call installed.
    fn record_registration(&self, registration: NativePluginRegistration) {
        let mut registrations = self
            .registrations
            .lock()
            .unwrap_or_else(PoisonError::into_inner);
        registrations.retain(|existing| {
            existing.qualified_name != registration.qualified_name
                || existing.operation != registration.operation
        });
        registrations.push(registration);
    }

    /// Drop the records for a registration the plugin removed.
    ///
    /// A gate the plugin registers through its runtime handle can be removed
    /// while the plugin is still loaded, and a description that kept it would
    /// claim a registration that no longer runs.
    fn forget_registration(&self, qualified_name: &str) {
        self.registrations
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .retain(|registration| registration.qualified_name != qualified_name);
    }
}

fn serialize_native_tool_result(result: ToolExecutionResult) -> serde_json::Result<Json> {
    serde_json::to_value(result)
}

fn serialize_native_tool_outcome(
    outcome: ToolExecutionInterceptOutcome,
) -> serde_json::Result<Json> {
    serde_json::to_value(outcome)
}

fn deserialize_native_tool_outcome(
    outcome: Json,
) -> serde_json::Result<ToolExecutionInterceptOutcome> {
    serde_json::from_value(outcome)
}

unsafe impl Send for NativePluginInstance {}
unsafe impl Sync for NativePluginInstance {}

impl Drop for NativePluginInstance {
    fn drop(&mut self) {
        if let Ok(mut plugin) = self.plugin.lock() {
            drop_native_plugin_descriptor(&mut plugin);
        }
    }
}

fn drop_native_plugin_descriptor(plugin: &mut NemoRelayNativePluginV1) {
    if let Some(drop_fn) = plugin.drop.take() {
        unsafe { drop_fn(plugin.user_data) };
        plugin.user_data = ptr::null_mut();
    }
    if !plugin.plugin_kind.is_null() {
        unsafe { native_string_free(plugin.plugin_kind) };
        plugin.plugin_kind = ptr::null_mut();
    }
}

/// A verified copy of a plugin artifact, in a directory private to this account.
///
/// The copy is what gets loaded. A pathname can be repointed between the hash and
/// the `dlopen` that follows it, so the loader never executes the source path: it
/// executes a file this process wrote, in a directory whose mode denies other users
/// and whose name could not be chosen in advance.
///
/// Private to the *account*, not to the process: `0700` denies other users, and a
/// process running under the same account has the same filesystem identity. The
/// threat model this satisfies is a plugin that is trusted but possibly buggy — a
/// hostile process under this account would need the mechanism
/// `stage_verified_library` documents, such as loading through a retained descriptor.
pub(crate) struct StagedArtifact {
    dir: PathBuf,
}

impl std::fmt::Debug for StagedArtifact {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("StagedArtifact")
            .field("dir", &self.dir)
            .finish()
    }
}

impl Drop for StagedArtifact {
    fn drop(&mut self) {
        // Best effort: the library stays mapped after this, which is what makes
        // removing the file safe on the platforms this runs on.
        let _ = std::fs::remove_dir_all(&self.dir);
    }
}

/// Copy a verified artifact into a private directory and return the copy's path.
///
/// The source is read through an open handle so the digest describes an instance
/// rather than a name, and the copy is re-hashed before it is handed back: the
/// bytes that will be loaded are bytes this function has read twice.
///
/// The copy exists because an approved load never executes the approved path: a
/// path can be repointed between the moment it was approved and the moment it is
/// opened, and a copy that no *other user* can write and that nothing can name in
/// advance cannot be. That is the guarantee, stated as what it is: the directory is
/// the load's own, its mode denies other users, and its name is random rather than
/// derived from the digest. It is not a statement about another process running as
/// the same user — Unix permissions do not make that one a boundary, and a threat
/// model that includes a hostile process under this account needs a mechanism this
/// one does not claim, such as loading through a retained descriptor.
pub(crate) fn stage_verified_library(
    library_path: &Path,
    approved_library_sha256: &str,
) -> nemo_relay::plugin::Result<(PathBuf, StagedArtifact)> {
    use std::io::Read;

    let mut source = std::fs::File::open(library_path).map_err(|error| {
        PluginError::NotFound(format!(
            "native plugin library '{}' could not be opened: {error}",
            library_path.display()
        ))
    })?;
    // One handle, read twice: hashing consumes it, so it is rewound rather than
    // cloned — a clone would share the offset and the copy would then start at
    // the end of the file, which is exactly the bug this comment replaces.
    let source_digest = host_runtime().hash_open_file(&mut source)?;
    {
        use std::io::Seek;
        source.seek(std::io::SeekFrom::Start(0)).map_err(|error| {
            PluginError::Internal(format!(
                "failed to rewind '{}': {error}",
                library_path.display()
            ))
        })?;
    }
    if source_digest != approved_library_sha256 {
        return Err(PluginError::RegistrationFailed(format!(
            "native plugin library '{}' hashes to {source_digest}, while \
             {approved_library_sha256} was approved",
            library_path.display()
        )));
    }

    // Nothing another user controls decides where the copy lands: the directory is
    // this load's own, its mode denies other users, and its name is random rather than
    // derived from the digest, so two loads of one artifact cannot land on each other.
    // The digest-derived name this replaces mapped every load of one artifact to one
    // path, which is exactly the case that collides — and a second load truncating the
    // file the first is running from is the collision that matters.
    //
    // The guard is built *before* anything can fail, so every path from here — a failed
    // open, a short read, a write error, a digest that does not match — takes the
    // directory with it. Creating it and returning the guard only at the end left the
    // private directory behind on the paths in between, which is litter rather than a
    // vulnerability, and litter is what a guard removes by construction.
    let guard = StagedArtifact {
        dir: create_staging_directory()?,
    };
    let dir = guard.dir.clone();

    let staged = dir.join("library");
    // Exclusive creation, so a destination that already exists is an error
    // rather than something this load overwrites. The directory is fresh, so
    // this refuses a pre-existing target instead of trusting that there is none.
    let mut options = std::fs::OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    let mut destination = options.open(&staged).map_err(|error| {
        PluginError::Internal(format!(
            "failed to create the staged artifact '{}': {error}",
            staged.display()
        ))
    })?;
    let mut buffer = [0u8; 64 * 1024];
    loop {
        let read = source.read(&mut buffer).map_err(|error| {
            PluginError::Internal(format!(
                "failed to read '{}': {error}",
                library_path.display()
            ))
        })?;
        if read == 0 {
            break;
        }
        std::io::Write::write_all(&mut destination, &buffer[..read]).map_err(|error| {
            PluginError::Internal(format!("failed to write '{}': {error}", staged.display()))
        })?;
    }
    destination.sync_all().map_err(|error| {
        PluginError::Internal(format!("failed to flush '{}': {error}", staged.display()))
    })?;
    drop(destination);
    // The copy is re-hashed from the file that will be loaded rather than from
    // the bytes as they were written: the guarantee is about the artifact the
    // loader opens, and reading it back is how the digests describe the same
    // instance the loader will get rather than the same buffer this loop held.
    let staged_digest = host_runtime().hash_path(&staged)?;
    if staged_digest != approved_library_sha256 {
        return Err(PluginError::RegistrationFailed(format!(
            "the staged copy of '{}' hashes to {staged_digest}, while \
             {approved_library_sha256} was approved",
            library_path.display()
        )));
    }
    Ok((staged, guard))
}

/// Create the private directory one staged artifact lives in.
///
/// The name is random rather than derived from the digest or the process id, and
/// the directory is created exclusively: nothing else can choose the path a load
/// writes into, and nothing can arrange for the path to exist before it does. A
/// digest-derived name under a process-derived root is predictable, which is the
/// property that makes it possible for another process running as the same user
/// to put something there first. A retry is not a workaround for that: the first
/// name is unavailable, so another is chosen rather than reusing it.
fn create_staging_directory() -> nemo_relay::plugin::Result<PathBuf> {
    for _ in 0..16 {
        let dir =
            std::env::temp_dir().join(format!("nemo-native-artifacts-{}", Uuid::new_v4().simple()));
        let mut builder = std::fs::DirBuilder::new();
        #[cfg(unix)]
        {
            use std::os::unix::fs::DirBuilderExt;
            builder.mode(0o700);
        }
        match builder.create(&dir) {
            Ok(()) => return Ok(dir),
            // A name already taken is another load's, not this one's: the next
            // attempt gets a name nobody holds rather than sharing that one.
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(error) => {
                return Err(PluginError::Internal(format!(
                    "failed to create the staging directory '{}': {error}",
                    dir.display()
                )));
            }
        }
    }
    Err(PluginError::Internal(
        "failed to create a private staging directory for a native plugin".to_string(),
    ))
}

fn load_one_native_plugin(
    spec: &NativePluginLoadSpec,
) -> nemo_relay::plugin::Result<Arc<NativePluginInstance>> {
    // The manifest is read once and parsed from the bytes that were hashed, so
    // the identity and the content are the same object rather than two lookups
    // of one path.
    let manifest_path = {
        let path = PathBuf::from(&spec.manifest_ref);
        if path.is_dir() {
            path.join(DYNAMIC_PLUGIN_MANIFEST_FILENAME)
        } else {
            path
        }
    };
    let manifest_bytes = std::fs::read(&manifest_path).map_err(|error| {
        PluginError::NotFound(format!(
            "dynamic plugin manifest '{}' could not be read: {error}",
            manifest_path.display()
        ))
    })?;
    let manifest_sha256 = host_runtime().hash_bytes(&manifest_bytes);
    if let Some(approved) = spec.approval()
        && approved.identity().manifest_sha256 != manifest_sha256
    {
        return Err(PluginError::RegistrationFailed(format!(
            "dynamic plugin '{}' is not the approved artifact: '{}' hashes to \
             {manifest_sha256}, while {} was approved",
            spec.plugin_id,
            manifest_path.display(),
            approved.identity().manifest_sha256
        )));
    }
    let manifest_ref = manifest_path.to_string_lossy().into_owned();
    let manifest = DynamicPluginManifest::parse_toml(
        std::str::from_utf8(&manifest_bytes).map_err(|error| {
            PluginError::InvalidConfig(format!(
                "'{}' is not UTF-8: {error}",
                manifest_path.display()
            ))
        })?,
    )?;
    if manifest.plugin.id.trim() != spec.plugin_id {
        return Err(PluginError::InvalidConfig(format!(
            "dynamic plugin manifest id '{}' does not match expected id '{}'",
            manifest.plugin.id, spec.plugin_id
        )));
    }
    if manifest.plugin.kind != DynamicPluginKind::RustDynamic {
        return Err(PluginError::InvalidConfig(format!(
            "dynamic plugin '{}' is kind {}; native loader only supports rust_dynamic",
            spec.plugin_id, manifest.plugin.kind
        )));
    }
    validate_relay_compatibility(manifest.compat.relay.as_deref())?;
    let relay_compat = manifest
        .compat
        .relay
        .as_deref()
        .expect("validated native manifest must declare compat.relay")
        .to_string();
    if manifest.compat.native_api.as_deref().map(str::trim) != Some("1") {
        return Err(PluginError::InvalidConfig(format!(
            "dynamic plugin '{}' declares unsupported compat.native_api '{}'; expected 1",
            spec.plugin_id,
            manifest.compat.native_api.as_deref().unwrap_or("")
        )));
    }
    let DynamicPluginManifestLoad::RustDynamic(load) = &manifest.load else {
        return Err(PluginError::InvalidConfig(format!(
            "dynamic plugin '{}' has invalid rust_dynamic load contract",
            spec.plugin_id
        )));
    };
    let manifest_path = PathBuf::from(&manifest_ref);
    let library_path = host_runtime().resolve_manifest_relative(
        &manifest_path,
        load.library
            .as_deref()
            .ok_or_else(|| PluginError::InvalidConfig("load.library is required".into()))?,
    );
    if !library_path.exists() {
        return Err(PluginError::NotFound(format!(
            "native plugin library '{}' does not exist",
            library_path.display()
        )));
    }
    if let Some(expected_digest) = manifest
        .integrity
        .as_ref()
        .and_then(|integrity| integrity.sha256.as_deref())
    {
        host_runtime().verify_path(&library_path, expected_digest)?;
    }
    // Ordinary approved loads are copied into private staging. The restricted
    // host instead loads the authenticated container copy in place, then checks
    // the digest again after dlopen. Unapproved development loads retain their
    // existing in-place behavior and post-load check.
    let (library_path, staging) = match spec.approval() {
        Some(approved) if spec.load_approved_in_place => {
            let measured = host_runtime().hash_path(&library_path)?;
            if measured != approved.identity().library_sha256 {
                return Err(PluginError::RegistrationFailed(format!(
                    "the transferred library hashes to {measured}, while {} was approved",
                    approved.identity().library_sha256
                )));
            }
            (library_path.clone(), None)
        }
        Some(approved) => {
            let (staged, guard) =
                stage_verified_library(&library_path, &approved.identity().library_sha256)?;
            (staged, Some(guard))
        }
        None => (library_path.clone(), None),
    };
    let verified_library_sha256 = spec
        .approval()
        .map(|approved| approved.identity().library_sha256.clone());
    let symbol = load
        .symbol
        .as_deref()
        .ok_or_else(|| PluginError::InvalidConfig("load.symbol is required".into()))?;

    let library = unsafe { Library::new(&library_path) }.map_err(|err| {
        PluginError::Internal(format!(
            "failed to load native plugin library '{}': {err}",
            library_path.display()
        ))
    })?;
    // A staged load needs no second look: the file it opened is one this process
    // wrote, in a directory no other user can write. A load with no approved
    // identity still re-checks the path, which is the weaker guarantee it can offer.
    if staging.is_none()
        && let Some(verified) = &verified_library_sha256
    {
        let mapped = host_runtime().hash_path(&library_path)?;
        if &mapped != verified {
            drop(library);
            return Err(PluginError::RegistrationFailed(format!(
                "native plugin library '{}' changed between verification and loading; it is \
                 not the artifact this load approved",
                library_path.display()
            )));
        }
    }
    let mut plugin = NemoRelayNativePluginV1::default();
    unsafe {
        let entry: Symbol<NemoRelayNativePluginEntry> =
            library.get(symbol.as_bytes()).map_err(|err| {
                PluginError::NotFound(format!(
                    "native plugin symbol '{symbol}' not found in '{}': {err}",
                    library_path.display()
                ))
            })?;
        let status = negotiate_plugin_entry(*entry, &mut plugin);
        if status != NemoRelayStatus::Ok {
            drop_native_plugin_descriptor(&mut plugin);
            return Err(PluginError::RegistrationFailed(format!(
                "native plugin entry symbol '{symbol}' failed: {}",
                native_last_error_message().unwrap_or_else(|| format!("{status:?}"))
            )));
        }
    }
    if let Err(err) = validate_plugin_descriptor(&spec.plugin_id, &plugin) {
        drop_native_plugin_descriptor(&mut plugin);
        return Err(err);
    }
    let plugin_kind = match read_native_string(plugin.plugin_kind) {
        Ok(plugin_kind) => plugin_kind,
        Err(err) => {
            drop_native_plugin_descriptor(&mut plugin);
            return Err(err);
        }
    };
    if plugin_kind != spec.plugin_id {
        drop_native_plugin_descriptor(&mut plugin);
        return Err(PluginError::InvalidConfig(format!(
            "native plugin returned kind '{plugin_kind}' but manifest id is '{}'",
            spec.plugin_id
        )));
    }
    Ok(Arc::new(NativePluginInstance {
        plugin_kind,
        relay_compat,
        allows_multiple_components: plugin.allows_multiple_components,
        plugin: Mutex::new(plugin),
        registrations: Mutex::new(Vec::new()),
        _staging: staging,
        _library: library,
    }))
}

fn validate_relay_compatibility(relay: Option<&str>) -> nemo_relay::plugin::Result<()> {
    host_runtime().validate_relay_compatibility(relay, "native")
}

fn validate_plugin_descriptor(
    plugin_id: &str,
    plugin: &NemoRelayNativePluginV1,
) -> nemo_relay::plugin::Result<()> {
    if plugin.struct_size < std::mem::size_of::<NemoRelayNativePluginV1>() {
        return Err(PluginError::InvalidConfig(format!(
            "native plugin '{plugin_id}' returned incompatible plugin descriptor size {}",
            plugin.struct_size
        )));
    }
    if plugin.plugin_kind.is_null() {
        return Err(PluginError::InvalidConfig(format!(
            "native plugin '{plugin_id}' returned a null plugin_kind"
        )));
    }
    if plugin.register.is_none() {
        return Err(PluginError::InvalidConfig(format!(
            "native plugin '{plugin_id}' returned no register callback"
        )));
    }
    Ok(())
}

#[repr(C)]
struct NativeHostPluginContext {
    ctx: *mut PluginRegistrationContext,
    instance: Arc<NativePluginInstance>,
}

struct NativeHostPluginRuntime {
    namespace: String,
    encode_local_names: bool,
    instance: Weak<NativePluginInstance>,
    active: AtomicBool,
    gates: Mutex<HashMap<String, NativeOwnedGate>>,
}

struct NativeOwnedGate {
    local_name: String,
    qualified_name: String,
}

impl NativeHostPluginRuntime {
    fn cleanup(&self) -> nemo_relay::plugin::Result<()> {
        self.active.store(false, Ordering::Release);
        let mut gates = match self.gates.lock() {
            Ok(gates) => gates,
            Err(error) => {
                log::error!(
                    target: "nemo_relay.plugin",
                    event = "native_gate_ownership_lock_poisoned";
                    "Native gate ownership lock was poisoned during cleanup; recovering owned gates"
                );
                error.into_inner()
            }
        };
        let names = gates
            .drain()
            .map(|(_, gate)| gate.qualified_name)
            .collect::<Vec<_>>();
        drop(gates);
        let mut errors = Vec::new();
        for name in names {
            if let Err(error) = deregister_conditional_middleware_guardrail(&name) {
                errors.push(format!("'{name}': {error}"));
            }
        }
        if !errors.is_empty() {
            return Err(PluginError::RegistrationFailed(format!(
                "conditional middleware guardrail deregistration failed: {}",
                errors.join("; ")
            )));
        }
        Ok(())
    }
}

struct NativeHostString(Vec<u8>);

struct NativeHostLlmRequestCodec(Arc<dyn LlmCodec>);
struct NativeHostLlmResponseCodec(Arc<dyn LlmResponseCodec>);

struct NativeHostScopeHandle(ScopeHandle);

struct NativeHostScopeStack(ScopeStackHandle);

struct NativeHostScopeStackBinding(ThreadScopeStackBinding);

thread_local! {
    static NATIVE_LAST_ERROR: RefCell<Option<String>> = const { RefCell::new(None) };
    #[cfg(test)]
    static NATIVE_STRING_LIVE_ALLOCATIONS: RefCell<HashSet<usize>> = RefCell::new(HashSet::new());
    #[cfg(test)]
    static NATIVE_STRING_FAIL_AFTER: Cell<Option<usize>> = const { Cell::new(None) };
}

fn set_native_last_error(message: impl Into<String>) {
    NATIVE_LAST_ERROR.with(|cell| *cell.borrow_mut() = Some(message.into()));
}

fn clear_native_last_error() {
    NATIVE_LAST_ERROR.with(|cell| *cell.borrow_mut() = None);
}

fn native_last_error_message() -> Option<String> {
    NATIVE_LAST_ERROR.with(|cell| cell.borrow().clone())
}

#[cfg(test)]
fn fail_native_string_allocation_after(successful_allocations: usize) {
    NATIVE_STRING_FAIL_AFTER.with(|cell| cell.set(Some(successful_allocations)));
}

#[cfg(test)]
fn native_string_live_allocations() -> usize {
    NATIVE_STRING_LIVE_ALLOCATIONS.with(|allocations| allocations.borrow().len())
}

unsafe extern "C" fn native_string_new(
    data: *const u8,
    len: usize,
    out: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    if out.is_null() {
        set_native_last_error("out string pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    if data.is_null() && len > 0 {
        set_native_last_error("string data pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    let bytes: &[u8] = if len == 0 {
        &[]
    } else {
        unsafe { std::slice::from_raw_parts(data, len) }
    };
    if let Err(err) = std::str::from_utf8(bytes) {
        set_native_last_error(format!("string data is not valid UTF-8: {err}"));
        return NemoRelayStatus::InvalidUtf8;
    }
    #[cfg(test)]
    let should_fail = NATIVE_STRING_FAIL_AFTER.with(|cell| match cell.get() {
        Some(0) => {
            cell.set(None);
            true
        }
        Some(remaining) => {
            cell.set(Some(remaining - 1));
            false
        }
        None => false,
    });
    #[cfg(test)]
    if should_fail {
        set_native_last_error("injected native string allocation failure");
        return NemoRelayStatus::Internal;
    }
    let handle = Box::new(NativeHostString(bytes.to_vec()));
    unsafe { *out = Box::into_raw(handle) as *mut NemoRelayNativeString };
    #[cfg(test)]
    NATIVE_STRING_LIVE_ALLOCATIONS.with(|allocations| {
        allocations.borrow_mut().insert(unsafe { *out } as usize);
    });
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_string_data(value: *const NemoRelayNativeString) -> *const u8 {
    if value.is_null() {
        return ptr::null();
    }
    let value = unsafe { &*(value as *const NativeHostString) };
    value.0.as_ptr()
}

unsafe extern "C" fn native_string_len(value: *const NemoRelayNativeString) -> usize {
    if value.is_null() {
        return 0;
    }
    let value = unsafe { &*(value as *const NativeHostString) };
    value.0.len()
}

unsafe extern "C" fn native_string_free(value: *mut NemoRelayNativeString) {
    if !value.is_null() {
        drop(unsafe { Box::from_raw(value as *mut NativeHostString) });
        #[cfg(test)]
        NATIVE_STRING_LIVE_ALLOCATIONS.with(|allocations| {
            allocations.borrow_mut().remove(&(value as usize));
        });
    }
}

unsafe extern "C" fn native_last_error_clear() {
    clear_native_last_error();
}

unsafe extern "C" fn native_last_error_set(message: *const NemoRelayNativeString) {
    match read_native_string(message) {
        Ok(message) => set_native_last_error(message),
        Err(err) => set_native_last_error(err.to_string()),
    }
}

unsafe extern "C" fn native_llm_request_codec_decode(
    codec: *const NemoRelayNativeLlmRequestCodec,
    request_json: *const NemoRelayNativeString,
    out: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out.is_null() {
        set_native_last_error("request codec decode output pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    if codec.is_null() {
        set_native_last_error("request codec decode capability is null");
        return NemoRelayStatus::NullPointer;
    }
    if request_json.is_null() {
        set_native_last_error("request codec decode request is null");
        return NemoRelayStatus::NullPointer;
    }
    let result = catch_unwind(AssertUnwindSafe(|| -> std::result::Result<_, String> {
        let request: LlmRequest = serde_json::from_str(
            &read_native_string(request_json).map_err(|error| error.to_string())?,
        )
        .map_err(|error| format!("invalid request JSON: {error}"))?;
        let codec = unsafe { &*(codec as *const NativeHostLlmRequestCodec) };
        let annotated = codec
            .0
            .decode(&request)
            .map_err(|error| error.to_string())?;
        let annotated = serde_json::to_value(annotated).map_err(|error| error.to_string())?;
        native_string_from_json(&annotated)
            .ok_or_else(|| "failed to allocate decoded request".to_string())
    }));
    match result {
        Ok(Ok(value)) => {
            unsafe { *out = value };
            NemoRelayStatus::Ok
        }
        Ok(Err(error)) => {
            set_native_last_error(format!("request codec decode failed: {error}"));
            NemoRelayStatus::Internal
        }
        Err(_) => {
            set_native_last_error("request codec decode panicked");
            NemoRelayStatus::Internal
        }
    }
}

unsafe extern "C" fn native_llm_request_codec_encode(
    codec: *const NemoRelayNativeLlmRequestCodec,
    annotated_json: *const NemoRelayNativeString,
    original_json: *const NemoRelayNativeString,
    out: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out.is_null() {
        set_native_last_error("request codec encode output pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    if codec.is_null() {
        set_native_last_error("request codec encode capability is null");
        return NemoRelayStatus::NullPointer;
    }
    if annotated_json.is_null() {
        set_native_last_error("request codec encode annotated request is null");
        return NemoRelayStatus::NullPointer;
    }
    if original_json.is_null() {
        set_native_last_error("request codec encode original request is null");
        return NemoRelayStatus::NullPointer;
    }
    let result = catch_unwind(AssertUnwindSafe(|| -> std::result::Result<_, String> {
        let annotated: AnnotatedLlmRequest = serde_json::from_str(
            &read_native_string(annotated_json).map_err(|error| error.to_string())?,
        )
        .map_err(|error| format!("invalid annotated request JSON: {error}"))?;
        let original: LlmRequest = serde_json::from_str(
            &read_native_string(original_json).map_err(|error| error.to_string())?,
        )
        .map_err(|error| format!("invalid original request JSON: {error}"))?;
        let codec = unsafe { &*(codec as *const NativeHostLlmRequestCodec) };
        let request = codec
            .0
            .encode(&annotated, &original)
            .map_err(|error| error.to_string())?;
        let request = serde_json::to_value(request).map_err(|error| error.to_string())?;
        native_string_from_json(&request)
            .ok_or_else(|| "failed to allocate encoded request".to_string())
    }));
    match result {
        Ok(Ok(value)) => {
            unsafe { *out = value };
            NemoRelayStatus::Ok
        }
        Ok(Err(error)) => {
            set_native_last_error(format!("request codec encode failed: {error}"));
            NemoRelayStatus::Internal
        }
        Err(_) => {
            set_native_last_error("request codec encode panicked");
            NemoRelayStatus::Internal
        }
    }
}

unsafe extern "C" fn native_llm_response_codec_decode(
    codec: *const NemoRelayNativeLlmResponseCodec,
    response_json: *const NemoRelayNativeString,
    out: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out.is_null() {
        set_native_last_error("response codec decode output pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    if codec.is_null() {
        set_native_last_error("response codec decode capability is null");
        return NemoRelayStatus::NullPointer;
    }
    if response_json.is_null() {
        set_native_last_error("response codec decode response is null");
        return NemoRelayStatus::NullPointer;
    }
    let result = catch_unwind(AssertUnwindSafe(|| -> std::result::Result<_, String> {
        let response: Json = serde_json::from_str(
            &read_native_string(response_json).map_err(|error| error.to_string())?,
        )
        .map_err(|error| format!("invalid response JSON: {error}"))?;
        let codec = unsafe { &*(codec as *const NativeHostLlmResponseCodec) };
        let annotated = codec
            .0
            .decode_response(&response)
            .map_err(|error| error.to_string())?;
        let annotated = serde_json::to_value(annotated).map_err(|error| error.to_string())?;
        native_string_from_json(&annotated)
            .ok_or_else(|| "failed to allocate decoded response".to_string())
    }));
    match result {
        Ok(Ok(value)) => {
            unsafe { *out = value };
            NemoRelayStatus::Ok
        }
        Ok(Err(error)) => {
            set_native_last_error(format!("response codec decode failed: {error}"));
            NemoRelayStatus::Internal
        }
        Err(_) => {
            set_native_last_error("response codec decode panicked");
            NemoRelayStatus::Internal
        }
    }
}

fn native_host_api() -> *const NemoRelayNativeHostApiV1 {
    static HOST_API: OnceLock<NemoRelayNativeHostApiV5> = OnceLock::new();
    &HOST_API.get_or_init(build_native_host_api_v5).v4.v3.v1 as *const NemoRelayNativeHostApiV1
}

/// The frozen v4 table, for plugins built against an SDK that stops at v4.
///
/// A plugin that only knows v4 refuses the current table — its own supported range
/// ends before this host's version — and the refusal says nothing about what the
/// two could have agreed on. Offering the version it was built against is what
/// keeps an older plugin working while the current ABI grows, and it is why each
/// older table is frozen rather than derived from the current one.
fn native_host_api_v4() -> *const NemoRelayNativeHostApiV1 {
    static HOST_API: OnceLock<NemoRelayNativeHostApiV4> = OnceLock::new();
    &HOST_API.get_or_init(build_frozen_host_api_v4).v3.v1 as *const NemoRelayNativeHostApiV1
}

/// Call a plugin's entry, offering every table this host can speak.
///
/// A plugin built against an older SDK refuses a table whose version it does not
/// know — its own supported range ends before this host's version — and that refusal
/// says nothing about what the two could have agreed on. The negotiation therefore
/// offers the current table first and then each frozen older one, newest first, so
/// what a plugin is handed is the newest version it was built for.
///
/// The order is the whole of the rule, which is why it is a function with a test of
/// its own rather than a loop inside the loader: getting it wrong is silent, and it
/// is how every already-built plugin would stop loading at once.
fn negotiate_plugin_entry(
    entry: NemoRelayNativePluginEntry,
    plugin: &mut NemoRelayNativePluginV1,
) -> NemoRelayStatus {
    let mut status = unsafe { entry(native_host_api(), plugin) };
    for table in [
        native_host_api_v4(),
        native_host_api_v3(),
        native_host_api_v2(),
    ] {
        if status != NemoRelayStatus::InvalidArg {
            break;
        }
        drop_native_plugin_descriptor(plugin);
        status = unsafe { entry(table, plugin) };
    }
    status
}

fn build_frozen_host_api_v4() -> NemoRelayNativeHostApiV4 {
    let mut v4 = build_native_host_api_v4();
    v4.v3.v1.abi_version = NEMO_RELAY_NATIVE_ABI_VERSION_COMPLETION_CODECS;
    v4.v3.v1.struct_size = std::mem::size_of::<NemoRelayNativeHostApiV4>();
    v4
}

fn native_host_api_v3() -> *const NemoRelayNativeHostApiV1 {
    static HOST_API: OnceLock<NemoRelayNativeHostApiV3> = OnceLock::new();
    &HOST_API.get_or_init(build_native_host_api_v3).v1 as *const NemoRelayNativeHostApiV1
}

fn native_host_api_v2() -> *const NemoRelayNativeHostApiV1 {
    static HOST_API: OnceLock<NemoRelayNativeHostApiV1> = OnceLock::new();
    HOST_API.get_or_init(build_native_host_api_v2) as *const _
}

fn build_native_host_api_v2() -> NemoRelayNativeHostApiV1 {
    static RELAY_VERSION: &[u8] = concat!(env!("CARGO_PKG_VERSION"), "\0").as_bytes();
    NemoRelayNativeHostApiV1 {
        abi_version: NEMO_RELAY_NATIVE_ABI_VERSION_LEGACY,
        struct_size: std::mem::size_of::<NemoRelayNativeHostApiV1>(),
        relay_version: RELAY_VERSION.as_ptr().cast(),
        string_new: native_string_new,
        string_data: native_string_data,
        string_len: native_string_len,
        string_free: native_string_free,
        last_error_clear: native_last_error_clear,
        last_error_set: native_last_error_set,
        llm_request_codec_decode: native_llm_request_codec_decode,
        llm_request_codec_encode: native_llm_request_codec_encode,
        llm_response_codec_decode: native_llm_response_codec_decode,
        plugin_context_register_subscriber: native_plugin_context_register_subscriber,
        plugin_context_register_tool_sanitize_request_guardrail:
            native_plugin_context_register_tool_sanitize_request_guardrail,
        plugin_context_register_tool_sanitize_response_guardrail:
            native_plugin_context_register_tool_sanitize_response_guardrail,
        plugin_context_register_tool_conditional_execution_guardrail:
            native_plugin_context_register_tool_conditional_execution_guardrail,
        plugin_context_register_tool_request_intercept:
            native_plugin_context_register_tool_request_intercept,
        plugin_context_register_tool_execution_intercept:
            native_plugin_context_register_tool_execution_intercept,
        plugin_context_register_llm_sanitize_request_guardrail:
            native_plugin_context_register_llm_sanitize_request_guardrail,
        plugin_context_register_llm_sanitize_response_guardrail:
            native_plugin_context_register_llm_sanitize_response_guardrail,
        plugin_context_register_llm_conditional_execution_guardrail:
            native_plugin_context_register_llm_conditional_execution_guardrail,
        plugin_context_register_llm_request_intercept:
            native_plugin_context_register_llm_request_intercept,
        plugin_context_register_llm_execution_intercept:
            native_plugin_context_register_llm_execution_intercept,
        plugin_context_register_llm_stream_execution_intercept:
            native_plugin_context_register_llm_stream_execution_intercept,
        scope_handle_free: native_scope_handle_free,
        scope_get_current: native_scope_get_current,
        scope_push: native_scope_push,
        scope_pop: native_scope_pop,
        emit_mark: native_emit_mark,
        scope_stack_create: native_scope_stack_create,
        scope_stack_free: native_scope_stack_free,
        scope_stack_set_thread: native_scope_stack_set_thread,
        scope_stack_capture_thread: native_scope_stack_capture_thread,
        scope_stack_restore_thread: native_scope_stack_restore_thread,
        scope_stack_binding_free: native_scope_stack_binding_free,
        scope_stack_active: native_scope_stack_active,
        scope_stack_with_current: native_scope_stack_with_current,
        plugin_context_register_mark_sanitize_guardrail:
            native_plugin_context_register_mark_sanitize_guardrail,
        plugin_context_register_scope_sanitize_start_guardrail:
            native_plugin_context_register_scope_sanitize_start_guardrail,
        plugin_context_register_scope_sanitize_end_guardrail:
            native_plugin_context_register_scope_sanitize_end_guardrail,
    }
}

fn build_native_host_api_v3() -> NemoRelayNativeHostApiV3 {
    let mut v1 = build_native_host_api_v2();
    v1.abi_version = 3;
    v1.struct_size = std::mem::size_of::<NemoRelayNativeHostApiV3>();
    NemoRelayNativeHostApiV3 {
        v1,
        async_completion_resolve_json: native_async_completion_resolve_json,
        async_completion_reject: native_async_completion_reject,
        async_completion_is_cancelled: native_async_completion_is_cancelled,
        async_completion_release: native_async_completion_release,
        async_next_invoke: native_async_next_invoke,
        async_next_release: native_async_next_release,
        plugin_context_register_async_middleware: native_plugin_context_register_async_middleware,
        async_stream_push_json: native_async_stream_push_json,
        async_stream_finish: native_async_stream_finish,
        async_stream_reject: native_async_stream_reject,
        async_stream_is_cancelled: native_async_stream_is_cancelled,
        async_stream_release: native_async_stream_release,
        async_next_invoke_stream: native_async_next_invoke_stream,
        plugin_context_register_async_stream_middleware:
            native_plugin_context_register_async_stream_middleware,
        async_next_invoke_result: native_async_next_invoke_result,
    }
}

fn build_native_host_api_v5() -> NemoRelayNativeHostApiV5 {
    let mut v4 = build_native_host_api_v4();
    v4.v3.v1.abi_version = NEMO_RELAY_NATIVE_ABI_VERSION;
    v4.v3.v1.struct_size = std::mem::size_of::<NemoRelayNativeHostApiV5>();
    NemoRelayNativeHostApiV5 {
        v4,
        capture_mark_window_thread: native_capture_mark_window_thread,
        release_mark_window: native_release_mark_window,
        emit_mark_in_window: native_emit_mark_in_window,
    }
}

fn build_native_host_api_v4() -> NemoRelayNativeHostApiV4 {
    let mut v3 = build_native_host_api_v3();
    v3.v1.abi_version = NEMO_RELAY_NATIVE_ABI_VERSION;
    v3.v1.struct_size = std::mem::size_of::<NemoRelayNativeHostApiV4>();
    NemoRelayNativeHostApiV4 {
        v3,
        async_completion_llm_request_codec_decode: native_async_completion_llm_request_codec_decode,
        async_completion_llm_request_codec_encode: native_async_completion_llm_request_codec_encode,
        async_completion_llm_response_codec_decode:
            native_async_completion_llm_response_codec_decode,
        async_next_open_llm_stream: native_async_next_open_llm_stream,
        async_llm_stream_pull: native_async_llm_stream_pull,
        async_llm_stream_cancel: native_async_llm_stream_cancel,
        async_llm_stream_release: native_async_llm_stream_release,
        async_completion_retain: native_async_completion_retain,
        async_stream_is_backpressured: native_async_stream_is_backpressured,
        emit_mark_v2: native_emit_mark_v2,
        get_runtime_diagnostics: native_get_runtime_diagnostics,
        plugin_context_runtime: native_plugin_context_runtime,
        plugin_runtime_retain: native_plugin_runtime_retain,
        plugin_runtime_release: native_plugin_runtime_release,
        plugin_runtime_list_registrations: native_plugin_runtime_list_registrations,
        plugin_runtime_register_conditional_middleware_guardrail:
            native_plugin_runtime_register_conditional_middleware_guardrail,
        plugin_runtime_deregister_conditional_middleware_guardrail:
            native_plugin_runtime_deregister_conditional_middleware_guardrail,
        plugin_context_register_conditional_middleware_guardrail:
            native_plugin_context_register_conditional_middleware_guardrail,
        plugin_runtime_register_conditional_middleware_guardrail_callback:
            native_plugin_runtime_register_conditional_middleware_guardrail_callback,
        plugin_context_register_conditional_middleware_guardrail_callback:
            native_plugin_context_register_conditional_middleware_guardrail_callback,
    }
}

/// The mark window an invocation is running under, as an owned handle.
///
/// Captured where the host opens it — around the callback it is invoking — and
/// carried from there by whoever will be running the callback's work, because the
/// work outlives the call: a stream the callback returns is polled long after the
/// invocation that created it returned, and the marks it raises then belong to the
/// same operation as the ones raised during the call.
type MarkWindowHandle = Arc<dyn nemo_relay::plugin::execution::MarkForwarder>;

/// Captures the mark window the calling invocation runs under.
///
/// Answers a null handle when there is no window: a callback invoked outside the
/// host's own mark-forwarding window — as the in-process backend invokes one — has
/// no operation to attribute its marks to through this path, and the plugin's own
/// runtime handles them locally, which is what it already does.
unsafe extern "C" fn native_capture_mark_window_thread(
    out: *mut *mut NemoRelayNativeMarkWindow,
) -> NemoRelayStatus {
    if out.is_null() {
        set_native_last_error("mark window capture received null out pointer");
        return NemoRelayStatus::NullPointer;
    }
    clear_native_last_error();
    let window = host_runtime()
        .capture_mark_window()
        .map(|forwarder| Box::into_raw(Box::new(forwarder)) as *mut NemoRelayNativeMarkWindow)
        .unwrap_or(ptr::null_mut());
    unsafe { *out = window };
    NemoRelayStatus::Ok
}

/// Releases one owned mark-window handle.
unsafe extern "C" fn native_release_mark_window(window: *mut NemoRelayNativeMarkWindow) {
    if !window.is_null() {
        drop(unsafe { Box::from_raw(window as *mut MarkWindowHandle) });
    }
}

/// Emits a mark through the window it was raised under.
///
/// The window, not the call, says whose mark this is: a plugin chooses what a mark
/// says and not which operation it belongs to. A null window is refused rather than
/// attributed to whatever the calling thread happens to be doing — a mark with no
/// operation is a mark nobody can place, and placing it somewhere is worse than
/// saying so.
unsafe extern "C" fn native_emit_mark_in_window(
    window: *const NemoRelayNativeMarkWindow,
    name: *const NemoRelayNativeString,
    parent: *const NemoRelayNativeScopeHandle,
    data_json: *const NemoRelayNativeString,
    metadata_json: *const NemoRelayNativeString,
    data_schema_json: *const NemoRelayNativeString,
    severity: *const NemoRelayNativeString,
    timestamp_unix_micros: *const i64,
) -> NemoRelayStatus {
    if window.is_null() {
        set_native_last_error("mark emission requires the window it belongs to");
        return NemoRelayStatus::InvalidArg;
    }
    clear_native_last_error();
    let forwarder = unsafe { (window as *const MarkWindowHandle).as_ref() }.expect("checked above");
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let data = match optional_json_from_native_string(data_json, "mark data") {
        Ok(data) => data,
        Err(status) => return status,
    };
    let metadata = match optional_json_from_native_string(metadata_json, "mark metadata") {
        Ok(metadata) => metadata,
        Err(status) => return status,
    };
    let data_schema = match optional_typed_json_from_native_string::<DataSchema>(
        data_schema_json,
        "mark data schema",
    ) {
        Ok(data_schema) => data_schema,
        Err(status) => return status,
    };
    let severity = match optional_severity_from_native_string(severity) {
        Ok(severity) => severity,
        Err(status) => return status,
    };
    let timestamp = match optional_timestamp_from_native(timestamp_unix_micros) {
        Ok(timestamp) => timestamp,
        Err(status) => return status,
    };
    let parent_ref = native_scope_ref(parent);
    let params = EmitMarkEventParams::builder()
        .name(&name)
        .parent_opt(parent_ref)
        .data_opt(data)
        .metadata_opt(metadata)
        .data_schema_opt(data_schema)
        .severity_opt(severity)
        .timestamp_opt(timestamp)
        .build();
    match host_runtime()
        .forward_mark(&params)
        .and_then(|mark| forwarder.forward(&mark))
    {
        Ok(()) => NemoRelayStatus::Ok,
        Err(err) => status_from_flow_error(err),
    }
}

fn read_native_string(value: *const NemoRelayNativeString) -> nemo_relay::plugin::Result<String> {
    if value.is_null() {
        return Ok(String::new());
    }
    let value = unsafe { &*(value as *const NativeHostString) };
    std::str::from_utf8(&value.0)
        .map(str::to_owned)
        .map_err(|err| {
            PluginError::InvalidConfig(format!("native string is not valid UTF-8: {err}"))
        })
}

fn native_string_from_str(value: &str) -> Option<*mut NemoRelayNativeString> {
    let mut out = ptr::null_mut();
    let status = unsafe { native_string_new(value.as_ptr(), value.len(), &mut out) };
    (status == NemoRelayStatus::Ok).then_some(out)
}

fn native_string_from_json(value: &Json) -> Option<*mut NemoRelayNativeString> {
    serde_json::to_string(value)
        .ok()
        .and_then(|value| native_string_from_str(&value))
}

fn json_from_native_string(value: *mut NemoRelayNativeString, fallback: &str) -> FlowResult<Json> {
    if value.is_null() {
        return Err(FlowError::Internal(
            native_last_error_message().unwrap_or_else(|| fallback.into()),
        ));
    }
    let text = read_native_string(value).map_err(|err| FlowError::Internal(err.to_string()))?;
    serde_json::from_str(&text).map_err(|err| FlowError::Internal(format!("invalid JSON: {err}")))
}

fn take_native_string(value: *mut NemoRelayNativeString) -> FlowResult<String> {
    let result = read_native_string(value).map_err(|err| FlowError::Internal(err.to_string()));
    unsafe { native_string_free(value) };
    result
}

fn take_json_from_native_string(
    value: *mut NemoRelayNativeString,
    fallback: &str,
) -> FlowResult<Json> {
    let result = json_from_native_string(value, fallback);
    unsafe { native_string_free(value) };
    result
}

unsafe fn free_native_sanitizer_strings(
    input: *mut NemoRelayNativeString,
    codec_id: Option<*mut NemoRelayNativeString>,
    output: *mut NemoRelayNativeString,
) {
    unsafe { native_string_free(input) };
    if let Some(codec_id) = codec_id
        && codec_id != input
    {
        unsafe { native_string_free(codec_id) };
    }
    if !output.is_null() && output != input && Some(output) != codec_id {
        unsafe { native_string_free(output) };
    }
}

fn optional_json_from_native_string(
    value: *const NemoRelayNativeString,
    field: &str,
) -> Result<Option<Json>, NemoRelayStatus> {
    if value.is_null() {
        return Ok(None);
    }
    let text = read_native_string(value).map_err(|err| {
        set_native_last_error(err.to_string());
        NemoRelayStatus::InvalidUtf8
    })?;
    serde_json::from_str(&text).map(Some).map_err(|err| {
        set_native_last_error(format!("{field} is not valid JSON: {err}"));
        NemoRelayStatus::InvalidJson
    })
}

fn optional_typed_json_from_native_string<T: serde::de::DeserializeOwned>(
    value: *const NemoRelayNativeString,
    field: &str,
) -> Result<Option<T>, NemoRelayStatus> {
    optional_json_from_native_string(value, field)?
        .map(|value| {
            serde_json::from_value(value).map_err(|err| {
                set_native_last_error(format!("{field} has an invalid shape: {err}"));
                NemoRelayStatus::InvalidArg
            })
        })
        .transpose()
}

fn optional_severity_from_native_string(
    value: *const NemoRelayNativeString,
) -> Result<Option<LogSeverity>, NemoRelayStatus> {
    if value.is_null() {
        return Ok(None);
    }
    let value = read_native_string(value).map_err(|err| {
        set_native_last_error(err.to_string());
        NemoRelayStatus::InvalidUtf8
    })?;
    serde_json::from_value(Json::String(value))
        .map(Some)
        .map_err(|err| {
            set_native_last_error(format!("mark severity is invalid: {err}"));
            NemoRelayStatus::InvalidArg
        })
}

fn optional_timestamp_from_native(
    timestamp_unix_micros: *const i64,
) -> Result<Option<DateTime<Utc>>, NemoRelayStatus> {
    if timestamp_unix_micros.is_null() {
        return Ok(None);
    }
    DateTime::<Utc>::from_timestamp_micros(unsafe { ptr::read(timestamp_unix_micros) })
        .map(Some)
        .ok_or_else(|| {
            set_native_last_error("timestamp unix microseconds are outside supported range");
            NemoRelayStatus::InvalidArg
        })
}

fn native_scope_type_to_core(scope_type: NemoRelayNativeScopeType) -> ScopeType {
    match scope_type {
        NemoRelayNativeScopeType::Agent => ScopeType::Agent,
        NemoRelayNativeScopeType::Function => ScopeType::Function,
        NemoRelayNativeScopeType::Tool => ScopeType::Tool,
        NemoRelayNativeScopeType::Llm => ScopeType::Llm,
        NemoRelayNativeScopeType::Retriever => ScopeType::Retriever,
        NemoRelayNativeScopeType::Embedder => ScopeType::Embedder,
        NemoRelayNativeScopeType::Reranker => ScopeType::Reranker,
        NemoRelayNativeScopeType::Guardrail => ScopeType::Guardrail,
        NemoRelayNativeScopeType::Evaluator => ScopeType::Evaluator,
        NemoRelayNativeScopeType::Custom => ScopeType::Custom,
        NemoRelayNativeScopeType::Unknown => ScopeType::Unknown,
    }
}

fn native_scope_ref<'a>(handle: *const NemoRelayNativeScopeHandle) -> Option<&'a ScopeHandle> {
    if handle.is_null() {
        return None;
    }
    Some(&unsafe { &*(handle as *const NativeHostScopeHandle) }.0)
}

unsafe extern "C" fn native_scope_handle_free(handle: *mut NemoRelayNativeScopeHandle) {
    if !handle.is_null() {
        drop(unsafe { Box::from_raw(handle as *mut NativeHostScopeHandle) });
    }
}

unsafe extern "C" fn native_scope_get_current(
    out: *mut *mut NemoRelayNativeScopeHandle,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out.is_null() {
        set_native_last_error("out scope handle pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    match get_handle() {
        Ok(handle) => {
            unsafe { *out = Box::into_raw(Box::new(NativeHostScopeHandle(handle))).cast() };
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_flow_error(err),
    }
}

unsafe extern "C" fn native_scope_push(
    name: *const NemoRelayNativeString,
    scope_type: NemoRelayNativeScopeType,
    parent: *const NemoRelayNativeScopeHandle,
    attributes: u32,
    data_json: *const NemoRelayNativeString,
    metadata_json: *const NemoRelayNativeString,
    input_json: *const NemoRelayNativeString,
    timestamp_unix_micros: *const i64,
    out: *mut *mut NemoRelayNativeScopeHandle,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out.is_null() {
        set_native_last_error("out scope handle pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let data = match optional_json_from_native_string(data_json, "scope data") {
        Ok(data) => data,
        Err(status) => return status,
    };
    let metadata = match optional_json_from_native_string(metadata_json, "scope metadata") {
        Ok(metadata) => metadata,
        Err(status) => return status,
    };
    let input = match optional_json_from_native_string(input_json, "scope input") {
        Ok(input) => input,
        Err(status) => return status,
    };
    let timestamp = match optional_timestamp_from_native(timestamp_unix_micros) {
        Ok(timestamp) => timestamp,
        Err(status) => return status,
    };
    let parent_ref = native_scope_ref(parent);
    match push_scope(
        PushScopeParams::builder()
            .name(&name)
            .scope_type(native_scope_type_to_core(scope_type))
            .parent_opt(parent_ref)
            .attributes(ScopeAttributes::from_bits_truncate(attributes))
            .data_opt(data)
            .metadata_opt(metadata)
            .input_opt(input)
            .timestamp_opt(timestamp)
            .build(),
    ) {
        Ok(handle) => {
            unsafe { *out = Box::into_raw(Box::new(NativeHostScopeHandle(handle))).cast() };
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_flow_error(err),
    }
}

unsafe extern "C" fn native_scope_pop(
    handle: *const NemoRelayNativeScopeHandle,
    output_json: *const NemoRelayNativeString,
    metadata_json: *const NemoRelayNativeString,
    timestamp_unix_micros: *const i64,
) -> NemoRelayStatus {
    clear_native_last_error();
    if handle.is_null() {
        set_native_last_error("scope handle is null");
        return NemoRelayStatus::NullPointer;
    }
    let output = match optional_json_from_native_string(output_json, "scope output") {
        Ok(output) => output,
        Err(status) => return status,
    };
    let metadata = match optional_json_from_native_string(metadata_json, "scope metadata") {
        Ok(metadata) => metadata,
        Err(status) => return status,
    };
    let timestamp = match optional_timestamp_from_native(timestamp_unix_micros) {
        Ok(timestamp) => timestamp,
        Err(status) => return status,
    };
    let handle = unsafe { &*(handle as *const NativeHostScopeHandle) };
    match pop_scope(
        PopScopeParams::builder()
            .handle_uuid(&handle.0.uuid)
            .output_opt(output)
            .metadata_opt(metadata)
            .timestamp_opt(timestamp)
            .build(),
    ) {
        Ok(()) => NemoRelayStatus::Ok,
        Err(err) => status_from_flow_error(err),
    }
}

unsafe extern "C" fn native_emit_mark(
    name: *const NemoRelayNativeString,
    parent: *const NemoRelayNativeScopeHandle,
    data_json: *const NemoRelayNativeString,
    metadata_json: *const NemoRelayNativeString,
    timestamp_unix_micros: *const i64,
) -> NemoRelayStatus {
    clear_native_last_error();
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let data = match optional_json_from_native_string(data_json, "mark data") {
        Ok(data) => data,
        Err(status) => return status,
    };
    let metadata = match optional_json_from_native_string(metadata_json, "mark metadata") {
        Ok(metadata) => metadata,
        Err(status) => return status,
    };
    let timestamp = match optional_timestamp_from_native(timestamp_unix_micros) {
        Ok(timestamp) => timestamp,
        Err(status) => return status,
    };
    let parent_ref = native_scope_ref(parent);
    match emit_scope_mark(
        EmitMarkEventParams::builder()
            .name(&name)
            .parent_opt(parent_ref)
            .data_opt(data)
            .metadata_opt(metadata)
            .timestamp_opt(timestamp)
            .build(),
    ) {
        Ok(()) => NemoRelayStatus::Ok,
        Err(err) => status_from_flow_error(err),
    }
}

#[allow(clippy::too_many_arguments)] // Mirrors the append-only native ABI function.
unsafe extern "C" fn native_emit_mark_v2(
    name: *const NemoRelayNativeString,
    parent: *const NemoRelayNativeScopeHandle,
    data_json: *const NemoRelayNativeString,
    metadata_json: *const NemoRelayNativeString,
    data_schema_json: *const NemoRelayNativeString,
    severity: *const NemoRelayNativeString,
    timestamp_unix_micros: *const i64,
) -> NemoRelayStatus {
    clear_native_last_error();
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let data = match optional_json_from_native_string(data_json, "mark data") {
        Ok(data) => data,
        Err(status) => return status,
    };
    let metadata = match optional_json_from_native_string(metadata_json, "mark metadata") {
        Ok(metadata) => metadata,
        Err(status) => return status,
    };
    let data_schema = match optional_typed_json_from_native_string::<DataSchema>(
        data_schema_json,
        "mark data schema",
    ) {
        Ok(data_schema) => data_schema,
        Err(status) => return status,
    };
    let severity = match optional_severity_from_native_string(severity) {
        Ok(severity) => severity,
        Err(status) => return status,
    };
    let timestamp = match optional_timestamp_from_native(timestamp_unix_micros) {
        Ok(timestamp) => timestamp,
        Err(status) => return status,
    };
    let parent_ref = native_scope_ref(parent);
    match emit_scope_mark(
        EmitMarkEventParams::builder()
            .name(&name)
            .parent_opt(parent_ref)
            .data_opt(data)
            .metadata_opt(metadata)
            .data_schema_opt(data_schema)
            .severity_opt(severity)
            .timestamp_opt(timestamp)
            .build(),
    ) {
        Ok(()) => NemoRelayStatus::Ok,
        Err(err) => status_from_flow_error(err),
    }
}

unsafe extern "C" fn native_get_runtime_diagnostics(
    out_json: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    let diagnostics = host_runtime().runtime_diagnostics();
    match serde_json::to_value(diagnostics) {
        Ok(entries) => {
            let value = Json::Object(Map::from_iter([("entries".into(), entries)]));
            write_native_json(&value, out_json)
        }
        Err(error) => {
            set_native_last_error(format!("failed to serialize runtime diagnostics: {error}"));
            NemoRelayStatus::Internal
        }
    }
}

unsafe extern "C" fn native_scope_stack_create(
    out: *mut *mut NemoRelayNativeScopeStack,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out.is_null() {
        set_native_last_error("out scope stack pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe {
        *out = Box::into_raw(Box::new(NativeHostScopeStack(create_scope_stack()))).cast();
    }
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_scope_stack_free(stack: *mut NemoRelayNativeScopeStack) {
    if !stack.is_null() {
        drop(unsafe { Box::from_raw(stack as *mut NativeHostScopeStack) });
    }
}

unsafe extern "C" fn native_scope_stack_set_thread(
    stack: *const NemoRelayNativeScopeStack,
) -> NemoRelayStatus {
    clear_native_last_error();
    if stack.is_null() {
        set_native_last_error("scope stack is null");
        return NemoRelayStatus::NullPointer;
    }
    let stack = unsafe { &*(stack as *const NativeHostScopeStack) };
    set_thread_scope_stack(stack.0.clone());
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_scope_stack_capture_thread(
    out: *mut *mut NemoRelayNativeScopeStackBinding,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out.is_null() {
        set_native_last_error("out scope stack binding pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe {
        *out = Box::into_raw(Box::new(NativeHostScopeStackBinding(
            capture_thread_scope_stack(),
        )))
        .cast();
    }
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_scope_stack_restore_thread(
    binding: *mut NemoRelayNativeScopeStackBinding,
) -> NemoRelayStatus {
    clear_native_last_error();
    if binding.is_null() {
        set_native_last_error("scope stack binding is null");
        return NemoRelayStatus::NullPointer;
    }
    let binding = unsafe { Box::from_raw(binding as *mut NativeHostScopeStackBinding) };
    restore_thread_scope_stack(binding.0);
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_scope_stack_binding_free(
    binding: *mut NemoRelayNativeScopeStackBinding,
) {
    if !binding.is_null() {
        drop(unsafe { Box::from_raw(binding as *mut NativeHostScopeStackBinding) });
    }
}

unsafe extern "C" fn native_scope_stack_active() -> bool {
    scope_stack_active()
}

unsafe extern "C" fn native_scope_stack_with_current(
    stack: *const NemoRelayNativeScopeStack,
    cb: NemoRelayNativeWithScopeStackCb,
    user_data: *mut c_void,
) -> NemoRelayStatus {
    clear_native_last_error();
    if stack.is_null() {
        set_native_last_error("scope stack is null");
        return NemoRelayStatus::NullPointer;
    }
    let stack = unsafe { &*(stack as *const NativeHostScopeStack) };
    let status = with_scope_stack(stack.0.clone(), || unsafe { cb(user_data) });
    if status != NemoRelayStatus::Ok && native_last_error_message().is_none() {
        set_native_last_error(format!("native scope-stack callback returned {status:?}"));
    }
    status
}

fn flow_error_from_status(status: NemoRelayStatus, fallback: &str) -> FlowError {
    let message = native_last_error_message().unwrap_or_else(|| format!("{fallback}: {status:?}"));
    match status {
        NemoRelayStatus::AlreadyExists => FlowError::AlreadyExists(message),
        NemoRelayStatus::NotFound => FlowError::NotFound(message),
        NemoRelayStatus::ScopeStackEmpty => FlowError::ScopeStackEmpty,
        NemoRelayStatus::GuardrailRejected => FlowError::GuardrailRejected(message),
        NemoRelayStatus::InvalidArg => FlowError::InvalidArgument(message),
        _ => FlowError::Internal(message),
    }
}

fn status_from_plugin_error(err: PluginError) -> NemoRelayStatus {
    set_native_last_error(err.to_string());
    match err {
        PluginError::NotFound(_) => NemoRelayStatus::NotFound,
        PluginError::Conflict(_) => NemoRelayStatus::AlreadyExists,
        PluginError::InvalidConfig(_) | PluginError::Serialization(_) => {
            NemoRelayStatus::InvalidArg
        }
        PluginError::ResourceExhausted { .. } => NemoRelayStatus::Backpressured,
        PluginError::Internal(_) | PluginError::RegistrationFailed(_) => NemoRelayStatus::Internal,
    }
}

fn status_from_flow_error(err: FlowError) -> NemoRelayStatus {
    set_native_last_error(err.to_string());
    match err {
        FlowError::AlreadyExists(_) => NemoRelayStatus::AlreadyExists,
        FlowError::NotFound(_) => NemoRelayStatus::NotFound,
        FlowError::InvalidArgument(_) => NemoRelayStatus::InvalidArg,
        FlowError::ScopeStackEmpty => NemoRelayStatus::ScopeStackEmpty,
        FlowError::GuardrailRejected(_) => NemoRelayStatus::GuardrailRejected,
        // The stable native ABI already exposes a retryable capacity result.
        // Preserve that distinction instead of collapsing bounded-resource
        // admission failures into an opaque internal error.
        FlowError::ResourceExhausted { .. } => NemoRelayStatus::Backpressured,
        // Admission timeout is retryable backpressure at the native boundary.
        FlowError::Timeout { .. } => NemoRelayStatus::Backpressured,
        // A registration that failed keeps its reason: the dispatch state and
        // the certainty belong to whoever decides about effects, and a status
        // code at the ABI boundary is not a place to keep them.
        FlowError::PluginInvocation { failure, .. } => {
            set_native_last_error(failure.message);
            NemoRelayStatus::Internal
        }
        FlowError::Upstream(_) | FlowError::Internal(_) | FlowError::CallbackException { .. } => {
            NemoRelayStatus::Internal
        }
    }
}

fn panic_payload_message(payload: &(dyn std::any::Any + Send)) -> &str {
    payload
        .downcast_ref::<&str>()
        .copied()
        .or_else(|| payload.downcast_ref::<String>().map(String::as_str))
        .unwrap_or("unknown panic payload")
}

fn native_runtime() -> &'static Runtime {
    static RUNTIME: OnceLock<Runtime> = OnceLock::new();
    RUNTIME.get_or_init(|| {
        tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .expect("native plugin runtime should build")
    })
}

fn spawn_with_continuation_context<C, F, T>(
    context: MiddlewareContinuationContext,
    callback: C,
) -> std::thread::JoinHandle<T>
where
    C: FnOnce() -> F + Send + 'static,
    F: Future<Output = T> + Send + 'static,
    T: Send + 'static,
{
    let binding = capture_thread_scope_stack();
    std::thread::spawn(move || {
        restore_thread_scope_stack(binding);
        native_runtime().block_on(context.invoke(callback))
    })
}

struct NativeCallbackUserData {
    ptr: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
    _instance: Option<Arc<NativePluginInstance>>,
}

struct NativeCallbackUserDataGuard {
    ptr: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
    armed: bool,
}

impl NativeCallbackUserDataGuard {
    fn new(ptr: *mut c_void, free_fn: NemoRelayNativeFreeFn) -> Self {
        Self {
            ptr,
            free_fn,
            armed: true,
        }
    }

    fn transfer(mut self) -> (*mut c_void, NemoRelayNativeFreeFn) {
        self.armed = false;
        (self.ptr, self.free_fn)
    }
}

impl Drop for NativeCallbackUserDataGuard {
    fn drop(&mut self) {
        if self.armed
            && let Some(free_fn) = self.free_fn
        {
            unsafe { free_fn(self.ptr) };
        }
    }
}

unsafe impl Send for NativeCallbackUserData {}
unsafe impl Sync for NativeCallbackUserData {}

impl Drop for NativeCallbackUserData {
    fn drop(&mut self) {
        if let Some(free_fn) = self.free_fn {
            unsafe { free_fn(self.ptr) };
        }
    }
}

fn make_user_data(
    instance: Arc<NativePluginInstance>,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> Arc<NativeCallbackUserData> {
    Arc::new(NativeCallbackUserData {
        ptr: user_data,
        free_fn,
        _instance: Some(instance),
    })
}

const NATIVE_ASYNC_STREAM_CHANNEL_CAPACITY: usize = 64;

enum NativeAsyncCodecCapability {
    Request(Arc<dyn LlmCodec>),
    Response(Arc<dyn LlmResponseCodec>),
}

struct NativeAsyncCompletion {
    sender: Mutex<Option<tokio::sync::oneshot::Sender<FlowResult<Json>>>>,
    cancelled: AtomicBool,
    next_invoked: AtomicBool,
    next_abort: Mutex<Option<tokio::task::AbortHandle>>,
    continuation_aborts: Mutex<HashMap<tokio::task::Id, tokio::task::AbortHandle>>,
    codec: Option<NativeAsyncCodecCapability>,
    #[cfg(test)]
    before_settlement_lock: Option<Arc<std::sync::Barrier>>,
    // A pending native callback can continue running after its completion
    // wakes the awaiting task. Keep the callback's dynamic-library instance
    // alive until native code explicitly releases this handle.
    _callback_user_data: Option<Arc<NativeCallbackUserData>>,
}

struct NativeAsyncWait {
    completion: Arc<NativeAsyncCompletion>,
    receiver: tokio::sync::oneshot::Receiver<FlowResult<Json>>,
    completed: bool,
}

impl NativeAsyncWait {
    async fn receive(&mut self) -> FlowResult<Json> {
        let result = (&mut self.receiver).await.map_err(|_| {
            FlowError::Internal("native async callback dropped without settling".into())
        })?;
        self.completed = true;
        result
    }
}

impl Drop for NativeAsyncWait {
    fn drop(&mut self) {
        if self.completed {
            return;
        }
        let mut next_abort = self
            .completion
            .next_abort
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        self.completion.cancelled.store(true, Ordering::Release);
        if let Some(abort) = next_abort.take() {
            abort.abort();
        }
        abort_completion_continuations(&self.completion);
    }
}

fn abort_completion_continuations(completion: &NativeAsyncCompletion) {
    let mut aborts = completion
        .continuation_aborts
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    for (_, abort) in aborts.drain() {
        abort.abort();
    }
}

enum NativeAsyncNextInner {
    Tool(ToolExecutionNextFn),
    Llm(LlmExecutionNextFn),
    LlmStream(LlmStreamExecutionNextFn),
}

struct NativeAsyncNext {
    inner: NativeAsyncNextInner,
    runtime: tokio::runtime::Handle,
    context: MiddlewareContinuationContext,
    owner: Option<NativeAsyncNextOwner>,
    // The native callback owns this handle independently of its completion.
    // Retaining the library here prevents an unload while it still uses `next`.
    _callback_user_data: Option<Arc<NativeCallbackUserData>>,
}

#[derive(Clone)]
enum NativeAsyncNextOwner {
    Completion(Weak<NativeAsyncCompletion>),
    Stream(Weak<NativeAsyncStream>),
}

impl NativeAsyncNext {
    fn new(
        inner: NativeAsyncNextInner,
        runtime: tokio::runtime::Handle,
        callback_user_data: Option<Arc<NativeCallbackUserData>>,
    ) -> Self {
        Self {
            inner,
            runtime,
            context: MiddlewareContinuationContext::capture(),
            owner: None,
            _callback_user_data: callback_user_data,
        }
    }

    fn with_completion_owner(
        inner: NativeAsyncNextInner,
        runtime: tokio::runtime::Handle,
        callback_user_data: Option<Arc<NativeCallbackUserData>>,
        completion: &Arc<NativeAsyncCompletion>,
    ) -> Self {
        let mut next = Self::new(inner, runtime, callback_user_data);
        next.owner = Some(NativeAsyncNextOwner::Completion(Arc::downgrade(completion)));
        next
    }

    fn with_stream_owner(
        inner: NativeAsyncNextInner,
        runtime: tokio::runtime::Handle,
        callback_user_data: Option<Arc<NativeCallbackUserData>>,
        stream: &Arc<NativeAsyncStream>,
    ) -> Self {
        let mut next = Self::new(inner, runtime, callback_user_data);
        next.owner = Some(NativeAsyncNextOwner::Stream(Arc::downgrade(stream)));
        next
    }
}

fn register_native_next_operation(
    owner: &Option<NativeAsyncNextOwner>,
    id: tokio::task::Id,
    abort: tokio::task::AbortHandle,
) -> bool {
    match owner {
        Some(NativeAsyncNextOwner::Completion(owner)) => {
            let Some(owner) = owner.upgrade() else {
                return false;
            };
            let sender = owner
                .sender
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            if owner.cancelled.load(Ordering::Acquire) || sender.is_none() {
                return false;
            }
            owner
                .continuation_aborts
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .insert(id, abort);
            drop(sender);
            true
        }
        Some(NativeAsyncNextOwner::Stream(owner)) => {
            let Some(owner) = owner.upgrade() else {
                return false;
            };
            let _settlement = owner
                .settlement
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            if owner.cancelled.load(Ordering::Acquire) || owner.settled.load(Ordering::Acquire) {
                return false;
            }
            owner
                .downstream_aborts
                .lock()
                .unwrap_or_else(|error| error.into_inner())
                .insert(id, abort);
            true
        }
        None => true,
    }
}

fn remove_native_next_operation(owner: &Option<NativeAsyncNextOwner>, id: tokio::task::Id) {
    match owner {
        Some(NativeAsyncNextOwner::Completion(owner)) => {
            if let Some(owner) = owner.upgrade() {
                owner
                    .continuation_aborts
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .remove(&id);
            }
        }
        Some(NativeAsyncNextOwner::Stream(owner)) => {
            if let Some(owner) = owner.upgrade() {
                owner
                    .downstream_aborts
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .remove(&id);
            }
        }
        None => {}
    }
}

struct NativeAsyncStream {
    sender: Mutex<Option<tokio::sync::mpsc::Sender<FlowResult<Json>>>>,
    cancelled: AtomicBool,
    settled: AtomicBool,
    backpressured: AtomicBool,
    downstream_aborts: Mutex<HashMap<tokio::task::Id, tokio::task::AbortHandle>>,
    settlement: Mutex<()>,
    #[cfg(test)]
    before_settlement_lock: Option<Arc<std::sync::Barrier>>,
    _callback_user_data: Option<Arc<NativeCallbackUserData>>,
}

struct NativeAsyncStreamReceiver {
    receiver: tokio::sync::mpsc::Receiver<FlowResult<Json>>,
    stream: Arc<NativeAsyncStream>,
}

struct NativeAsyncStreamCallbackGuard {
    cb: NemoRelayNativeAsyncNextStreamCb,
    user_data: usize,
    stream: Arc<NativeAsyncStream>,
    _library_guard: Option<Arc<NativeCallbackUserData>>,
    active: bool,
}

impl NativeAsyncStreamCallbackGuard {
    fn finish(&mut self) {
        self.active = false;
    }

    fn fail(&mut self, error: &str) {
        if !self.active {
            return;
        }
        // Cancellation owns terminal delivery. Leave the guard active so its
        // Drop implementation can notify the plugin and release callback data.
        if self.stream.cancelled.load(Ordering::Acquire) {
            return;
        }
        if let Some(message) = native_string_from_str(error) {
            unsafe {
                let _ = (self.cb)(self.user_data as *mut c_void, ptr::null(), message, false);
                native_string_free(message);
            }
            self.active = false;
        }
    }
}

impl Drop for NativeAsyncStreamCallbackGuard {
    fn drop(&mut self) {
        if !self.active {
            return;
        }
        if self.stream.cancelled.load(Ordering::Acquire) {
            if let Some(message) =
                native_string_from_str("native async stream continuation was cancelled")
            {
                unsafe {
                    let _ = (self.cb)(self.user_data as *mut c_void, ptr::null(), message, false);
                    native_string_free(message);
                }
            }
        } else if self.stream.settled.load(Ordering::Acquire) {
            if let Some(message) =
                native_string_from_str("native async stream continuation output settled")
            {
                unsafe {
                    let _ = (self.cb)(self.user_data as *mut c_void, ptr::null(), message, false);
                    native_string_free(message);
                }
            }
        } else {
            unsafe {
                let _ = (self.cb)(
                    self.user_data as *mut c_void,
                    ptr::null(),
                    ptr::null(),
                    true,
                );
            }
        }
    }
}

impl Stream for NativeAsyncStreamReceiver {
    type Item = FlowResult<Json>;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.receiver.poll_recv(cx)
    }
}

impl Drop for NativeAsyncStreamReceiver {
    fn drop(&mut self) {
        let _settlement = self
            .stream
            .settlement
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let mut downstream_aborts = self
            .stream
            .downstream_aborts
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        self.stream.cancelled.store(true, Ordering::Release);
        for (_, abort) in downstream_aborts.drain() {
            abort.abort();
        }
        drop(downstream_aborts);
        self.stream
            .sender
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .take();
    }
}

async fn invoke_native_async_callback(
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: Arc<NativeCallbackUserData>,
    invocation: Json,
    next: Option<NativeAsyncNextInner>,
    codec: Option<NativeAsyncCodecCapability>,
) -> FlowResult<Json> {
    let runtime = if next.is_some() {
        Some(tokio::runtime::Handle::try_current().map_err(|error| {
            FlowError::Internal(format!(
                "native async intercept requires a Tokio runtime: {error}"
            ))
        })?)
    } else {
        None
    };
    let invocation = native_string_from_json(&invocation)
        .ok_or_else(|| FlowError::Internal("failed to allocate native async invocation".into()))?
        as usize;
    let (sender, receiver) = tokio::sync::oneshot::channel();
    let completion = Arc::new(NativeAsyncCompletion {
        sender: Mutex::new(Some(sender)),
        cancelled: AtomicBool::new(false),
        next_invoked: AtomicBool::new(false),
        next_abort: Mutex::new(None),
        continuation_aborts: Mutex::new(HashMap::new()),
        codec,
        #[cfg(test)]
        before_settlement_lock: None,
        _callback_user_data: Some(user_data.clone()),
    });
    let mut wait = NativeAsyncWait {
        completion: Arc::clone(&completion),
        receiver,
        completed: false,
    };
    let completion_ref = Arc::into_raw(completion.clone()) as usize;
    let next_ref = match (next, runtime) {
        (Some(inner), Some(runtime)) => Some(Arc::into_raw(Arc::new(
            NativeAsyncNext::with_completion_owner(
                inner,
                runtime,
                Some(user_data.clone()),
                &completion,
            ),
        )) as usize),
        (None, None) => None,
        _ => unreachable!("runtime is present exactly for native async intercepts"),
    };
    // ABI v3 exposes a thread-stack capture operation. Mirror the effective
    // task-local stack into that slot only while entering plugin code so the
    // SDK can capture it before moving the future to its own executor.
    let previous_thread_stack = capture_thread_scope_stack();
    sync_thread_scope_stack(current_scope_stack());
    let state = catch_unwind(AssertUnwindSafe(|| unsafe {
        cb(
            user_data.ptr,
            invocation as *const NemoRelayNativeString,
            next_ref
                .map(|next| next as *const NemoRelayNativeAsyncNext)
                .unwrap_or(ptr::null()),
            completion_ref as *const NemoRelayNativeAsyncCompletion,
        )
    }));
    restore_thread_scope_stack(previous_thread_stack);
    let state = match state {
        Ok(state) => state,
        Err(_) => {
            unsafe {
                drop(Arc::from_raw(
                    completion_ref as *const NativeAsyncCompletion,
                ));
                native_string_free(invocation as *mut NemoRelayNativeString);
            }
            return Err(FlowError::Internal("native async callback panicked".into()));
        }
    };
    unsafe { native_string_free(invocation as *mut NemoRelayNativeString) };
    let state = match NemoRelayNativeAsyncCallbackState::try_from(state) {
        Ok(state) => state,
        Err(()) => {
            unsafe {
                drop(Arc::from_raw(
                    completion_ref as *const NativeAsyncCompletion,
                ));
            }
            return Err(FlowError::Internal(
                "native async callback returned an invalid state".into(),
            ));
        }
    };
    if state == NemoRelayNativeAsyncCallbackState::Complete {
        unsafe {
            drop(Arc::from_raw(
                completion_ref as *const NativeAsyncCompletion,
            ));
        }
        if completion
            .sender
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .is_some()
        {
            return Err(FlowError::Internal(
                "native async callback returned Complete without settling".into(),
            ));
        }
    }
    wait.receive().await
}

unsafe extern "C" fn native_async_completion_resolve_json(
    completion: *const NemoRelayNativeAsyncCompletion,
    value_json: *const NemoRelayNativeString,
) -> NemoRelayStatus {
    let Some(completion) = (unsafe { (completion as *const NativeAsyncCompletion).as_ref() })
    else {
        return NemoRelayStatus::NullPointer;
    };
    let value = match parse_json_arg(value_json, "native async completion result") {
        Ok(value) => value,
        Err(status) => return status,
    };
    #[cfg(test)]
    if let Some(barrier) = &completion.before_settlement_lock {
        barrier.wait();
    }
    let mut next_abort = completion
        .next_abort
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if completion.cancelled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    let Some(sender) = completion
        .sender
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .take()
    else {
        return NemoRelayStatus::InvalidArg;
    };
    if let Some(abort) = next_abort.take() {
        abort.abort();
    }
    abort_completion_continuations(completion);
    let _ = sender.send(Ok(value));
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_async_completion_reject(
    completion: *const NemoRelayNativeAsyncCompletion,
    message: *const NemoRelayNativeString,
) -> NemoRelayStatus {
    let Some(completion) = (unsafe { (completion as *const NativeAsyncCompletion).as_ref() })
    else {
        return NemoRelayStatus::NullPointer;
    };
    let message = if message.is_null() {
        "native async callback rejected".to_string()
    } else {
        match read_native_string(message) {
            Ok(message) => message,
            Err(error) => {
                set_native_last_error(error.to_string());
                return NemoRelayStatus::InvalidArg;
            }
        }
    };
    #[cfg(test)]
    if let Some(barrier) = &completion.before_settlement_lock {
        barrier.wait();
    }
    let mut next_abort = completion
        .next_abort
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if completion.cancelled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    let Some(sender) = completion
        .sender
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .take()
    else {
        return NemoRelayStatus::InvalidArg;
    };
    if let Some(abort) = next_abort.take() {
        abort.abort();
    }
    abort_completion_continuations(completion);
    let _ = sender.send(Err(FlowError::Internal(message)));
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_async_completion_is_cancelled(
    completion: *const NemoRelayNativeAsyncCompletion,
) -> bool {
    unsafe { (completion as *const NativeAsyncCompletion).as_ref() }
        .is_none_or(|completion| completion.cancelled.load(Ordering::Acquire))
}

fn active_async_completion(
    completion: *const NemoRelayNativeAsyncCompletion,
) -> Result<&'static NativeAsyncCompletion, NemoRelayStatus> {
    let Some(completion) = (unsafe { (completion as *const NativeAsyncCompletion).as_ref() })
    else {
        return Err(NemoRelayStatus::NullPointer);
    };
    if completion.cancelled.load(Ordering::Acquire)
        || completion
            .sender
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .is_none()
    {
        set_native_last_error("native async completion capability is expired");
        return Err(NemoRelayStatus::InvalidArg);
    }
    Ok(completion)
}

unsafe extern "C" fn native_async_completion_llm_request_codec_decode(
    completion: *const NemoRelayNativeAsyncCompletion,
    request_json: *const NemoRelayNativeString,
    out: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    if out.is_null() {
        set_native_last_error("request codec decode output is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    let completion = match active_async_completion(completion) {
        Ok(completion) => completion,
        Err(status) => return status,
    };
    let Some(NativeAsyncCodecCapability::Request(codec)) = &completion.codec else {
        set_native_last_error("async completion has no request codec capability");
        return NemoRelayStatus::InvalidArg;
    };
    let codec = NativeHostLlmRequestCodec(Arc::clone(codec));
    unsafe { native_llm_request_codec_decode(std::ptr::from_ref(&codec).cast(), request_json, out) }
}

unsafe extern "C" fn native_async_completion_llm_request_codec_encode(
    completion: *const NemoRelayNativeAsyncCompletion,
    annotated_json: *const NemoRelayNativeString,
    original_json: *const NemoRelayNativeString,
    out: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    if out.is_null() {
        set_native_last_error("request codec encode output is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    let completion = match active_async_completion(completion) {
        Ok(completion) => completion,
        Err(status) => return status,
    };
    let Some(NativeAsyncCodecCapability::Request(codec)) = &completion.codec else {
        set_native_last_error("async completion has no request codec capability");
        return NemoRelayStatus::InvalidArg;
    };
    let codec = NativeHostLlmRequestCodec(Arc::clone(codec));
    unsafe {
        native_llm_request_codec_encode(
            std::ptr::from_ref(&codec).cast(),
            annotated_json,
            original_json,
            out,
        )
    }
}

unsafe extern "C" fn native_async_completion_llm_response_codec_decode(
    completion: *const NemoRelayNativeAsyncCompletion,
    response_json: *const NemoRelayNativeString,
    out: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    if out.is_null() {
        set_native_last_error("response codec decode output is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null_mut() };
    let completion = match active_async_completion(completion) {
        Ok(completion) => completion,
        Err(status) => return status,
    };
    let Some(NativeAsyncCodecCapability::Response(codec)) = &completion.codec else {
        set_native_last_error("async completion has no response codec capability");
        return NemoRelayStatus::InvalidArg;
    };
    let codec = NativeHostLlmResponseCodec(Arc::clone(codec));
    unsafe {
        native_llm_response_codec_decode(std::ptr::from_ref(&codec).cast(), response_json, out)
    }
}

unsafe extern "C" fn native_async_completion_release(
    completion: *const NemoRelayNativeAsyncCompletion,
) {
    if !completion.is_null() {
        let completion = unsafe { Arc::from_raw(completion as *const NativeAsyncCompletion) };
        if completion._callback_user_data.is_some() {
            defer_native_handle_drop(completion);
        }
    }
}

unsafe extern "C" fn native_async_completion_retain(
    completion: *const NemoRelayNativeAsyncCompletion,
) -> NemoRelayStatus {
    if completion.is_null() {
        return NemoRelayStatus::NullPointer;
    }
    unsafe { Arc::increment_strong_count(completion.cast::<NativeAsyncCompletion>()) };
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_async_next_release(next: *const NemoRelayNativeAsyncNext) {
    if !next.is_null() {
        let next = unsafe { Arc::from_raw(next as *const NativeAsyncNext) };
        if next._callback_user_data.is_some() {
            defer_native_handle_drop(next);
        }
    }
}

/// Drops plugin-owned ABI handles outside the plugin executor thread.
///
/// A handle can own the final dynamic-library guard. Dropping that guard from
/// the SDK executor would unload the library while its release trampoline is
/// still returning through plugin code. The host reaper may begin teardown
/// immediately, but plugin descriptor teardown joins the SDK executor before
/// the guard can unload the library.
fn defer_native_handle_drop(value: impl Send + 'static) {
    type DeferredDrop = Box<dyn Send>;
    static REAPER: OnceLock<Option<std::sync::mpsc::Sender<DeferredDrop>>> = OnceLock::new();
    let sender = REAPER.get_or_init(|| {
        let (sender, receiver) = std::sync::mpsc::channel::<DeferredDrop>();
        std::thread::Builder::new()
            .name("nemo-relay-native-reaper".into())
            .spawn(move || {
                while let Ok(value) = receiver.recv() {
                    drop(value);
                }
            })
            .ok()
            .map(|_| sender)
    });
    let value: DeferredDrop = Box::new(value);
    if let Some(sender) = sender {
        if let Err(error) = sender.send(value) {
            // The only safe fallback is to retain the handle. Synchronously
            // dropping it could unload plugin code on its executor thread.
            tracing::error!(
                target: "nemo_relay.plugin",
                event = "native_plugin_reaper_channel_closed",
                "native plugin reaper channel closed; leaking a deferred plugin handle"
            );
            std::mem::forget(error.0);
        }
    } else {
        tracing::error!(
            target: "nemo_relay.plugin",
            event = "native_plugin_reaper_unavailable",
            "native plugin reaper thread failed to start; leaking deferred plugin handles"
        );
        std::mem::forget(value);
    }
}

unsafe extern "C" fn native_async_stream_push_json(
    stream: *const NemoRelayNativeAsyncStream,
    chunk_json: *const NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    let Some(stream) = (unsafe { (stream as *const NativeAsyncStream).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    if stream.cancelled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    stream.backpressured.store(false, Ordering::Release);
    let chunk = match parse_json_arg(chunk_json, "native async stream chunk") {
        Ok(chunk) => chunk,
        Err(status) => return status,
    };
    #[cfg(test)]
    if let Some(barrier) = &stream.before_settlement_lock {
        barrier.wait();
    }
    let _settlement = stream
        .settlement
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if stream.cancelled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    if stream.settled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    let sender = stream
        .sender
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .clone();
    let Some(sender) = sender else {
        return NemoRelayStatus::InvalidArg;
    };
    match sender.try_send(Ok(chunk)) {
        Ok(()) => NemoRelayStatus::Ok,
        Err(tokio::sync::mpsc::error::TrySendError::Full(_)) => {
            stream.backpressured.store(true, Ordering::Release);
            set_native_last_error(
                "native async stream is backpressured; retry the chunk after the consumer advances",
            );
            NemoRelayStatus::Backpressured
        }
        Err(tokio::sync::mpsc::error::TrySendError::Closed(_)) => NemoRelayStatus::InvalidArg,
    }
}

unsafe extern "C" fn native_async_stream_finish(
    stream: *const NemoRelayNativeAsyncStream,
) -> NemoRelayStatus {
    let Some(stream) = (unsafe { (stream as *const NativeAsyncStream).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    #[cfg(test)]
    if let Some(barrier) = &stream.before_settlement_lock {
        barrier.wait();
    }
    let _settlement = stream
        .settlement
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if stream.cancelled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    if stream.settled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    if stream
        .sender
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .take()
        .is_some()
    {
        stream.settled.store(true, Ordering::Release);
        let mut downstream_aborts = stream
            .downstream_aborts
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        for (_, abort) in downstream_aborts.drain() {
            abort.abort();
        }
        NemoRelayStatus::Ok
    } else {
        NemoRelayStatus::InvalidArg
    }
}

unsafe extern "C" fn native_async_stream_reject(
    stream: *const NemoRelayNativeAsyncStream,
    message: *const NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    let Some(stream) = (unsafe { (stream as *const NativeAsyncStream).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    stream.backpressured.store(false, Ordering::Release);
    let message =
        read_native_string(message).unwrap_or_else(|_| "native async stream rejected".to_string());
    #[cfg(test)]
    if let Some(barrier) = &stream.before_settlement_lock {
        barrier.wait();
    }
    let _settlement = stream
        .settlement
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if stream.cancelled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    if stream.settled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    let mut sender_guard = stream
        .sender
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    let Some(sender) = sender_guard.as_ref() else {
        return NemoRelayStatus::InvalidArg;
    };
    match sender.try_send(Err(FlowError::Internal(message))) {
        Ok(()) => {
            sender_guard.take();
            stream.settled.store(true, Ordering::Release);
            let mut downstream_aborts = stream
                .downstream_aborts
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            for (_, abort) in downstream_aborts.drain() {
                abort.abort();
            }
            NemoRelayStatus::Ok
        }
        Err(tokio::sync::mpsc::error::TrySendError::Full(_)) => {
            stream.backpressured.store(true, Ordering::Release);
            set_native_last_error(
                "native async stream is backpressured; retry rejection after the consumer advances",
            );
            NemoRelayStatus::Backpressured
        }
        Err(tokio::sync::mpsc::error::TrySendError::Closed(_)) => NemoRelayStatus::InvalidArg,
    }
}

unsafe extern "C" fn native_async_stream_is_cancelled(
    stream: *const NemoRelayNativeAsyncStream,
) -> bool {
    unsafe { (stream as *const NativeAsyncStream).as_ref() }
        .is_none_or(|stream| stream.cancelled.load(Ordering::Acquire))
}

unsafe extern "C" fn native_async_stream_is_backpressured(
    stream: *const NemoRelayNativeAsyncStream,
) -> bool {
    unsafe { (stream as *const NativeAsyncStream).as_ref() }
        .is_some_and(|stream| stream.backpressured.load(Ordering::Acquire))
}

unsafe extern "C" fn native_async_stream_release(stream: *const NemoRelayNativeAsyncStream) {
    if !stream.is_null() {
        let stream = unsafe { Arc::from_raw(stream as *const NativeAsyncStream) };
        if stream._callback_user_data.is_some() {
            defer_native_handle_drop(stream);
        }
    }
}

/// Invokes the runtime continuation without blocking the calling native thread.
unsafe extern "C" fn native_async_next_invoke(
    next: *const NemoRelayNativeAsyncNext,
    invocation_json: *const NemoRelayNativeString,
    completion: *const NemoRelayNativeAsyncCompletion,
) -> NemoRelayStatus {
    let Some(next) = (unsafe { (next as *const NativeAsyncNext).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    if completion.is_null() {
        return NemoRelayStatus::NullPointer;
    }
    let invocation = match parse_json_arg(invocation_json, "native async next invocation") {
        Ok(value) => value,
        Err(status) => return status,
    };
    if matches!(&next.inner, NativeAsyncNextInner::LlmStream(_)) {
        set_native_last_error(
            "stream continuations require async_next_invoke_stream; completion-based next cannot buffer a stream",
        );
        return NemoRelayStatus::InvalidArg;
    }
    enum Invocation {
        Tool(Json),
        Llm(LlmRequest),
    }
    let invocation = match &next.inner {
        NativeAsyncNextInner::Tool(_) => Invocation::Tool(invocation),
        NativeAsyncNextInner::Llm(_) => match serde_json::from_value(invocation) {
            Ok(request) => Invocation::Llm(request),
            Err(error) => {
                set_native_last_error(error.to_string());
                return NemoRelayStatus::InvalidJson;
            }
        },
        NativeAsyncNextInner::LlmStream(_) => unreachable!("stream continuations were rejected"),
    };
    unsafe { Arc::increment_strong_count(completion as *const NativeAsyncCompletion) };
    let completion = unsafe { Arc::from_raw(completion as *const NativeAsyncCompletion) };
    if completion.cancelled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    let future: Pin<Box<dyn Future<Output = FlowResult<Json>> + Send>> =
        match (&next.inner, invocation) {
            (NativeAsyncNextInner::Tool(next), Invocation::Tool(invocation)) => {
                let next = next.clone();
                Box::pin(async move {
                    let result = next(invocation).await?;
                    serialize_native_tool_outcome(result.into()).map_err(|error| {
                        FlowError::Internal(format!(
                            "failed to serialize native async tool outcome: {error}"
                        ))
                    })
                })
            }
            (NativeAsyncNextInner::Llm(next), Invocation::Llm(request)) => {
                let next = next.clone();
                Box::pin(async move { next(request).await })
            }
            _ => unreachable!("native next invocation kind matched its continuation"),
        };
    let continuation_context = match host_runtime().isolate_invocation(&next.context) {
        Ok(context) => context,
        Err(error) => return status_from_flow_error(error),
    };
    let mut abort_guard = completion
        .next_abort
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if completion.cancelled.load(Ordering::Acquire) {
        return NemoRelayStatus::InvalidArg;
    }
    let unsettled = completion
        .sender
        .lock()
        .unwrap_or_else(|error| error.into_inner())
        .is_some();
    if !unsettled || completion.next_invoked.swap(true, Ordering::AcqRel) {
        set_native_last_error("native async next was already invoked for this completion");
        return NemoRelayStatus::InvalidArg;
    }
    let (start_tx, start_rx) = tokio::sync::oneshot::channel();
    let completion_for_task = Arc::clone(&completion);
    let task = next.runtime.spawn(async move {
        if start_rx.await.is_err() {
            return;
        }
        let result = AssertUnwindSafe(continuation_context.run(future))
            .catch_unwind()
            .await;
        let result = result.unwrap_or_else(|payload| {
            Err(FlowError::Internal(format!(
                "native async next continuation panicked: {}",
                panic_payload_message(payload.as_ref())
            )))
        });
        completion_for_task
            .next_abort
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .take();
        if let Some(sender) = completion_for_task
            .sender
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .take()
        {
            let _ = sender.send(result);
        }
    });
    let abort = task.abort_handle();
    *abort_guard = Some(abort.clone());
    if completion.cancelled.load(Ordering::Acquire) {
        abort_guard.take();
        abort.abort();
        return NemoRelayStatus::InvalidArg;
    }
    let _ = start_tx.send(());
    NemoRelayStatus::Ok
}

struct NativeAsyncResultCallbackGuard {
    cb: NemoRelayNativeAsyncNextResultCb,
    user_data: usize,
    _library_guard: Option<Arc<NativeCallbackUserData>>,
    active: bool,
}

impl NativeAsyncResultCallbackGuard {
    fn deliver(&mut self, result: FlowResult<Json>) {
        if !self.active {
            return;
        }
        match result {
            Ok(value) => {
                if let Some(value) = native_string_from_json(&value) {
                    unsafe {
                        (self.cb)(self.user_data as *mut c_void, value, ptr::null());
                        native_string_free(value);
                    }
                    self.active = false;
                } else {
                    self.deliver_error("failed to allocate native async next result");
                }
            }
            Err(error) => self.deliver_error(&error.to_string()),
        }
    }

    fn deliver_error(&mut self, message: &str) {
        if let Some(error) = native_string_from_str(message) {
            unsafe {
                (self.cb)(self.user_data as *mut c_void, ptr::null(), error);
                native_string_free(error);
            }
        } else {
            unsafe { (self.cb)(self.user_data as *mut c_void, ptr::null(), ptr::null()) };
        }
        self.active = false;
    }
}

impl Drop for NativeAsyncResultCallbackGuard {
    fn drop(&mut self) {
        if self.active {
            self.deliver_error("native async next continuation was cancelled");
        }
    }
}

trait NativeCallbackGuard {
    fn suppress(&mut self);
    fn fail_internal(&mut self, message: &str);
}

impl NativeCallbackGuard for NativeAsyncResultCallbackGuard {
    fn suppress(&mut self) {
        self.active = false;
    }

    fn fail_internal(&mut self, message: &str) {
        self.deliver_error(message);
    }
}

enum NativeCallbackHandoffState<G> {
    Pending(G),
    Accepted(G),
    TaskDropped(G),
    Complete,
}

struct NativeCallbackRegistration<G> {
    state: Arc<Mutex<NativeCallbackHandoffState<G>>>,
}

struct NativeCallbackTaskGuard<G> {
    state: Arc<Mutex<NativeCallbackHandoffState<G>>>,
    claimed: bool,
}

impl<G: NativeCallbackGuard> NativeCallbackRegistration<G> {
    fn new(guard: G) -> (Self, NativeCallbackTaskGuard<G>) {
        let state = Arc::new(Mutex::new(NativeCallbackHandoffState::Pending(guard)));
        (
            Self {
                state: Arc::clone(&state),
            },
            NativeCallbackTaskGuard {
                state,
                claimed: false,
            },
        )
    }

    fn accept(self) {
        let cancelled = {
            let mut state = self.state.lock().unwrap_or_else(|error| error.into_inner());
            match std::mem::replace(&mut *state, NativeCallbackHandoffState::Complete) {
                NativeCallbackHandoffState::Pending(guard) => {
                    *state = NativeCallbackHandoffState::Accepted(guard);
                    None
                }
                NativeCallbackHandoffState::TaskDropped(guard) => Some(guard),
                NativeCallbackHandoffState::Accepted(guard) => {
                    *state = NativeCallbackHandoffState::Accepted(guard);
                    None
                }
                NativeCallbackHandoffState::Complete => None,
            }
        };
        // Dropping an accepted guard delivers cancellation. Never invoke
        // plugin code while the handoff mutex is held.
        drop(cancelled);
    }

    fn reject(self) {
        let rejected = {
            let mut state = self.state.lock().unwrap_or_else(|error| error.into_inner());
            match std::mem::replace(&mut *state, NativeCallbackHandoffState::Complete) {
                NativeCallbackHandoffState::Pending(guard)
                | NativeCallbackHandoffState::TaskDropped(guard) => Some(guard),
                NativeCallbackHandoffState::Accepted(guard) => {
                    *state = NativeCallbackHandoffState::Accepted(guard);
                    None
                }
                NativeCallbackHandoffState::Complete => None,
            }
        };
        if let Some(mut guard) = rejected {
            guard.suppress();
        }
    }
}

impl<G> NativeCallbackTaskGuard<G> {
    fn claim(mut self) -> Option<std::result::Result<G, G>> {
        let result = {
            let mut state = self.state.lock().unwrap_or_else(|error| error.into_inner());
            match std::mem::replace(&mut *state, NativeCallbackHandoffState::Complete) {
                NativeCallbackHandoffState::Accepted(guard) => Some(Ok(guard)),
                NativeCallbackHandoffState::Pending(guard)
                | NativeCallbackHandoffState::TaskDropped(guard) => Some(Err(guard)),
                NativeCallbackHandoffState::Complete => None,
            }
        };
        self.claimed = true;
        result
    }
}

impl<G> Drop for NativeCallbackTaskGuard<G> {
    fn drop(&mut self) {
        if self.claimed {
            return;
        }
        let cancelled = {
            let mut state = self.state.lock().unwrap_or_else(|error| error.into_inner());
            match std::mem::replace(&mut *state, NativeCallbackHandoffState::Complete) {
                NativeCallbackHandoffState::Pending(guard) => {
                    *state = NativeCallbackHandoffState::TaskDropped(guard);
                    None
                }
                NativeCallbackHandoffState::Accepted(guard) => Some(guard),
                NativeCallbackHandoffState::TaskDropped(guard) => {
                    *state = NativeCallbackHandoffState::TaskDropped(guard);
                    None
                }
                NativeCallbackHandoffState::Complete => None,
            }
        };
        // An accepted registration owes exactly one callback even when its
        // task is aborted before the first poll.
        drop(cancelled);
    }
}

/// Invokes a unary continuation with an independent per-call result callback.
unsafe extern "C" fn native_async_next_invoke_result(
    next: *const NemoRelayNativeAsyncNext,
    invocation_json: *const NemoRelayNativeString,
    cb: NemoRelayNativeAsyncNextResultCb,
    user_data: *mut c_void,
) -> NemoRelayStatus {
    let Some(next) = (unsafe { (next as *const NativeAsyncNext).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    let invocation = match parse_json_arg(invocation_json, "native async next invocation") {
        Ok(value) => value,
        Err(status) => return status,
    };
    let future: Pin<Box<dyn Future<Output = FlowResult<Json>> + Send>> = match &next.inner {
        NativeAsyncNextInner::Tool(next) => {
            let next = next.clone();
            Box::pin(async move {
                let result = next(invocation).await?;
                serialize_native_tool_result(result).map_err(|error| {
                    FlowError::Internal(format!(
                        "failed to serialize native async tool result: {error}"
                    ))
                })
            })
        }
        NativeAsyncNextInner::Llm(next_fn) => {
            let request = match serde_json::from_value(invocation) {
                Ok(request) => request,
                Err(error) => {
                    set_native_last_error(error.to_string());
                    return NemoRelayStatus::InvalidJson;
                }
            };
            let next_fn = next_fn.clone();
            Box::pin(async move { next_fn(request).await })
        }
        NativeAsyncNextInner::LlmStream(_) => {
            set_native_last_error(
                "stream continuations require async_next_invoke_stream; unary result callbacks cannot buffer a stream",
            );
            return NemoRelayStatus::InvalidArg;
        }
    };
    let continuation_context = match host_runtime().isolate_invocation(&next.context) {
        Ok(context) => context,
        Err(error) => return status_from_flow_error(error),
    };
    let owner = next.owner.clone();
    let callback_user_data = next._callback_user_data.clone();
    let user_data = user_data as usize;
    let (start_tx, start_rx) = tokio::sync::oneshot::channel();
    let cleanup_owner = owner.clone();
    let (callback_registration, callback_task) =
        NativeCallbackRegistration::new(NativeAsyncResultCallbackGuard {
            cb,
            user_data,
            _library_guard: callback_user_data,
            active: true,
        });
    let task = next.runtime.spawn(async move {
        if start_rx.await.is_err() {
            return;
        }
        let mut callback_guard = match callback_task.claim() {
            Some(Ok(guard)) => guard,
            Some(Err(mut guard)) => {
                guard
                    .fail_internal("native callback task started before registration was accepted");
                remove_native_next_operation(&cleanup_owner, tokio::task::id());
                return;
            }
            None => {
                log::error!(
                    target: "nemo_relay.runtime",
                    event = "native_callback_handoff_lost";
                    "Native callback registration state completed before its task claimed ownership"
                );
                remove_native_next_operation(&cleanup_owner, tokio::task::id());
                return;
            }
        };
        let result = AssertUnwindSafe(continuation_context.run(future))
            .catch_unwind()
            .await
            .unwrap_or_else(|payload| {
                Err(FlowError::Internal(format!(
                    "native async next continuation panicked: {}",
                    panic_payload_message(payload.as_ref())
                )))
            });
        remove_native_next_operation(&cleanup_owner, tokio::task::id());
        callback_guard.deliver(result);
    });
    let abort = task.abort_handle();
    if !register_native_next_operation(&owner, task.id(), abort.clone()) {
        callback_registration.reject();
        abort.abort();
        return NemoRelayStatus::InvalidArg;
    }
    callback_registration.accept();
    let _ = start_tx.send(());
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_async_next_invoke_stream(
    next: *const NemoRelayNativeAsyncNext,
    invocation_json: *const NemoRelayNativeString,
    output_stream: *const NemoRelayNativeAsyncStream,
    cb: NemoRelayNativeAsyncNextStreamCb,
    user_data: *mut c_void,
) -> NemoRelayStatus {
    let Some(next) = (unsafe { (next as *const NativeAsyncNext).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    if output_stream.is_null() {
        return NemoRelayStatus::NullPointer;
    }
    unsafe { Arc::increment_strong_count(output_stream as *const NativeAsyncStream) };
    let output_stream = unsafe { Arc::from_raw(output_stream as *const NativeAsyncStream) };
    let NativeAsyncNextInner::LlmStream(next_fn) = &next.inner else {
        return NemoRelayStatus::InvalidArg;
    };
    let request = match parse_json_arg(invocation_json, "native async stream next invocation")
        .and_then(|value| {
            serde_json::from_value(value).map_err(|error| {
                set_native_last_error(error.to_string());
                NemoRelayStatus::InvalidJson
            })
        }) {
        Ok(request) => request,
        Err(status) => return status,
    };
    let continuation_context = match host_runtime().isolate_invocation(&next.context) {
        Ok(context) => context,
        Err(error) => return status_from_flow_error(error),
    };
    let _settlement = output_stream
        .settlement
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if output_stream.cancelled.load(Ordering::Acquire)
        || output_stream.settled.load(Ordering::Acquire)
        || output_stream
            .sender
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .is_none()
    {
        return NemoRelayStatus::InvalidArg;
    }
    let mut downstream_aborts = output_stream
        .downstream_aborts
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    let next_fn = next_fn.clone();
    let user_data = user_data as usize;
    let output_stream_for_task = Arc::clone(&output_stream);
    let output_stream_for_cleanup = Arc::clone(&output_stream);
    let callback_guard = NativeAsyncStreamCallbackGuard {
        cb,
        user_data,
        stream: output_stream_for_task,
        _library_guard: next._callback_user_data.clone(),
        active: true,
    };
    let (start_tx, start_rx) = tokio::sync::oneshot::channel();
    let task = next.runtime.spawn(async move {
        if start_rx.await.is_err() {
            return;
        }
        continuation_context
            .run(deliver_native_async_next_stream(
                next_fn,
                request,
                callback_guard,
            ))
            .await;
        output_stream_for_cleanup
            .downstream_aborts
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .remove(&tokio::task::id());
    });
    let abort = task.abort_handle();
    downstream_aborts.insert(task.id(), abort);
    let _ = start_tx.send(());
    NemoRelayStatus::Ok
}

enum NativePullStreamState {
    Idle,
    Pulling(tokio::task::AbortHandle),
    Terminal,
    Cancelled,
}

struct NativePullLlmStream {
    stream: tokio::sync::Mutex<Option<LlmJsonStream>>,
    runtime: tokio::runtime::Handle,
    context: MiddlewareContinuationContext,
    state: Mutex<NativePullStreamState>,
    _library_guard: Option<Arc<NativeCallbackUserData>>,
}

struct NativePullCallbackGuard {
    cb: NemoRelayNativeAsyncLlmStreamPullCb,
    user_data: usize,
    active: bool,
}

struct NativePullOpenCallbackGuard {
    cb: NemoRelayNativeAsyncLlmStreamOpenCb,
    user_data: usize,
    library_guard: Option<Arc<NativeCallbackUserData>>,
    active: bool,
}

impl NativePullOpenCallbackGuard {
    fn fail(&mut self, message: &str) {
        if self.active {
            call_native_pull_open_error(self.cb, self.user_data, message);
            self.active = false;
        }
    }
}

impl Drop for NativePullOpenCallbackGuard {
    fn drop(&mut self) {
        if self.active {
            self.fail("native pull stream open was cancelled");
        }
    }
}

impl NativeCallbackGuard for NativePullOpenCallbackGuard {
    fn suppress(&mut self) {
        self.active = false;
    }

    fn fail_internal(&mut self, message: &str) {
        self.fail(message);
    }
}

impl NativePullCallbackGuard {
    fn deliver(&mut self, result: FlowResult<Option<Json>>) {
        if self.active {
            deliver_native_pull_result(self.cb, self.user_data, result);
            self.active = false;
        }
    }
}

impl Drop for NativePullCallbackGuard {
    fn drop(&mut self) {
        if self.active {
            deliver_native_pull_result(
                self.cb,
                self.user_data,
                Err(FlowError::Internal(
                    "native pull stream was cancelled".into(),
                )),
            );
        }
    }
}

unsafe extern "C" fn native_async_next_open_llm_stream(
    next: *const NemoRelayNativeAsyncNext,
    request_json: *const NemoRelayNativeString,
    cb: NemoRelayNativeAsyncLlmStreamOpenCb,
    user_data: *mut c_void,
) -> NemoRelayStatus {
    let Some(next) = (unsafe { (next as *const NativeAsyncNext).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    let NativeAsyncNextInner::LlmStream(next_fn) = &next.inner else {
        set_native_last_error("pull streams require an LLM stream continuation");
        return NemoRelayStatus::InvalidArg;
    };
    let request = match parse_llm_request_arg(request_json, "native async stream request") {
        Ok(request) => request,
        Err(status) => return status,
    };
    let context = match host_runtime().isolate_invocation(&next.context) {
        Ok(context) => context,
        Err(error) => return status_from_flow_error(error),
    };
    let next_fn = next_fn.clone();
    let runtime = next.runtime.clone();
    let stream_runtime = runtime.clone();
    let stream_context = context.clone();
    let owner = next.owner.clone();
    let callback_user_data = next._callback_user_data.clone();
    let user_data = user_data as usize;
    let cleanup_owner = owner.clone();
    let (start_tx, start_rx) = tokio::sync::oneshot::channel();
    let (callback_registration, callback_task) =
        NativeCallbackRegistration::new(NativePullOpenCallbackGuard {
            cb,
            user_data,
            library_guard: callback_user_data,
            active: true,
        });
    let task = runtime.spawn(async move {
        if start_rx.await.is_err() {
            return;
        }
        let mut callback_guard = match callback_task.claim() {
            Some(Ok(guard)) => guard,
            Some(Err(mut guard)) => {
                guard.fail_internal(
                    "native callback task started before registration was accepted",
                );
                remove_native_next_operation(&cleanup_owner, tokio::task::id());
                return;
            }
            None => {
                log::error!(
                    target: "nemo_relay.runtime",
                    event = "native_callback_handoff_lost";
                    "Native stream-open callback registration state completed before its task claimed ownership"
                );
                remove_native_next_operation(&cleanup_owner, tokio::task::id());
                return;
            }
        };
        let result = AssertUnwindSafe(context.run(next_fn(request)))
            .catch_unwind()
            .await;
        remove_native_next_operation(&cleanup_owner, tokio::task::id());
        match result {
            Ok(Ok(stream)) => {
                let stream = Arc::new(NativePullLlmStream {
                    stream: tokio::sync::Mutex::new(Some(stream)),
                    runtime: stream_runtime,
                    context: stream_context,
                    state: Mutex::new(NativePullStreamState::Idle),
                    _library_guard: callback_guard.library_guard.take(),
                });
                unsafe {
                    (callback_guard.cb)(
                        callback_guard.user_data as *mut c_void,
                        Arc::into_raw(stream).cast(),
                        ptr::null(),
                    )
                };
                callback_guard.active = false;
            }
            Ok(Err(error)) => callback_guard.fail(&error.to_string()),
            Err(payload) => callback_guard.fail(&format!(
                "native async stream continuation panicked: {}",
                panic_payload_message(payload.as_ref())
            )),
        }
    });
    let abort = task.abort_handle();
    if !register_native_next_operation(&owner, task.id(), abort.clone()) {
        callback_registration.reject();
        abort.abort();
        return NemoRelayStatus::InvalidArg;
    }
    callback_registration.accept();
    let _ = start_tx.send(());
    NemoRelayStatus::Ok
}

fn call_native_pull_open_error(
    cb: NemoRelayNativeAsyncLlmStreamOpenCb,
    user_data: usize,
    message: &str,
) {
    if let Some(error) = native_string_from_str(message) {
        unsafe {
            cb(user_data as *mut c_void, ptr::null(), error);
            native_string_free(error);
        }
    } else {
        unsafe { cb(user_data as *mut c_void, ptr::null(), ptr::null()) };
    }
}

unsafe extern "C" fn native_async_llm_stream_pull(
    stream: *const NemoRelayNativeLlmAsyncStream,
    cb: NemoRelayNativeAsyncLlmStreamPullCb,
    user_data: *mut c_void,
) -> NemoRelayStatus {
    let Some(stream) = (unsafe { (stream as *const NativePullLlmStream).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    let mut state = stream
        .state
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if !matches!(*state, NativePullStreamState::Idle) {
        set_native_last_error("native pull stream is busy, terminal, or cancelled");
        return NemoRelayStatus::InvalidArg;
    }
    unsafe { Arc::increment_strong_count(stream as *const NativePullLlmStream) };
    let stream = unsafe { Arc::from_raw(stream as *const NativePullLlmStream) };
    let task_stream = Arc::clone(&stream);
    let context = stream.context.clone();
    let user_data = user_data as usize;
    let callback_guard = NativePullCallbackGuard {
        cb,
        user_data,
        active: true,
    };
    let (start_tx, start_rx) = tokio::sync::oneshot::channel();
    let task = stream.runtime.spawn(async move {
        let mut callback_guard = callback_guard;
        if start_rx.await.is_err() {
            return;
        }
        let result = AssertUnwindSafe(context.run(async {
            let mut guard = task_stream.stream.lock().await;
            match guard.as_mut() {
                Some(stream) => match stream.next().await {
                    Some(Ok(chunk)) => Ok(Some(chunk)),
                    Some(Err(error)) => {
                        guard.take();
                        Err(error)
                    }
                    None => {
                        guard.take();
                        Ok(None)
                    }
                },
                None => Ok(None),
            }
        }))
        .catch_unwind()
        .await
        .unwrap_or_else(|payload| {
            Err(FlowError::Internal(format!(
                "native pull stream panicked: {}",
                panic_payload_message(payload.as_ref())
            )))
        });
        let cancelled = {
            let mut state = task_stream
                .state
                .lock()
                .unwrap_or_else(|error| error.into_inner());
            if matches!(*state, NativePullStreamState::Cancelled) {
                true
            } else {
                *state = if matches!(result, Ok(Some(_))) {
                    NativePullStreamState::Idle
                } else {
                    NativePullStreamState::Terminal
                };
                false
            }
        };
        if !cancelled {
            callback_guard.deliver(result);
        } else {
            callback_guard.deliver(Err(FlowError::Internal(
                "native pull stream was cancelled".into(),
            )));
        }
    });
    *state = NativePullStreamState::Pulling(task.abort_handle());
    drop(state);
    let _ = start_tx.send(());
    NemoRelayStatus::Ok
}

fn deliver_native_pull_result(
    cb: NemoRelayNativeAsyncLlmStreamPullCb,
    user_data: usize,
    result: FlowResult<Option<Json>>,
) {
    match result {
        Ok(Some(chunk)) => {
            if let Some(chunk) = native_string_from_json(&chunk) {
                unsafe {
                    cb(user_data as *mut c_void, chunk, ptr::null(), false);
                    native_string_free(chunk);
                }
            } else {
                deliver_native_pull_result(
                    cb,
                    user_data,
                    Err(FlowError::Internal(
                        "failed to allocate stream chunk".into(),
                    )),
                );
            }
        }
        Ok(None) => unsafe { cb(user_data as *mut c_void, ptr::null(), ptr::null(), true) },
        Err(error) => {
            if let Some(error) = native_string_from_str(&error.to_string()) {
                unsafe {
                    cb(user_data as *mut c_void, ptr::null(), error, true);
                    native_string_free(error);
                }
            } else {
                unsafe { cb(user_data as *mut c_void, ptr::null(), ptr::null(), true) };
            }
        }
    }
}

unsafe extern "C" fn native_async_llm_stream_cancel(
    stream: *const NemoRelayNativeLlmAsyncStream,
) -> NemoRelayStatus {
    let Some(stream) = (unsafe { (stream as *const NativePullLlmStream).as_ref() }) else {
        return NemoRelayStatus::NullPointer;
    };
    let mut state = stream
        .state
        .lock()
        .unwrap_or_else(|error| error.into_inner());
    if let NativePullStreamState::Pulling(abort) = &*state {
        abort.abort();
    }
    if matches!(
        *state,
        NativePullStreamState::Terminal | NativePullStreamState::Cancelled
    ) {
        return NemoRelayStatus::InvalidArg;
    }
    *state = NativePullStreamState::Cancelled;
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_async_llm_stream_release(stream: *const NemoRelayNativeLlmAsyncStream) {
    if !stream.is_null() {
        let stream = unsafe { Arc::from_raw(stream as *const NativePullLlmStream) };
        let _ = unsafe { native_async_llm_stream_cancel(Arc::as_ptr(&stream).cast()) };
        if stream._library_guard.is_some() {
            defer_native_handle_drop(stream);
        }
    }
}

async fn deliver_native_async_next_stream(
    next_fn: LlmStreamExecutionNextFn,
    request: LlmRequest,
    mut callback_guard: NativeAsyncStreamCallbackGuard,
) {
    let result = AssertUnwindSafe(async {
        match next_fn(request).await {
            Ok(stream) => forward_native_async_next_stream(stream, &mut callback_guard).await,
            Err(error) => callback_guard.fail(&error.to_string()),
        }
    })
    .catch_unwind()
    .await;
    if let Err(payload) = result {
        callback_guard.fail(&format!(
            "native async stream continuation panicked: {}",
            panic_payload_message(payload.as_ref())
        ));
    }
}

async fn forward_native_async_next_stream(
    stream: LlmJsonStream,
    callback_guard: &mut NativeAsyncStreamCallbackGuard,
) {
    forward_native_async_next_stream_with(stream, callback_guard, native_string_from_json).await;
}

async fn forward_native_async_next_stream_with(
    mut stream: LlmJsonStream,
    callback_guard: &mut NativeAsyncStreamCallbackGuard,
    to_native_string: impl Fn(&Json) -> Option<*mut NemoRelayNativeString>,
) {
    while let Some(item) = stream.next().await {
        match item {
            Ok(chunk) => {
                let Some(chunk) = to_native_string(&chunk) else {
                    callback_guard.fail(
                        "failed to serialize or allocate native async stream continuation chunk",
                    );
                    return;
                };
                let keep_going = unsafe {
                    (callback_guard.cb)(
                        callback_guard.user_data as *mut c_void,
                        chunk,
                        ptr::null(),
                        false,
                    )
                };
                unsafe { native_string_free(chunk) };
                if !keep_going {
                    callback_guard.finish();
                    return;
                }
            }
            Err(error) => {
                callback_guard.fail(&error.to_string());
                return;
            }
        }
    }
    unsafe {
        let _ = (callback_guard.cb)(
            callback_guard.user_data as *mut c_void,
            ptr::null(),
            ptr::null(),
            true,
        );
    }
    callback_guard.finish();
}

fn wrap_native_async_tool_json(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> ToolSanitizeFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, value| {
        let user_data = user_data.clone();
        Box::pin(async move {
            let value = invoke_native_async_callback(
                cb,
                user_data,
                serde_json::json!({"name": name, "value": value}),
                None,
                None,
            )
            .await?;
            Ok(value)
        })
    })
}

fn wrap_native_async_tool_conditional(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> ToolConditionalFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, value| {
        let user_data = user_data.clone();
        Box::pin(async move {
            match invoke_native_async_callback(
                cb,
                user_data,
                serde_json::json!({"name": name, "value": value}),
                None,
                None,
            )
            .await?
            {
                Json::Null => Ok(None),
                Json::String(reason) => Ok(Some(reason)),
                other => Err(FlowError::Internal(format!(
                    "native async tool conditional callback returned {other}; expected string or null"
                ))),
            }
        })
    })
}

fn wrap_native_async_llm_conditional(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmConditionalFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |request| {
        let user_data = user_data.clone();
        Box::pin(async move {
            match invoke_native_async_callback(
                cb,
                user_data,
                serde_json::json!({"request": request}),
                None,
                None,
            )
            .await?
            {
                Json::Null => Ok(None),
                Json::String(reason) => Ok(Some(reason)),
                other => Err(FlowError::Internal(format!(
                    "native async LLM conditional callback returned {other}; expected string or null"
                ))),
            }
        })
    })
}

fn wrap_native_async_llm_sanitize_request(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmSanitizeRequestFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |request, context| {
        let user_data = user_data.clone();
        let codec = native_async_codec_identity(context.codec());
        let capability = context
            .resolve_codec()
            .map(NativeAsyncCodecCapability::Request);
        Box::pin(async move {
            let value = invoke_native_async_callback(
                cb,
                user_data,
                serde_json::json!({"request": request, "context": codec}),
                None,
                capability,
            )
            .await?;
            if value.is_null() {
                Ok(None)
            } else {
                serde_json::from_value(value)
                    .map(Some)
                    .map_err(|error| FlowError::Internal(error.to_string()))
            }
        })
    })
}

fn wrap_native_async_llm_sanitize_response(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmSanitizeResponseFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |response, context| {
        let user_data = user_data.clone();
        let codec = native_async_codec_identity(context.codec());
        let capability = context
            .resolve_codec()
            .map(NativeAsyncCodecCapability::Response);
        Box::pin(async move {
            let value = invoke_native_async_callback(
                cb,
                user_data,
                serde_json::json!({"response": response, "context": codec}),
                None,
                capability,
            )
            .await?;
            Ok((!value.is_null()).then_some(value))
        })
    })
}

fn native_async_codec_identity(identity: &LlmCodecIdentity) -> Json {
    match identity {
        LlmCodecIdentity::None => {
            serde_json::json!({"codec_kind": "none", "codec_id": Json::Null})
        }
        LlmCodecIdentity::BuiltIn(codec) => {
            serde_json::json!({"codec_kind": "builtin", "codec_id": codec.id()})
        }
        LlmCodecIdentity::Runtime(id) => {
            serde_json::json!({"codec_kind": "runtime", "codec_id": id})
        }
        LlmCodecIdentity::Opaque => {
            serde_json::json!({"codec_kind": "opaque", "codec_id": Json::Null})
        }
    }
}

fn wrap_native_async_llm_request_intercept(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmRequestInterceptFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, request, annotated| {
        let user_data = user_data.clone();
        Box::pin(async move {
            serde_json::from_value(
                invoke_native_async_callback(
                    cb,
                    user_data,
                    serde_json::json!({
                        "name": name,
                        "request": request,
                        "annotated": annotated,
                    }),
                    None,
                    None,
                )
                .await?,
            )
            .map_err(|error| {
                FlowError::Internal(format!(
                    "invalid native async LLM intercept outcome: {error}"
                ))
            })
        })
    })
}

fn wrap_native_async_event_sanitize(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> EventSanitizeFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |event, fields| {
        let user_data = user_data.clone();
        Box::pin(async move {
            serde_json::from_value(
                invoke_native_async_callback(
                    cb,
                    user_data,
                    serde_json::json!({"event": event, "fields": fields}),
                    None,
                    None,
                )
                .await?,
            )
            .map_err(|error| {
                FlowError::Internal(format!("invalid native async event fields: {error}"))
            })
        })
    })
}

fn wrap_native_async_event_metadata_injector(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> EventMetadataInjectorFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |event| {
        let user_data = user_data.clone();
        Box::pin(async move {
            serde_json::from_value::<BTreeMap<String, Json>>(
                invoke_native_async_callback(
                    cb,
                    user_data,
                    serde_json::json!({"event": event}),
                    None,
                    None,
                )
                .await?,
            )
            .map_err(|error| {
                FlowError::Internal(format!(
                    "invalid native async Event metadata additions: {error}"
                ))
            })
        })
    })
}

fn wrap_native_async_tool_execution(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> ToolExecutionFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, args, next| {
        let user_data = user_data.clone();
        let invocation = serde_json::json!({"name": name, "value": args});
        Box::pin(async move {
            let outcome = invoke_native_async_callback(
                cb,
                user_data,
                invocation,
                Some(NativeAsyncNextInner::Tool(next)),
                None,
            )
            .await?;
            deserialize_native_tool_outcome(outcome).map_err(|error| {
                FlowError::Internal(format!("invalid native async tool outcome: {error}"))
            })
        })
    })
}

fn wrap_native_async_llm_execution(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmExecutionFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, request, next| {
        let user_data = user_data.clone();
        let name = name.to_owned();
        Box::pin(async move {
            invoke_native_async_callback(
                cb,
                user_data,
                serde_json::json!({"name": name, "request": request}),
                Some(NativeAsyncNextInner::Llm(next)),
                None,
            )
            .await
        })
    })
}

fn wrap_native_incremental_llm_stream_execution(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeAsyncStreamMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmStreamExecutionFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    wrap_native_incremental_llm_stream_execution_with_user_data(cb, user_data)
}

fn wrap_native_incremental_llm_stream_execution_with_user_data(
    cb: NemoRelayNativeAsyncStreamMiddlewareCb,
    user_data: Arc<NativeCallbackUserData>,
) -> LlmStreamExecutionFn {
    Arc::new(move |name, request, next| {
        let user_data = user_data.clone();
        let name = name.to_owned();
        Box::pin(async move {
            let (sender, receiver) =
                tokio::sync::mpsc::channel(NATIVE_ASYNC_STREAM_CHANNEL_CAPACITY);
            let stream = Arc::new(NativeAsyncStream {
                sender: Mutex::new(Some(sender)),
                cancelled: AtomicBool::new(false),
                settled: AtomicBool::new(false),
                backpressured: AtomicBool::new(false),
                downstream_aborts: Mutex::new(HashMap::new()),
                settlement: Mutex::new(()),
                #[cfg(test)]
                before_settlement_lock: None,
                _callback_user_data: Some(user_data.clone()),
            });
            let output = NativeAsyncStreamReceiver {
                receiver,
                stream: Arc::clone(&stream),
            };
            let state = {
                let invocation =
                    native_string_from_json(&serde_json::json!({"name": name, "request": request}))
                        .ok_or_else(|| {
                            FlowError::Internal(
                                "failed to allocate native async stream invocation".into(),
                            )
                        })?;
                let runtime = tokio::runtime::Handle::try_current().map_err(|error| {
                    FlowError::Internal(format!(
                        "native async stream intercept requires a Tokio runtime: {error}"
                    ))
                })?;
                let next_ref = Arc::into_raw(Arc::new(NativeAsyncNext::with_stream_owner(
                    NativeAsyncNextInner::LlmStream(next),
                    runtime,
                    Some(user_data.clone()),
                    &stream,
                )));
                let stream_ref = Arc::into_raw(stream.clone());
                let previous_thread_stack = capture_thread_scope_stack();
                sync_thread_scope_stack(current_scope_stack());
                let state = catch_unwind(AssertUnwindSafe(|| unsafe {
                    cb(
                        user_data.ptr,
                        invocation,
                        next_ref as *const NemoRelayNativeAsyncNext,
                        stream_ref as *const NemoRelayNativeAsyncStream,
                    )
                }));
                restore_thread_scope_stack(previous_thread_stack);
                unsafe { native_string_free(invocation) };
                state
                    .ok()
                    .and_then(|state| NemoRelayNativeAsyncCallbackState::try_from(state).ok())
                    .ok_or_else(|| {
                        FlowError::Internal(
                            "native async stream callback panicked or returned an invalid state"
                                .into(),
                        )
                    })?
            };
            if state == NemoRelayNativeAsyncCallbackState::Complete
                && stream
                    .sender
                    .lock()
                    .unwrap_or_else(|error| error.into_inner())
                    .is_some()
            {
                return Err(FlowError::Internal(
                    "native async stream callback returned Complete without finishing".into(),
                ));
            }
            Ok(LlmJsonStream::new(output))
        })
    })
}

unsafe extern "C" fn native_plugin_context_register_async_stream_middleware(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    cb: NemoRelayNativeAsyncStreamMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let user_data_guard = NativeCallbackUserDataGuard::new(user_data, free_fn);
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let (user_data, free_fn) = user_data_guard.transfer();
    let context = unsafe { &mut *host_ctx.ctx };
    match context.register_llm_stream_execution_intercept(
        &name,
        priority,
        wrap_native_incremental_llm_stream_execution(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                context,
                RuntimeRegistrationKind::LlmStreamExecutionIntercept,
                &name,
                Some(priority),
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(error) => status_from_plugin_error(error),
    }
}

unsafe extern "C" fn native_plugin_context_register_async_middleware(
    ctx: *mut NemoRelayNativePluginContext,
    kind: u32,
    name: *const NemoRelayNativeString,
    priority: i32,
    break_chain: bool,
    cb: NemoRelayNativeAsyncMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    // The host owns callback user data as soon as registration is attempted,
    // including malformed and incompatible registrations.
    let user_data_guard = NativeCallbackUserDataGuard::new(user_data, free_fn);
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let kind = match NemoRelayNativeAsyncMiddlewareKind::try_from(kind) {
        Ok(kind) => kind,
        Err(()) => {
            set_native_last_error("invalid native async middleware kind");
            return NemoRelayStatus::InvalidArg;
        }
    };
    if kind == NemoRelayNativeAsyncMiddlewareKind::LlmStreamExecutionIntercept {
        set_native_last_error(
            "completion-based LLM stream middleware is unsupported; use plugin_context_register_async_stream_middleware",
        );
        return NemoRelayStatus::InvalidArg;
    }
    if kind == NemoRelayNativeAsyncMiddlewareKind::LlmRequestIntercept
        && let Err(error) = host_runtime()
            .validate_request_consumer_compatibility(&instance.relay_compat, &instance.plugin_kind)
    {
        return status_from_plugin_error(error);
    }
    let (user_data, free_fn) = user_data_guard.transfer();
    let context = unsafe { &mut *host_ctx.ctx };
    // The attachment point each kind installs itself at. This mirrors the
    // registration arms below, and both are exhaustive so a kind the ABI gains
    // cannot be handled by one without the other.
    let operation = match kind {
        NemoRelayNativeAsyncMiddlewareKind::ToolSanitizeRequest => {
            RuntimeRegistrationKind::ToolSanitizeRequestGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::ToolSanitizeResponse => {
            RuntimeRegistrationKind::ToolSanitizeResponseGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::ToolConditionalExecution => {
            RuntimeRegistrationKind::ToolConditionalExecutionGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::ToolRequestIntercept => {
            RuntimeRegistrationKind::ToolRequestIntercept
        }
        NemoRelayNativeAsyncMiddlewareKind::ToolExecutionIntercept => {
            RuntimeRegistrationKind::ToolExecutionIntercept
        }
        NemoRelayNativeAsyncMiddlewareKind::LlmSanitizeRequest => {
            RuntimeRegistrationKind::LlmSanitizeRequestGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::LlmSanitizeResponse => {
            RuntimeRegistrationKind::LlmSanitizeResponseGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::LlmConditionalExecution => {
            RuntimeRegistrationKind::LlmConditionalExecutionGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::LlmRequestIntercept => {
            RuntimeRegistrationKind::LlmRequestIntercept
        }
        NemoRelayNativeAsyncMiddlewareKind::LlmExecutionIntercept => {
            RuntimeRegistrationKind::LlmExecutionIntercept
        }
        NemoRelayNativeAsyncMiddlewareKind::MarkSanitize => {
            RuntimeRegistrationKind::MarkSanitizeGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::ScopeSanitizeStart => {
            RuntimeRegistrationKind::ScopeSanitizeStartGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::ScopeSanitizeEnd => {
            RuntimeRegistrationKind::ScopeSanitizeEndGuardrail
        }
        NemoRelayNativeAsyncMiddlewareKind::EventMetadataInjector => {
            RuntimeRegistrationKind::EventMetadataInjector
        }
        NemoRelayNativeAsyncMiddlewareKind::LlmStreamExecutionIntercept => {
            unreachable!("completion-based stream middleware was rejected before registration")
        }
    };
    // Kept for the record: each arm below hands the instance to a callback
    // wrapper, and the registration still has to be recorded against it.
    let recorded_instance = instance.clone();
    let registration = match kind {
        NemoRelayNativeAsyncMiddlewareKind::ToolSanitizeRequest => context
            .register_tool_sanitize_request_guardrail(
                &name,
                priority,
                wrap_native_async_tool_json(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::ToolSanitizeResponse => context
            .register_tool_sanitize_response_guardrail(
                &name,
                priority,
                wrap_native_async_tool_json(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::ToolConditionalExecution => context
            .register_tool_conditional_execution_guardrail(
                &name,
                priority,
                wrap_native_async_tool_conditional(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::ToolRequestIntercept => context
            .register_tool_request_intercept(
                &name,
                priority,
                break_chain,
                wrap_native_async_tool_json(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::ToolExecutionIntercept => context
            .register_tool_execution_intercept(
                &name,
                priority,
                wrap_native_async_tool_execution(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::LlmSanitizeRequest => context
            .register_llm_sanitize_request_guardrail(
                &name,
                priority,
                wrap_native_async_llm_sanitize_request(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::LlmSanitizeResponse => context
            .register_llm_sanitize_response_guardrail(
                &name,
                priority,
                wrap_native_async_llm_sanitize_response(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::LlmConditionalExecution => context
            .register_llm_conditional_execution_guardrail(
                &name,
                priority,
                wrap_native_async_llm_conditional(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::LlmRequestIntercept => context
            .register_llm_request_intercept(
                &name,
                priority,
                break_chain,
                wrap_native_async_llm_request_intercept(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::LlmExecutionIntercept => context
            .register_llm_execution_intercept(
                &name,
                priority,
                wrap_native_async_llm_execution(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::LlmStreamExecutionIntercept => {
            unreachable!("completion-based stream middleware was rejected before registration")
        }
        NemoRelayNativeAsyncMiddlewareKind::MarkSanitize => context
            .register_mark_sanitize_guardrail(
                &name,
                priority,
                wrap_native_async_event_sanitize(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::ScopeSanitizeStart => context
            .register_scope_sanitize_start_guardrail(
                &name,
                priority,
                wrap_native_async_event_sanitize(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::ScopeSanitizeEnd => context
            .register_scope_sanitize_end_guardrail(
                &name,
                priority,
                wrap_native_async_event_sanitize(instance, cb, user_data, free_fn),
            ),
        NemoRelayNativeAsyncMiddlewareKind::EventMetadataInjector => context
            .register_event_metadata_injector(
                &name,
                priority,
                wrap_native_async_event_metadata_injector(instance, cb, user_data, free_fn),
            ),
    };
    match registration {
        Ok(()) => {
            record_native_registration(
                &recorded_instance,
                context,
                operation,
                &name,
                Some(priority),
                Some(break_chain),
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(error) => status_from_plugin_error(error),
    }
}

fn host_ctx_mut<'a>(
    ctx: *mut NemoRelayNativePluginContext,
) -> Result<&'a mut NativeHostPluginContext, NemoRelayStatus> {
    if ctx.is_null() {
        set_native_last_error("plugin context is null");
        return Err(NemoRelayStatus::NullPointer);
    }
    let ctx = unsafe { &mut *(ctx as *mut NativeHostPluginContext) };
    if ctx.ctx.is_null() {
        set_native_last_error("plugin context inner pointer is null");
        return Err(NemoRelayStatus::NullPointer);
    }
    Ok(ctx)
}

fn native_runtime_ref<'a>(
    runtime: *const NemoRelayNativePluginRuntime,
) -> Result<&'a NativeHostPluginRuntime, NemoRelayStatus> {
    if runtime.is_null() {
        set_native_last_error("plugin runtime capability is null");
        return Err(NemoRelayStatus::NullPointer);
    }
    let runtime = unsafe { &*(runtime as *const NativeHostPluginRuntime) };
    if !runtime.active.load(Ordering::Acquire) {
        set_native_last_error("plugin runtime capability is no longer active");
        return Err(NemoRelayStatus::NotFound);
    }
    Ok(runtime)
}

fn read_runtime_registration_kinds(
    kinds_json: *const NemoRelayNativeString,
) -> Result<BTreeSet<RuntimeRegistrationKind>, NemoRelayStatus> {
    let text = read_native_string(kinds_json).map_err(status_from_plugin_error)?;
    serde_json::from_str(&text).map_err(|error| {
        set_native_last_error(format!("invalid runtime registration kinds: {error}"));
        NemoRelayStatus::InvalidArg
    })
}

unsafe extern "C" fn native_plugin_context_runtime(
    ctx: *mut NemoRelayNativePluginContext,
    out: *mut *const NemoRelayNativePluginRuntime,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out.is_null() {
        set_native_last_error("plugin runtime output is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out = ptr::null() };
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let context = unsafe { &*host_ctx.ctx };
    let namespace = context.qualify_name("");
    let runtime = Arc::new(NativeHostPluginRuntime {
        namespace,
        encode_local_names: host_runtime().qualifies_component_names(context),
        instance: Arc::downgrade(&host_ctx.instance),
        active: AtomicBool::new(true),
        gates: Mutex::new(HashMap::new()),
    });
    let cleanup_runtime = Arc::clone(&runtime);
    unsafe { &mut *host_ctx.ctx }.add_registration(PluginRegistration::new(
        "native-plugin-runtime",
        format!("runtime-{}", Uuid::now_v7()),
        Box::new(move || cleanup_runtime.cleanup()),
    ));
    unsafe { *out = Arc::into_raw(runtime).cast() };
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_plugin_runtime_retain(
    runtime: *const NemoRelayNativePluginRuntime,
) -> NemoRelayStatus {
    clear_native_last_error();
    if let Err(status) = native_runtime_ref(runtime) {
        return status;
    }
    unsafe { Arc::increment_strong_count(runtime.cast::<NativeHostPluginRuntime>()) };
    NemoRelayStatus::Ok
}

unsafe extern "C" fn native_plugin_runtime_release(runtime: *const NemoRelayNativePluginRuntime) {
    if !runtime.is_null() {
        unsafe { Arc::decrement_strong_count(runtime.cast::<NativeHostPluginRuntime>()) };
    }
}

unsafe extern "C" fn native_plugin_runtime_list_registrations(
    runtime: *const NemoRelayNativePluginRuntime,
    kinds_json: *const NemoRelayNativeString,
    out_json: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out_json.is_null() {
        set_native_last_error("runtime registration output is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out_json = ptr::null_mut() };
    if let Err(status) = native_runtime_ref(runtime) {
        return status;
    }
    let kinds = if kinds_json.is_null() {
        None
    } else {
        match read_runtime_registration_kinds(kinds_json) {
            Ok(kinds) => Some(kinds),
            Err(status) => return status,
        }
    };
    match list_runtime_registrations(kinds.as_ref()) {
        Ok(registrations) => match serde_json::to_value(registrations)
            .ok()
            .and_then(|registrations| native_string_from_json(&registrations))
        {
            Some(value) => {
                unsafe { *out_json = value };
                NemoRelayStatus::Ok
            }
            None => {
                set_native_last_error("failed to serialize runtime registrations");
                NemoRelayStatus::Internal
            }
        },
        Err(error) => status_from_flow_error(error),
    }
}

unsafe extern "C" fn native_plugin_runtime_register_conditional_middleware_guardrail(
    runtime: *const NemoRelayNativePluginRuntime,
    name: *const NemoRelayNativeString,
    kinds_json: *const NemoRelayNativeString,
    registration_name: *const NemoRelayNativeString,
    reason: *const NemoRelayNativeString,
    out_handle: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out_handle.is_null() {
        set_native_last_error("conditional middleware guardrail handle output is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out_handle = ptr::null_mut() };
    let runtime = match native_runtime_ref(runtime) {
        Ok(runtime) => runtime,
        Err(status) => return status,
    };
    let local_name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let kinds = match read_runtime_registration_kinds(kinds_json) {
        Ok(kinds) => kinds,
        Err(status) => return status,
    };
    let registration_name = match read_name(registration_name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let reason = match read_name(reason) {
        Ok(reason) => reason,
        Err(status) => return status,
    };
    register_native_owned_gate(
        runtime,
        local_name,
        kinds,
        registration_name,
        Arc::new(move |_, _| Some(reason.clone())),
        out_handle,
    )
}

unsafe extern "C" fn native_plugin_runtime_register_conditional_middleware_guardrail_callback(
    runtime: *const NemoRelayNativePluginRuntime,
    name: *const NemoRelayNativeString,
    kinds_json: *const NemoRelayNativeString,
    registration_name: *const NemoRelayNativeString,
    cb: NemoRelayNativeConditionalMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
    out_handle: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    let user_data_guard = NativeCallbackUserDataGuard::new(user_data, free_fn);
    if out_handle.is_null() {
        set_native_last_error("conditional middleware guardrail handle output is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out_handle = ptr::null_mut() };
    let runtime = match native_runtime_ref(runtime) {
        Ok(runtime) => runtime,
        Err(status) => return status,
    };
    let local_name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let kinds = match read_runtime_registration_kinds(kinds_json) {
        Ok(kinds) => kinds,
        Err(status) => return status,
    };
    let registration_name = match read_name(registration_name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let Some(instance) = runtime.instance.upgrade() else {
        set_native_last_error("native plugin instance is no longer active");
        return NemoRelayStatus::NotFound;
    };
    let (user_data, free_fn) = user_data_guard.transfer();
    let guardrail = wrap_conditional_middleware_guardrail(instance, cb, user_data, free_fn);
    register_native_owned_gate(
        runtime,
        local_name,
        kinds,
        registration_name,
        guardrail,
        out_handle,
    )
}

fn register_native_owned_gate(
    runtime: &NativeHostPluginRuntime,
    local_name: String,
    kinds: BTreeSet<RuntimeRegistrationKind>,
    registration_name: String,
    guardrail: ConditionalMiddlewareGuardrailFn,
    out_handle: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    let mut gates = match runtime.gates.lock() {
        Ok(gates) => gates,
        Err(error) => {
            set_native_last_error(format!("native gate lock poisoned: {error}"));
            return NemoRelayStatus::Internal;
        }
    };
    if !runtime.active.load(Ordering::Acquire) {
        set_native_last_error("plugin runtime capability is no longer active");
        return NemoRelayStatus::NotFound;
    }
    if gates.values().any(|gate| gate.local_name == local_name) {
        set_native_last_error(format!(
            "conditional middleware guardrail '{local_name}' already exists for this activation"
        ));
        return NemoRelayStatus::AlreadyExists;
    }
    let handle = format!("gate-{}", Uuid::now_v7());
    let qualified_name = if runtime.encode_local_names {
        format!(
            "{}{}",
            runtime.namespace,
            host_runtime().qualify_component_field(&local_name)
        )
    } else {
        format!("{}{}", runtime.namespace, local_name)
    };
    if let Err(error) = register_conditional_middleware_guardrail(
        &qualified_name,
        kinds.clone(),
        &registration_name,
        guardrail,
    ) {
        return status_from_flow_error(error);
    }
    // Kept for the record: the ownership entry takes the names, and a gate that
    // fails to hand back a handle is rolled back above without ever being
    // recorded.
    let recorded_local_name = local_name.clone();
    let recorded_qualified_name = qualified_name.clone();
    gates.insert(
        handle.clone(),
        NativeOwnedGate {
            local_name,
            qualified_name,
        },
    );
    match native_string_from_str(&handle) {
        Some(value) => {
            if let Some(instance) = runtime.instance.upgrade() {
                record_native_gate_at(
                    &instance,
                    &recorded_local_name,
                    &recorded_qualified_name,
                    &kinds,
                    &registration_name,
                );
            }
            unsafe { *out_handle = value };
            NemoRelayStatus::Ok
        }
        None => {
            let Some(gate) = gates.remove(&handle) else {
                return NemoRelayStatus::Internal;
            };
            let _ = deregister_conditional_middleware_guardrail(&gate.qualified_name);
            set_native_last_error("failed to allocate conditional middleware guardrail handle");
            NemoRelayStatus::Internal
        }
    }
}

unsafe extern "C" fn native_plugin_runtime_deregister_conditional_middleware_guardrail(
    runtime: *const NemoRelayNativePluginRuntime,
    handle: *const NemoRelayNativeString,
    out_removed: *mut bool,
) -> NemoRelayStatus {
    clear_native_last_error();
    if out_removed.is_null() {
        set_native_last_error("conditional middleware guardrail removal output is null");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out_removed = false };
    let runtime = match native_runtime_ref(runtime) {
        Ok(runtime) => runtime,
        Err(status) => return status,
    };
    let handle = match read_name(handle) {
        Ok(handle) => handle,
        Err(status) => return status,
    };
    let mut gates = match runtime.gates.lock() {
        Ok(gates) => gates,
        Err(error) => {
            set_native_last_error(format!("native gate lock poisoned: {error}"));
            return NemoRelayStatus::Internal;
        }
    };
    let Some(gate) = gates.get(&handle) else {
        return NemoRelayStatus::Ok;
    };
    let qualified_name = gate.qualified_name.clone();
    match deregister_conditional_middleware_guardrail(&qualified_name) {
        Ok(removed) => {
            if removed {
                gates.remove(&handle);
                // The plugin removed a registration it had made, so the
                // description keeps up rather than claiming a gate that is
                // gone.
                if let Some(instance) = runtime.instance.upgrade() {
                    instance.forget_registration(&qualified_name);
                }
            }
            unsafe { *out_removed = removed };
            NemoRelayStatus::Ok
        }
        Err(error) => status_from_flow_error(error),
    }
}

unsafe extern "C" fn native_plugin_context_register_conditional_middleware_guardrail(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    kinds_json: *const NemoRelayNativeString,
    registration_name: *const NemoRelayNativeString,
    reason: *const NemoRelayNativeString,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let kinds = match read_runtime_registration_kinds(kinds_json) {
        Ok(kinds) => kinds,
        Err(status) => return status,
    };
    let registration_name = match read_name(registration_name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let reason = match read_name(reason) {
        Ok(reason) => reason,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let context = unsafe { &mut *host_ctx.ctx };
    match context.register_conditional_middleware_guardrail(
        &name,
        kinds.clone(),
        &registration_name,
        Arc::new(move |_, _| Some(reason.clone())),
    ) {
        Ok(()) => {
            record_native_gate(&instance, context, &name, &kinds, &registration_name);
            NemoRelayStatus::Ok
        }
        Err(error) => status_from_plugin_error(error),
    }
}

unsafe extern "C" fn native_plugin_context_register_conditional_middleware_guardrail_callback(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    kinds_json: *const NemoRelayNativeString,
    registration_name: *const NemoRelayNativeString,
    cb: NemoRelayNativeConditionalMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let user_data_guard = NativeCallbackUserDataGuard::new(user_data, free_fn);
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let kinds = match read_runtime_registration_kinds(kinds_json) {
        Ok(kinds) => kinds,
        Err(status) => return status,
    };
    let registration_name = match read_name(registration_name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    let (user_data, free_fn) = user_data_guard.transfer();
    let instance = host_ctx.instance.clone();
    let guardrail = wrap_conditional_middleware_guardrail(instance.clone(), cb, user_data, free_fn);
    let context = unsafe { &mut *host_ctx.ctx };
    match context.register_conditional_middleware_guardrail(
        &name,
        kinds.clone(),
        &registration_name,
        guardrail,
    ) {
        Ok(()) => {
            record_native_gate(&instance, context, &name, &kinds, &registration_name);
            NemoRelayStatus::Ok
        }
        Err(error) => status_from_plugin_error(error),
    }
}

/// Record a registration the plugin has just made.
///
/// Called only after the runtime accepted the registration: a hook that failed
/// installed nothing, and recording it would describe a component that does not
/// exist.
fn record_native_registration(
    instance: &NativePluginInstance,
    ctx: &PluginRegistrationContext,
    operation: RuntimeRegistrationKind,
    local_name: &str,
    priority: Option<i32>,
    may_break_chain: Option<bool>,
    gated_registration: Option<String>,
) {
    record_native_registration_at(
        instance,
        operation,
        local_name,
        ctx.qualify_name(local_name),
        priority,
        may_break_chain,
        gated_registration,
    );
}

/// Record one registration against a name the caller has already qualified.
///
/// The runtime-handle gate path qualifies names itself rather than through a
/// registration context, so the name travels with the record instead of being
/// derived from a context that path does not have.
fn record_native_registration_at(
    instance: &NativePluginInstance,
    operation: RuntimeRegistrationKind,
    local_name: &str,
    qualified_name: String,
    priority: Option<i32>,
    may_break_chain: Option<bool>,
    gated_registration: Option<String>,
) {
    instance.record_registration(NativePluginRegistration {
        operation,
        local_name: local_name.to_owned(),
        qualified_name,
        priority,
        may_break_chain,
        gated_registration,
    });
}

/// Record a conditional guardrail against every kind it gates.
///
/// A gate is not a component at one attachment point: it decides whether
/// registrations of the kinds it names run. Reporting it once per gated kind is
/// what lets a remote installer install a matching gate at each point, and the
/// target name is the runtime-qualified registration the gate matches on.
fn record_native_gate(
    instance: &NativePluginInstance,
    ctx: &PluginRegistrationContext,
    local_name: &str,
    kinds: &BTreeSet<RuntimeRegistrationKind>,
    gated_registration: &str,
) {
    record_native_gate_at(
        instance,
        local_name,
        &ctx.qualify_name(local_name),
        kinds,
        gated_registration,
    );
}

/// Record a conditional guardrail against an already-qualified name.
fn record_native_gate_at(
    instance: &NativePluginInstance,
    local_name: &str,
    qualified_name: &str,
    kinds: &BTreeSet<RuntimeRegistrationKind>,
    gated_registration: &str,
) {
    for kind in kinds {
        record_native_registration_at(
            instance,
            *kind,
            local_name,
            qualified_name.to_owned(),
            None,
            None,
            Some(gated_registration.to_owned()),
        );
    }
}

fn read_name(name: *const NemoRelayNativeString) -> Result<String, NemoRelayStatus> {
    if name.is_null() {
        set_native_last_error("required native string is null");
        return Err(NemoRelayStatus::NullPointer);
    }
    read_native_string(name).map_err(|err| {
        set_native_last_error(err.to_string());
        NemoRelayStatus::InvalidUtf8
    })
}

unsafe extern "C" fn native_plugin_context_register_subscriber(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    cb: NemoRelayNativeEventSubscriberCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_subscriber(
        &name,
        wrap_event_subscriber(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::Subscriber,
                &name,
                None,
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

macro_rules! native_tool_json_context_register {
    ($fn_name:ident, $ctx_method:ident, $operation:expr) => {
        unsafe extern "C" fn $fn_name(
            ctx: *mut NemoRelayNativePluginContext,
            name: *const NemoRelayNativeString,
            priority: i32,
            cb: NemoRelayNativeToolJsonCb,
            user_data: *mut c_void,
            free_fn: NemoRelayNativeFreeFn,
        ) -> NemoRelayStatus {
            clear_native_last_error();
            let host_ctx = match host_ctx_mut(ctx) {
                Ok(ctx) => ctx,
                Err(status) => return status,
            };
            let instance = host_ctx.instance.clone();
            let ctx = unsafe { &mut *host_ctx.ctx };
            let name = match read_name(name) {
                Ok(name) => name,
                Err(status) => return status,
            };
            match ctx.$ctx_method(
                &name,
                priority,
                wrap_tool_json_fn(instance.clone(), cb, user_data, free_fn),
            ) {
                Ok(()) => {
                    record_native_registration(
                        &instance,
                        ctx,
                        $operation,
                        &name,
                        Some(priority),
                        None,
                        None,
                    );
                    NemoRelayStatus::Ok
                }
                Err(err) => status_from_plugin_error(err),
            }
        }
    };
}

native_tool_json_context_register!(
    native_plugin_context_register_tool_sanitize_request_guardrail,
    register_tool_sanitize_request_guardrail,
    RuntimeRegistrationKind::ToolSanitizeRequestGuardrail
);
native_tool_json_context_register!(
    native_plugin_context_register_tool_sanitize_response_guardrail,
    register_tool_sanitize_response_guardrail,
    RuntimeRegistrationKind::ToolSanitizeResponseGuardrail
);

unsafe extern "C" fn native_plugin_context_register_tool_conditional_execution_guardrail(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    cb: NemoRelayNativeToolConditionalCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_tool_conditional_execution_guardrail(
        &name,
        priority,
        wrap_tool_conditional_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::ToolConditionalExecutionGuardrail,
                &name,
                Some(priority),
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

unsafe extern "C" fn native_plugin_context_register_tool_request_intercept(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    break_chain: bool,
    cb: NemoRelayNativeToolJsonCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_tool_request_intercept(
        &name,
        priority,
        break_chain,
        wrap_tool_intercept_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::ToolRequestIntercept,
                &name,
                Some(priority),
                Some(break_chain),
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

unsafe extern "C" fn native_plugin_context_register_tool_execution_intercept(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    cb: NemoRelayNativeToolExecutionCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_tool_execution_intercept(
        &name,
        priority,
        wrap_tool_execution_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::ToolExecutionIntercept,
                &name,
                Some(priority),
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

unsafe extern "C" fn native_plugin_context_register_llm_sanitize_request_guardrail(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    cb: NemoRelayNativeLlmSanitizeRequestCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_llm_sanitize_request_guardrail(
        &name,
        priority,
        wrap_llm_sanitize_request_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::LlmSanitizeRequestGuardrail,
                &name,
                Some(priority),
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

unsafe extern "C" fn native_plugin_context_register_llm_sanitize_response_guardrail(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    cb: NemoRelayNativeLlmSanitizeResponseCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_llm_sanitize_response_guardrail(
        &name,
        priority,
        wrap_llm_sanitize_response_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::LlmSanitizeResponseGuardrail,
                &name,
                Some(priority),
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

unsafe extern "C" fn native_plugin_context_register_llm_conditional_execution_guardrail(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    cb: NemoRelayNativeLlmConditionalCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_llm_conditional_execution_guardrail(
        &name,
        priority,
        wrap_llm_conditional_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::LlmConditionalExecutionGuardrail,
                &name,
                Some(priority),
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

unsafe extern "C" fn native_plugin_context_register_llm_request_intercept(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    break_chain: bool,
    cb: NemoRelayNativeLlmRequestInterceptCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    if let Err(error) = host_runtime()
        .validate_request_consumer_compatibility(&instance.relay_compat, &instance.plugin_kind)
    {
        return status_from_plugin_error(error);
    }
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_llm_request_intercept(
        &name,
        priority,
        break_chain,
        wrap_llm_request_intercept_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::LlmRequestIntercept,
                &name,
                Some(priority),
                Some(break_chain),
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

unsafe extern "C" fn native_plugin_context_register_llm_execution_intercept(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    cb: NemoRelayNativeLlmExecutionCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_llm_execution_intercept(
        &name,
        priority,
        wrap_llm_execution_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::LlmExecutionIntercept,
                &name,
                Some(priority),
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

unsafe extern "C" fn native_plugin_context_register_llm_stream_execution_intercept(
    ctx: *mut NemoRelayNativePluginContext,
    name: *const NemoRelayNativeString,
    priority: i32,
    cb: NemoRelayNativeLlmStreamExecutionCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> NemoRelayStatus {
    clear_native_last_error();
    let host_ctx = match host_ctx_mut(ctx) {
        Ok(ctx) => ctx,
        Err(status) => return status,
    };
    let instance = host_ctx.instance.clone();
    let ctx = unsafe { &mut *host_ctx.ctx };
    let name = match read_name(name) {
        Ok(name) => name,
        Err(status) => return status,
    };
    match ctx.register_llm_stream_execution_intercept(
        &name,
        priority,
        wrap_llm_stream_execution_fn(instance.clone(), cb, user_data, free_fn),
    ) {
        Ok(()) => {
            record_native_registration(
                &instance,
                ctx,
                RuntimeRegistrationKind::LlmStreamExecutionIntercept,
                &name,
                Some(priority),
                None,
                None,
            );
            NemoRelayStatus::Ok
        }
        Err(err) => status_from_plugin_error(err),
    }
}

macro_rules! native_event_sanitize_context_register {
    ($fn_name:ident, $ctx_method:ident, $operation:expr) => {
        unsafe extern "C" fn $fn_name(
            ctx: *mut NemoRelayNativePluginContext,
            name: *const NemoRelayNativeString,
            priority: i32,
            cb: NemoRelayNativeEventSanitizeCb,
            user_data: *mut c_void,
            free_fn: NemoRelayNativeFreeFn,
        ) -> NemoRelayStatus {
            clear_native_last_error();
            let host_ctx = match host_ctx_mut(ctx) {
                Ok(ctx) => ctx,
                Err(status) => return status,
            };
            let instance = host_ctx.instance.clone();
            let ctx = unsafe { &mut *host_ctx.ctx };
            let name = match read_name(name) {
                Ok(name) => name,
                Err(status) => return status,
            };
            match ctx.$ctx_method(
                &name,
                priority,
                wrap_event_sanitize_fn(instance.clone(), cb, user_data, free_fn),
            ) {
                Ok(()) => {
                    record_native_registration(
                        &instance,
                        ctx,
                        $operation,
                        &name,
                        Some(priority),
                        None,
                        None,
                    );
                    NemoRelayStatus::Ok
                }
                Err(err) => status_from_plugin_error(err),
            }
        }
    };
}

native_event_sanitize_context_register!(
    native_plugin_context_register_mark_sanitize_guardrail,
    register_mark_sanitize_guardrail,
    RuntimeRegistrationKind::MarkSanitizeGuardrail
);
native_event_sanitize_context_register!(
    native_plugin_context_register_scope_sanitize_start_guardrail,
    register_scope_sanitize_start_guardrail,
    RuntimeRegistrationKind::ScopeSanitizeStartGuardrail
);
native_event_sanitize_context_register!(
    native_plugin_context_register_scope_sanitize_end_guardrail,
    register_scope_sanitize_end_guardrail,
    RuntimeRegistrationKind::ScopeSanitizeEndGuardrail
);

fn wrap_conditional_middleware_guardrail(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeConditionalMiddlewareCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> ConditionalMiddlewareGuardrailFn {
    let plugin_kind = instance.plugin_kind.clone();
    let user_data = make_user_data(instance, user_data, free_fn);
    wrap_conditional_middleware_guardrail_callback(plugin_kind, cb, user_data)
}

fn wrap_conditional_middleware_guardrail_callback(
    plugin_kind: String,
    cb: NemoRelayNativeConditionalMiddlewareCb,
    user_data: Arc<NativeCallbackUserData>,
) -> ConditionalMiddlewareGuardrailFn {
    Arc::new(move |kinds, registration_name| {
        clear_native_last_error();
        let kinds_value = serde_json::to_value(kinds).unwrap_or(Json::Null);
        let Some(kinds_json) = native_string_from_json(&kinds_value) else {
            log::warn!(
                target: "nemo_relay.plugin",
                event = "native_conditional_middleware_guardrail_failed",
                plugin_id = plugin_kind.as_str(),
                registration_name;
                "Native conditional middleware guardrail failed open: failed to allocate kinds"
            );
            return None;
        };
        let Some(registration_name_string) = native_string_from_str(registration_name) else {
            unsafe { native_string_free(kinds_json) };
            log::warn!(
                target: "nemo_relay.plugin",
                event = "native_conditional_middleware_guardrail_failed",
                plugin_id = plugin_kind.as_str(),
                registration_name;
                "Native conditional middleware guardrail failed open: failed to allocate registration name"
            );
            return None;
        };
        let mut out = ptr::null_mut();
        let status = unsafe {
            cb(
                user_data.ptr,
                kinds_json,
                registration_name_string,
                &mut out,
            )
        };
        unsafe {
            native_string_free(kinds_json);
            native_string_free(registration_name_string);
        }
        if status != NemoRelayStatus::Ok {
            if !out.is_null() {
                unsafe { native_string_free(out) };
            }
            let error = native_last_error_message().unwrap_or_else(|| format!("{status:?}"));
            log::warn!(
                target: "nemo_relay.plugin",
                event = "native_conditional_middleware_guardrail_failed",
                plugin_id = plugin_kind.as_str(),
                registration_name;
                "Native conditional middleware guardrail failed open: {error}"
            );
            return None;
        }
        if out.is_null() {
            return None;
        }
        match take_native_string(out) {
            Ok(reason) => Some(reason),
            Err(error) => {
                log::warn!(
                    target: "nemo_relay.plugin",
                    event = "native_conditional_middleware_guardrail_failed",
                    plugin_id = plugin_kind.as_str(),
                    registration_name;
                    "Native conditional middleware guardrail failed open: {error}"
                );
                None
            }
        }
    })
}

fn wrap_event_subscriber(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeEventSubscriberCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> EventSubscriberFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |event: &Event| {
        let event_json = serde_json::to_value(event).unwrap_or(Json::Null);
        if let Some(event_string) = native_string_from_json(&event_json) {
            let status = unsafe { cb(user_data.ptr, event_string) };
            if status != NemoRelayStatus::Ok {
                set_native_last_error(format!("native subscriber callback returned {status:?}"));
            }
            unsafe { native_string_free(event_string) };
        }
    })
}

fn wrap_event_sanitize_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeEventSanitizeCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> EventSanitizeFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |event, fields| {
        let user_data = user_data.clone();
        Box::pin(async move { call_event_sanitize_callback(cb, user_data.ptr, &event, &fields) })
    })
}

fn call_event_sanitize_callback(
    cb: NemoRelayNativeEventSanitizeCb,
    user_data: *mut c_void,
    event: &Event,
    fields: &EventSanitizeFields,
) -> FlowResult<EventSanitizeFields> {
    clear_native_last_error();
    let event_json = serde_json::to_value(event)
        .map_err(|err| FlowError::Internal(format!("failed to encode native event: {err}")))?;
    let fields_json = serde_json::to_value(fields).map_err(|err| {
        FlowError::Internal(format!("failed to encode native event fields: {err}"))
    })?;
    let event = native_string_from_json(&event_json)
        .ok_or_else(|| FlowError::Internal("failed to allocate native event".into()))?;
    let fields = match native_string_from_json(&fields_json) {
        Some(fields) => fields,
        None => {
            unsafe { native_string_free(event) };
            return Err(FlowError::Internal(
                "failed to allocate native event fields".into(),
            ));
        }
    };
    let mut out = ptr::null_mut();
    let status = unsafe { cb(user_data, event, fields, &mut out) };
    unsafe {
        native_string_free(event);
        native_string_free(fields);
    }
    if status != NemoRelayStatus::Ok {
        if !out.is_null() {
            unsafe { native_string_free(out) };
        }
        return Err(flow_error_from_status(
            status,
            "native event sanitizer failed",
        ));
    }
    let value = take_json_from_native_string(out, "native event sanitizer returned null")?;
    serde_json::from_value(value)
        .map_err(|err| FlowError::Internal(format!("invalid event sanitize fields: {err}")))
}

fn wrap_tool_json_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeToolJsonCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> ToolSanitizeFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, payload| {
        let user_data = user_data.clone();
        Box::pin(async move { call_tool_json_callback(cb, user_data.ptr, &name, &payload) })
    })
}

fn wrap_tool_intercept_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeToolJsonCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> ToolInterceptFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, payload| {
        let user_data = user_data.clone();
        Box::pin(async move { call_tool_json_callback(cb, user_data.ptr, &name, &payload) })
    })
}

fn call_tool_json_callback(
    cb: NemoRelayNativeToolJsonCb,
    user_data: *mut c_void,
    name: &str,
    payload: &Json,
) -> FlowResult<Json> {
    clear_native_last_error();
    let name = native_string_from_str(name)
        .ok_or_else(|| FlowError::Internal("failed to allocate native name".into()))?;
    let payload = native_string_from_json(payload)
        .ok_or_else(|| FlowError::Internal("failed to allocate native payload".into()))?;
    let mut out = ptr::null_mut();
    let status = unsafe { cb(user_data, name, payload, &mut out) };
    unsafe {
        native_string_free(name);
        native_string_free(payload);
    }
    if status != NemoRelayStatus::Ok {
        if !out.is_null() {
            unsafe { native_string_free(out) };
        }
        return Err(flow_error_from_status(
            status,
            "native JSON callback failed",
        ));
    }
    take_json_from_native_string(out, "native JSON callback returned null")
}

fn wrap_tool_conditional_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeToolConditionalCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> ToolConditionalFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, args| {
        let user_data = user_data.clone();
        Box::pin(async move {
            clear_native_last_error();
            let name_string = native_string_from_str(&name)
                .ok_or_else(|| FlowError::Internal("failed to allocate native name".into()))?;
            let args_string = native_string_from_json(&args)
                .ok_or_else(|| FlowError::Internal("failed to allocate native args".into()))?;
            let mut out = ptr::null_mut();
            let status = unsafe { cb(user_data.ptr, name_string, args_string, &mut out) };
            unsafe {
                native_string_free(name_string);
                native_string_free(args_string);
            }
            if status != NemoRelayStatus::Ok {
                if !out.is_null() {
                    unsafe { native_string_free(out) };
                }
                return Err(flow_error_from_status(
                    status,
                    "native tool conditional failed",
                ));
            }
            if out.is_null() {
                Ok(None)
            } else {
                let reason = take_native_string(out)?;
                Ok(Some(reason))
            }
        })
    })
}

fn wrap_tool_execution_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeToolExecutionCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> ToolExecutionFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, args, next| {
        let name = name.to_owned();
        let user_data = user_data.clone();
        Box::pin(async move {
            clear_native_last_error();
            let name_string = native_string_from_str(&name)
                .ok_or_else(|| FlowError::Internal("failed to allocate native name".into()))?;
            let args_string = native_string_from_json(&args)
                .ok_or_else(|| FlowError::Internal("failed to allocate native args".into()))?;
            let next_ctx = Box::into_raw(Box::new(next)) as *mut c_void;
            let mut out_outcome = ptr::null_mut();
            let status = unsafe {
                cb(
                    user_data.ptr,
                    name_string,
                    args_string,
                    native_tool_next,
                    next_ctx,
                    &mut out_outcome,
                )
            };
            unsafe {
                drop(Box::from_raw(next_ctx as *mut ToolExecutionNextFn));
                native_string_free(name_string);
                native_string_free(args_string);
            }
            if status != NemoRelayStatus::Ok {
                if !out_outcome.is_null() {
                    unsafe { native_string_free(out_outcome) };
                }
                return Err(flow_error_from_status(
                    status,
                    "native tool execution failed",
                ));
            }
            let outcome_json = take_json_from_native_string(
                out_outcome,
                "native tool execution returned null outcome",
            )?;
            deserialize_native_tool_outcome(outcome_json).map_err(|err| {
                FlowError::Internal(format!("invalid native tool execution outcome JSON: {err}"))
            })
        })
    })
}

unsafe extern "C" fn native_tool_next(
    args_json: *const NemoRelayNativeString,
    next_ctx: *mut c_void,
    out_json: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    if next_ctx.is_null() || out_json.is_null() {
        set_native_last_error("native tool next received null pointer");
        return NemoRelayStatus::NullPointer;
    }
    let args = match parse_json_arg(args_json, "native tool next args") {
        Ok(args) => args,
        Err(status) => return status,
    };
    let next = unsafe { (*(next_ctx as *const ToolExecutionNextFn)).clone() };
    let context = MiddlewareContinuationContext::capture();
    let result = spawn_with_continuation_context(context, move || next(args)).join();
    match result {
        Ok(Ok(result)) => match serialize_native_tool_result(result) {
            Ok(result) => write_native_json(&result, out_json),
            Err(error) => {
                set_native_last_error(format!("failed to serialize native tool result: {error}"));
                NemoRelayStatus::Internal
            }
        },
        Ok(Err(err)) => status_from_flow_error(err),
        Err(_) => {
            set_native_last_error("native tool next panicked");
            NemoRelayStatus::Internal
        }
    }
}

fn wrap_llm_sanitize_request_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeLlmSanitizeRequestCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmSanitizeRequestFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |request, context| {
        let user_data = user_data.clone();
        Box::pin(
            async move { call_llm_sanitize_request_callback(cb, user_data.ptr, &request, context) },
        )
    })
}

fn wrap_llm_sanitize_response_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeLlmSanitizeResponseCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmSanitizeResponseFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |payload, context| {
        let user_data = user_data.clone();
        Box::pin(async move {
            call_llm_sanitize_response_callback(cb, user_data.ptr, &payload, context)
        })
    })
}

fn call_llm_sanitize_request_callback(
    cb: NemoRelayNativeLlmSanitizeRequestCb,
    user_data: *mut c_void,
    request: &LlmRequest,
    context: LlmSanitizeRequestContext,
) -> FlowResult<Option<LlmRequest>> {
    clear_native_last_error();
    let codec = context.resolve_codec().map(NativeHostLlmRequestCodec);
    let (codec_kind, context_id) = native_llm_codec_identity(context.codec())?;
    let request_json = match serde_json::to_value(request) {
        Ok(request_json) => request_json,
        Err(err) => {
            if let Some(context_id) = context_id {
                unsafe { native_string_free(context_id) };
            }
            return Err(FlowError::Internal(format!(
                "failed to serialize LLM request: {err}"
            )));
        }
    };
    let request_string = match native_string_from_json(&request_json) {
        Some(request_string) => request_string,
        None => {
            if let Some(context_id) = context_id {
                unsafe { native_string_free(context_id) };
            }
            return Err(FlowError::Internal(
                "failed to allocate native LLM request".into(),
            ));
        }
    };
    let context = NemoRelayNativeLlmSanitizeRequestContext {
        codec_kind,
        codec_id: context_id.map_or(ptr::null(), |value| value.cast_const()),
        codec: codec
            .as_ref()
            .map_or(ptr::null(), |value| std::ptr::from_ref(value).cast()),
    };
    let mut out = ptr::null_mut();
    let status = unsafe { cb(user_data, request_string, context, &mut out) };
    if status != NemoRelayStatus::Ok {
        unsafe { free_native_sanitizer_strings(request_string, context_id, out) };
        return Err(flow_error_from_status(
            status,
            "native LLM sanitize-request callback failed",
        ));
    }
    if out.is_null() {
        unsafe { free_native_sanitizer_strings(request_string, context_id, out) };
        return Ok(None);
    }
    let result_json =
        json_from_native_string(out, "native LLM sanitize-request returned invalid JSON");
    unsafe { free_native_sanitizer_strings(request_string, context_id, out) };
    let result_json = result_json?;
    serde_json::from_value(result_json)
        .map(Some)
        .map_err(|err| FlowError::Internal(format!("invalid LLM request JSON: {err}")))
}

fn call_llm_sanitize_response_callback(
    cb: NemoRelayNativeLlmSanitizeResponseCb,
    user_data: *mut c_void,
    payload: &Json,
    context: LlmSanitizeResponseContext,
) -> FlowResult<Option<Json>> {
    clear_native_last_error();
    let codec = context.resolve_codec().map(NativeHostLlmResponseCodec);
    let (codec_kind, context_id) = native_llm_codec_identity(context.codec())?;
    let payload_string = match native_string_from_json(payload) {
        Some(payload_string) => payload_string,
        None => {
            if let Some(context_id) = context_id {
                unsafe { native_string_free(context_id) };
            }
            return Err(FlowError::Internal(
                "failed to allocate native LLM response".into(),
            ));
        }
    };
    let context = NemoRelayNativeLlmSanitizeResponseContext {
        codec_kind,
        codec_id: context_id.map_or(ptr::null(), |value| value.cast_const()),
        codec: codec
            .as_ref()
            .map_or(ptr::null(), |value| std::ptr::from_ref(value).cast()),
    };
    let mut out = ptr::null_mut();
    let status = unsafe { cb(user_data, payload_string, context, &mut out) };
    if status != NemoRelayStatus::Ok {
        unsafe { free_native_sanitizer_strings(payload_string, context_id, out) };
        return Err(flow_error_from_status(
            status,
            "native LLM sanitize-response callback failed",
        ));
    }
    if out.is_null() {
        unsafe { free_native_sanitizer_strings(payload_string, context_id, out) };
        return Ok(None);
    }
    let result = json_from_native_string(out, "native LLM sanitize-response returned invalid JSON");
    unsafe { free_native_sanitizer_strings(payload_string, context_id, out) };
    result.map(Some)
}

fn native_llm_codec_identity(
    context: &LlmCodecIdentity,
) -> FlowResult<(
    NemoRelayNativeLlmCodecKind,
    Option<*mut NemoRelayNativeString>,
)> {
    let (codec_kind, codec_id) = match context {
        LlmCodecIdentity::None => (NemoRelayNativeLlmCodecKind::None, None),
        LlmCodecIdentity::BuiltIn(codec) => {
            (NemoRelayNativeLlmCodecKind::BuiltIn, Some(codec.id()))
        }
        LlmCodecIdentity::Runtime(id) => (NemoRelayNativeLlmCodecKind::Runtime, Some(id.as_str())),
        LlmCodecIdentity::Opaque => (NemoRelayNativeLlmCodecKind::Opaque, None),
    };
    let codec_id =
        match codec_id {
            Some(codec_id) => Some(native_string_from_str(codec_id).ok_or_else(|| {
                FlowError::Internal("failed to allocate native LLM codec ID".into())
            })?),
            None => None,
        };
    Ok((codec_kind, codec_id))
}

fn wrap_llm_conditional_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeLlmConditionalCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmConditionalFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |request| {
        let user_data = user_data.clone();
        Box::pin(async move {
            clear_native_last_error();
            let request_json = serde_json::to_value(request).map_err(|err| {
                FlowError::Internal(format!("failed to serialize LLM request: {err}"))
            })?;
            let request_string = native_string_from_json(&request_json).ok_or_else(|| {
                FlowError::Internal("failed to allocate native LLM request".into())
            })?;
            let mut out = ptr::null_mut();
            let status = unsafe { cb(user_data.ptr, request_string, &mut out) };
            unsafe { native_string_free(request_string) };
            if status != NemoRelayStatus::Ok {
                if !out.is_null() {
                    unsafe { native_string_free(out) };
                }
                return Err(flow_error_from_status(
                    status,
                    "native LLM conditional failed",
                ));
            }
            if out.is_null() {
                Ok(None)
            } else {
                let reason = take_native_string(out)?;
                Ok(Some(reason))
            }
        })
    })
}

fn wrap_llm_request_intercept_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeLlmRequestInterceptCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmRequestInterceptFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, request, annotated| {
        let user_data = user_data.clone();
        Box::pin(async move {
            clear_native_last_error();
            let name_string = native_string_from_str(&name)
                .ok_or_else(|| FlowError::Internal("failed to allocate native name".into()))?;
            let request_json = serde_json::to_value(&request).map_err(|err| {
                FlowError::Internal(format!("failed to serialize LLM request: {err}"))
            })?;
            let request_string = native_string_from_json(&request_json).ok_or_else(|| {
                FlowError::Internal("failed to allocate native LLM request".into())
            })?;
            let annotated_string = match &annotated {
                Some(annotated) => {
                    let value = serde_json::to_value(annotated).map_err(|err| {
                        FlowError::Internal(format!("failed to serialize annotated request: {err}"))
                    })?;
                    native_string_from_json(&value).ok_or_else(|| {
                        FlowError::Internal("failed to allocate annotated request".into())
                    })?
                }
                None => ptr::null_mut(),
            };
            let mut out_outcome = ptr::null_mut();
            let status = unsafe {
                cb(
                    user_data.ptr,
                    name_string,
                    request_string,
                    annotated_string,
                    &mut out_outcome,
                )
            };
            unsafe {
                native_string_free(name_string);
                native_string_free(request_string);
                native_string_free(annotated_string);
            }
            if status != NemoRelayStatus::Ok {
                unsafe {
                    native_string_free(out_outcome);
                }
                return Err(flow_error_from_status(
                    status,
                    "native LLM request intercept failed",
                ));
            }
            let outcome_json = json_from_native_string(
                out_outcome,
                "native LLM request intercept returned null outcome",
            );
            unsafe {
                native_string_free(out_outcome);
            }
            serde_json::from_value::<LlmRequestInterceptOutcome>(outcome_json?).map_err(|err| {
                FlowError::Internal(format!("invalid LLM request intercept outcome JSON: {err}"))
            })
        })
    })
}

fn wrap_llm_execution_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeLlmExecutionCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmExecutionFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, request, next| {
        let name = name.to_owned();
        let user_data = user_data.clone();
        Box::pin(async move { call_llm_execution_callback(cb, &user_data, &name, &request, next) })
    })
}

fn call_llm_execution_callback(
    cb: NemoRelayNativeLlmExecutionCb,
    user_data: &NativeCallbackUserData,
    name: &str,
    request: &LlmRequest,
    next: LlmExecutionNextFn,
) -> FlowResult<Json> {
    clear_native_last_error();
    let name_string = native_string_from_str(name)
        .ok_or_else(|| FlowError::Internal("failed to allocate native name".into()))?;
    let request_json = serde_json::to_value(request)
        .map_err(|err| FlowError::Internal(format!("failed to serialize LLM request: {err}")))?;
    let request_string = native_string_from_json(&request_json)
        .ok_or_else(|| FlowError::Internal("failed to allocate native LLM request".into()))?;
    let next_ctx = Box::into_raw(Box::new(next)) as *mut c_void;
    let mut out = ptr::null_mut();
    let status = unsafe {
        cb(
            user_data.ptr,
            name_string,
            request_string,
            native_llm_next,
            next_ctx,
            &mut out,
        )
    };
    unsafe {
        drop(Box::from_raw(next_ctx as *mut LlmExecutionNextFn));
        native_string_free(name_string);
        native_string_free(request_string);
    }
    if status != NemoRelayStatus::Ok {
        if !out.is_null() {
            unsafe { native_string_free(out) };
        }
        return Err(flow_error_from_status(
            status,
            "native LLM execution failed",
        ));
    }
    take_json_from_native_string(out, "native LLM execution returned null")
}

unsafe extern "C" fn native_llm_next(
    request_json: *const NemoRelayNativeString,
    next_ctx: *mut c_void,
    out_json: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    if next_ctx.is_null() || out_json.is_null() {
        set_native_last_error("native LLM next received null pointer");
        return NemoRelayStatus::NullPointer;
    }
    let request = match parse_llm_request_arg(request_json, "native LLM next request") {
        Ok(request) => request,
        Err(status) => return status,
    };
    let next = unsafe { (*(next_ctx as *const LlmExecutionNextFn)).clone() };
    let context = MiddlewareContinuationContext::capture();
    let result = spawn_with_continuation_context(context, move || next(request)).join();
    match result {
        Ok(Ok(result)) => write_native_json(&result, out_json),
        Ok(Err(err)) => status_from_flow_error(err),
        Err(_) => {
            set_native_last_error("native LLM next panicked");
            NemoRelayStatus::Internal
        }
    }
}
fn wrap_llm_stream_execution_fn(
    instance: Arc<NativePluginInstance>,
    cb: NemoRelayNativeLlmStreamExecutionCb,
    user_data: *mut c_void,
    free_fn: NemoRelayNativeFreeFn,
) -> LlmStreamExecutionFn {
    let user_data = make_user_data(instance, user_data, free_fn);
    Arc::new(move |name, request, next| {
        let name = name.to_owned();
        let user_data = user_data.clone();
        Box::pin(
            async move { call_llm_stream_execution_callback(cb, user_data, &name, &request, next) },
        )
    })
}

fn call_llm_stream_execution_callback(
    cb: NemoRelayNativeLlmStreamExecutionCb,
    user_data: Arc<NativeCallbackUserData>,
    name: &str,
    request: &LlmRequest,
    next: LlmStreamExecutionNextFn,
) -> FlowResult<LlmJsonStream> {
    clear_native_last_error();
    let name_string = native_string_from_str(name)
        .ok_or_else(|| FlowError::Internal("failed to allocate native name".into()))?;
    let request_json = serde_json::to_value(request)
        .map_err(|err| FlowError::Internal(format!("failed to serialize LLM request: {err}")))?;
    let request_string = native_string_from_json(&request_json)
        .ok_or_else(|| FlowError::Internal("failed to allocate native LLM request".into()))?;
    let next_ctx = NativeStreamNextContext::new(Box::into_raw(Box::new(next)) as *mut c_void);
    let mut out = NemoRelayNativeLlmStreamV1::default();
    let status = unsafe {
        cb(
            user_data.ptr,
            name_string,
            request_string,
            native_llm_stream_next,
            next_ctx.ptr,
            &mut out,
        )
    };
    unsafe {
        native_string_free(name_string);
        native_string_free(request_string);
    }
    if status != NemoRelayStatus::Ok {
        drop_native_stream(out);
        return Err(flow_error_from_status(
            status,
            "native LLM stream execution failed",
        ));
    }
    native_stream_to_relay_stream(out, Some(next_ctx), Some(user_data))
}

unsafe extern "C" fn native_llm_stream_next(
    request_json: *const NemoRelayNativeString,
    next_ctx: *mut c_void,
    out_stream: *mut NemoRelayNativeLlmStreamV1,
) -> NemoRelayStatus {
    if next_ctx.is_null() || out_stream.is_null() {
        set_native_last_error("native LLM stream next received null pointer");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out_stream = NemoRelayNativeLlmStreamV1::default() };
    let request = match parse_llm_request_arg(request_json, "native LLM stream next request") {
        Ok(request) => request,
        Err(status) => return status,
    };
    let next = unsafe { (*(next_ctx as *const LlmStreamExecutionNextFn)).clone() };
    let context = MiddlewareContinuationContext::capture();
    let stream_context = context.clone();
    let result = spawn_with_continuation_context(context, move || next(request)).join();
    match result {
        Ok(Ok(stream)) => {
            unsafe {
                *out_stream = relay_stream_to_native_stream_with_context(stream, stream_context)
            };
            NemoRelayStatus::Ok
        }
        Ok(Err(err)) => status_from_flow_error(err),
        Err(_) => {
            set_native_last_error("native LLM stream next panicked");
            NemoRelayStatus::Internal
        }
    }
}

struct NativeRelayLlmStream {
    raw: NemoRelayNativeLlmStreamV1,
    finished: bool,
    _next_ctx: Option<NativeStreamNextContext>,
    _callback_user_data: Option<Arc<NativeCallbackUserData>>,
}

unsafe impl Send for NativeRelayLlmStream {}

impl NativeRelayLlmStream {
    fn from_raw(
        raw: NemoRelayNativeLlmStreamV1,
        next_ctx: Option<NativeStreamNextContext>,
        callback_user_data: Option<Arc<NativeCallbackUserData>>,
    ) -> FlowResult<Self> {
        if raw.struct_size != std::mem::size_of::<NemoRelayNativeLlmStreamV1>() {
            let struct_size = raw.struct_size;
            drop_native_stream(raw);
            return Err(FlowError::Internal(format!(
                "unsupported native LLM stream struct size: {}",
                struct_size
            )));
        }
        if raw.next.is_none() {
            drop_native_stream(raw);
            return Err(FlowError::Internal(
                "native LLM stream next callback was null".into(),
            ));
        }
        Ok(Self {
            raw,
            finished: false,
            _next_ctx: next_ctx,
            _callback_user_data: callback_user_data,
        })
    }

    fn finish(&mut self) {
        self.finished = true;
        if let Some(drop_fn) = self.raw.drop.take() {
            unsafe { drop_fn(self.raw.user_data) };
        }
        self.raw.user_data = ptr::null_mut();
    }
}

impl Stream for NativeRelayLlmStream {
    type Item = FlowResult<Json>;

    fn poll_next(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        if self.finished {
            return Poll::Ready(None);
        }
        let Some(next) = self.raw.next else {
            self.finish();
            return Poll::Ready(Some(Err(FlowError::Internal(
                "native LLM stream next callback was null".into(),
            ))));
        };
        let mut out = ptr::null_mut();
        let status = unsafe { next(self.raw.user_data, &mut out) };
        match status {
            NemoRelayStatus::Ok => {
                if out.is_null() {
                    let error = FlowError::Internal(
                        native_last_error_message()
                            .unwrap_or_else(|| "native LLM stream returned null chunk".into()),
                    );
                    self.finish();
                    return Poll::Ready(Some(Err(error)));
                }
                let result =
                    take_json_from_native_string(out, "native LLM stream returned null chunk");
                if result.is_err() {
                    self.finish();
                }
                Poll::Ready(Some(result))
            }
            NemoRelayStatus::StreamEnd => {
                if !out.is_null() {
                    unsafe { native_string_free(out) };
                }
                self.finish();
                Poll::Ready(None)
            }
            status => {
                if !out.is_null() {
                    unsafe { native_string_free(out) };
                }
                let error = flow_error_from_status(status, "native LLM stream poll failed");
                self.finish();
                Poll::Ready(Some(Err(error)))
            }
        }
    }
}

impl Drop for NativeRelayLlmStream {
    fn drop(&mut self) {
        if !self.finished
            && let Some(cancel) = self.raw.cancel
        {
            let _ = unsafe { cancel(self.raw.user_data) };
        }
        self.finish();
    }
}

fn native_stream_to_relay_stream(
    raw: NemoRelayNativeLlmStreamV1,
    next_ctx: Option<NativeStreamNextContext>,
    callback_user_data: Option<Arc<NativeCallbackUserData>>,
) -> FlowResult<LlmJsonStream> {
    Ok(LlmJsonStream::new(NativeRelayLlmStream::from_raw(
        raw,
        next_ctx,
        callback_user_data,
    )?))
}

fn drop_native_stream(mut raw: NemoRelayNativeLlmStreamV1) {
    if let Some(drop_fn) = raw.drop.take() {
        unsafe { drop_fn(raw.user_data) };
    }
}

struct NativeHostLlmStream {
    stream: Arc<Mutex<Option<LlmJsonStream>>>,
    context: MiddlewareContinuationContext,
}

struct NativeStreamNextContext {
    ptr: *mut c_void,
}

unsafe impl Send for NativeStreamNextContext {}

impl NativeStreamNextContext {
    fn new(ptr: *mut c_void) -> Self {
        Self { ptr }
    }
}

impl Drop for NativeStreamNextContext {
    fn drop(&mut self) {
        if !self.ptr.is_null() {
            drop(unsafe { Box::from_raw(self.ptr as *mut LlmStreamExecutionNextFn) });
            self.ptr = ptr::null_mut();
        }
    }
}

#[cfg(test)]
fn relay_stream_to_native_stream(stream: LlmJsonStream) -> NemoRelayNativeLlmStreamV1 {
    relay_stream_to_native_stream_with_context(stream, MiddlewareContinuationContext::capture())
}

fn relay_stream_to_native_stream_with_context(
    stream: LlmJsonStream,
    context: MiddlewareContinuationContext,
) -> NemoRelayNativeLlmStreamV1 {
    let state = Box::new(NativeHostLlmStream {
        stream: Arc::new(Mutex::new(Some(stream))),
        context,
    });
    NemoRelayNativeLlmStreamV1 {
        struct_size: std::mem::size_of::<NemoRelayNativeLlmStreamV1>(),
        user_data: Box::into_raw(state).cast(),
        next: Some(poll_relay_llm_stream),
        cancel: Some(cancel_relay_llm_stream),
        drop: Some(drop_relay_llm_stream),
    }
}

unsafe extern "C" fn poll_relay_llm_stream(
    user_data: *mut c_void,
    out_json: *mut *mut NemoRelayNativeString,
) -> NemoRelayStatus {
    if user_data.is_null() || out_json.is_null() {
        set_native_last_error("native host LLM stream poll received null pointer");
        return NemoRelayStatus::NullPointer;
    }
    unsafe { *out_json = ptr::null_mut() };
    let state = unsafe { &*(user_data as *const NativeHostLlmStream) };
    let stream = state.stream.clone();
    let context = state.context.clone();
    let result = spawn_with_continuation_context(context, move || async move {
        let Some(mut current) = stream
            .lock()
            .map_err(|_| FlowError::Internal("native host LLM stream lock poisoned".into()))?
            .take()
        else {
            return Ok(None);
        };
        match current.next().await {
            Some(Ok(chunk)) => {
                *stream.lock().map_err(|_| {
                    FlowError::Internal("native host LLM stream lock poisoned".into())
                })? = Some(current);
                Ok(Some(chunk))
            }
            Some(Err(err)) => Err(err),
            None => Ok(None),
        }
    })
    .join();
    match result {
        Ok(Ok(Some(chunk))) => write_native_json(&chunk, out_json),
        Ok(Ok(None)) => NemoRelayStatus::StreamEnd,
        Ok(Err(err)) => status_from_flow_error(err),
        Err(_) => {
            set_native_last_error("native host LLM stream poll panicked");
            NemoRelayStatus::Internal
        }
    }
}

unsafe extern "C" fn cancel_relay_llm_stream(user_data: *mut c_void) -> NemoRelayStatus {
    if user_data.is_null() {
        set_native_last_error("native host LLM stream cancel received null pointer");
        return NemoRelayStatus::NullPointer;
    }
    let state = unsafe { &*(user_data as *const NativeHostLlmStream) };
    match state.stream.lock() {
        Ok(mut stream) => {
            stream.take();
            NemoRelayStatus::Ok
        }
        Err(_) => {
            set_native_last_error("native host LLM stream lock poisoned");
            NemoRelayStatus::Internal
        }
    }
}

unsafe extern "C" fn drop_relay_llm_stream(user_data: *mut c_void) {
    if !user_data.is_null() {
        drop(unsafe { Box::from_raw(user_data as *mut NativeHostLlmStream) });
    }
}

fn parse_json_arg(
    value: *const NemoRelayNativeString,
    label: &str,
) -> Result<Json, NemoRelayStatus> {
    let text = match read_native_string(value) {
        Ok(text) => text,
        Err(err) => {
            set_native_last_error(err.to_string());
            return Err(NemoRelayStatus::InvalidUtf8);
        }
    };
    serde_json::from_str(&text).map_err(|err| {
        set_native_last_error(format!("{label} was invalid JSON: {err}"));
        NemoRelayStatus::InvalidJson
    })
}

fn parse_llm_request_arg(
    value: *const NemoRelayNativeString,
    label: &str,
) -> Result<LlmRequest, NemoRelayStatus> {
    let value = parse_json_arg(value, label)?;
    serde_json::from_value(value).map_err(|err| {
        set_native_last_error(format!("{label} was not an LLM request: {err}"));
        NemoRelayStatus::InvalidJson
    })
}

fn write_native_json(value: &Json, out: *mut *mut NemoRelayNativeString) -> NemoRelayStatus {
    if out.is_null() {
        set_native_last_error("out JSON pointer is null");
        return NemoRelayStatus::NullPointer;
    }
    let Some(handle) = native_string_from_json(value) else {
        set_native_last_error("failed to serialize native JSON output");
        return NemoRelayStatus::Internal;
    };
    unsafe { *out = handle };
    NemoRelayStatus::Ok
}

#[cfg(test)]
#[path = "../tests/unit/native_plugin_tests.rs"]
mod tests;
