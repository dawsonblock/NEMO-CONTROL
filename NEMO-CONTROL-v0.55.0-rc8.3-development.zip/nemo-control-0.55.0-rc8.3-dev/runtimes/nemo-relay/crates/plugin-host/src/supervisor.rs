// SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

//! The kernel's side of the process boundary: spawn, handshake, and the backend.
//!
//! Everything the boundary is supposed to guarantee is enforced here rather than
//! asked of the child: the socket lives in a directory private to this account,
//! under a name nothing could choose in advance, the child starts with a filtered
//! environment and one credential, the handshake has to bind the runtime identity
//! before any operation is sent, and a deadline that passes kills the process rather
//! than waiting for a plugin to honour a cancellation token.
//!
//! Nothing here trusts the child's own account of itself. A host that exits is
//! reported as `HostCrashed` rather than as an unavailable service, because the
//! two call for different responses: one is a process that ended, and the other
//! is a message that did not arrive.

use std::io::Read;
use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::Arc;
use std::time::Duration;

use nemo_relay::plugin::execution::{PluginExecutionBackend, PluginExecutionFuture};
use nemo_relay_plugin_proto::convert::{
    context_to_wire, failure_from_wire, health_outcome_from_wire, inspect_outcome_from_wire,
    inspect_request_to_wire, load_outcome_from_wire, load_request_to_wire,
    unload_outcome_from_wire, unload_request_to_wire,
};
use nemo_relay_plugin_proto::v1;
use nemo_relay_plugin_proto::v1::plugin_host_client::PluginHostClient;
use nemo_relay_plugin_proto::v1::relay_runtime_server::RelayRuntimeServer;
use nemo_relay_plugin_protocol::{
    MAX_FRAME_BYTES, PROTOCOL_VERSION, PluginDescriptor, PluginExecutionContext, PluginFailure,
    PluginFailureCode, PluginHostBuild, PluginHostHealth, PluginHostReadCapability,
    PluginInspectRequest, PluginLoadRequest, PluginLoadResponse, PluginProtocolError,
    PluginSessionIdentity, PluginUnloadRequest, Uuid, deadline_expired,
};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::net::UnixStream;
use tokio::process::{Child, Command};
use tokio::sync::Mutex;
use tonic::transport::Server;
use tonic::transport::{Channel, Endpoint};
use tower::service_fn;

use crate::operation_scopes::OperationScopes;
use crate::runtime_service::{RelayRuntimeConfig, RelayRuntimeService};

/// How to start a plugin host.
#[derive(Debug, Clone)]
pub struct PluginHostSupervisorConfig {
    /// The `nemo-plugin-host` executable.
    pub executable: PathBuf,
    /// The build this runtime expects the host beside it to have been made from.
    ///
    /// Compared against what the host reports during the handshake, before any
    /// operation exists. A host and the runtime that starts it are packaged
    /// together, so a disagreement means one of the two was replaced without the
    /// other — an interrupted upgrade, a stale host left beside a new runtime, or
    /// a hand-built binary pointed at by `NEMO_RELAY_PLUGIN_HOST` — and the way
    /// to find that out is at startup rather than on the first plugin load.
    pub expected_host_build: PluginHostBuild,
    /// Digest of the runtime identity the host is bound to.
    pub runtime_binding_digest: String,
    /// Kernel-held state the host may read, if any.
    pub offered_read_capabilities: Vec<PluginHostReadCapability>,
    /// Largest frame either side will accept.
    ///
    /// Carried so the transport decoder is configured from the same value the
    /// handshake negotiates, rather than from a transport default that could
    /// disagree with the protocol.
    pub maximum_frame_bytes: u32,
    /// What the host process is allowed to take from the machine.
    ///
    /// Applied to the child rather than to this process, and applied before it
    /// runs any plugin code, so nothing a plugin does can raise it.
    pub limits: crate::limits::PluginHostLimits,
    /// How much the host process is contained.
    ///
    /// The resource limits above bound what the host takes; this decides whether
    /// the platform confines what it can *reach* — its files, its network, its
    /// devices. The default is the level that was implicit before the policy had
    /// a name, and a level this build cannot deliver is refused at startup rather
    /// than served with a host that runs without it.
    pub isolation: crate::isolation_policy::NativeIsolationPolicy,
    /// How long to wait for the host to start and handshake.
    pub startup_timeout: Duration,
}

impl PluginHostSupervisorConfig {
    /// Start from the executable that ships beside this process.
    ///
    /// Three places are tried, in order, because "beside this process" is not
    /// one place in every build: a test harness runs from `deps/` while the
    /// binary it exercises is one directory above, and a deployment that
    /// installs the host somewhere else can say where. The first one that exists
    /// is used; when none does, the path beside this process is returned so the
    /// failure names the location the deployment was expected to fill.
    pub fn beside_this_executable(runtime_binding_digest: impl Into<String>) -> Self {
        let executable = resolve_executable();
        Self {
            executable,
            expected_host_build: PluginHostBuild::expected(env!("CARGO_PKG_VERSION")),
            runtime_binding_digest: runtime_binding_digest.into(),
            offered_read_capabilities: Vec::new(),
            maximum_frame_bytes: MAX_FRAME_BYTES,
            limits: crate::limits::PluginHostLimits::default(),
            isolation: crate::isolation_policy::NativeIsolationPolicy::default(),
            startup_timeout: Duration::from_secs(10),
        }
    }
}

/// Environment variable naming the host executable, for deployments that do not
/// install it beside the process that starts it.
///
/// Re-exported from [`crate::host_location`], which owns the decision, so the
/// path this variable has always been reachable at keeps working.
pub use crate::host_location::{EXECUTABLE_ENV, plugin_runtime_binding};

use crate::host_location::{host_search_locations, resolve_executable};

/// A running plugin host process.
pub struct PluginHostSupervisor {
    /// The child, behind a lock because killing it and asking whether it exited
    /// happen from `&self`: a backend operation holds no exclusive borrow.
    child: Mutex<Child>,
    /// The child's process id, captured while it was running.
    process_id: Option<u32>,
    /// The write end of the pipe the host watches for its kernel's absence.
    ///
    /// Dropped with the session, which is what tells the host that this kernel
    /// is gone even when `Drop` never runs — a process that exits, or is killed,
    /// closes it as surely as a clean teardown does.
    child_pipe: Option<tokio::process::ChildStdin>,
    /// Removed when the supervisor drops, so nothing outlives the session.
    socket_dir: PathBuf,
    /// Host endpoint, discovered from the child in restricted mode because the
    /// sandbox container path is owned by macOS and must not be guessed here.
    host_endpoint: PathBuf,
    /// The socket this kernel serves for the child's own calls.
    kernel_endpoint: PathBuf,
    /// The task serving it, aborted with the session.
    ///
    /// The handle keeps the task's own result rather than discarding it: a
    /// server that stopped serving says so where the session ends, instead of
    /// looking like a kernel whose socket merely went quiet.
    runtime_server: tokio::task::JoinHandle<Result<(), String>>,
    /// The executor the kernel's own callback service runs on.
    ///
    /// Its own runtime rather than whichever runtime started this host, and that is a
    /// structural property rather than a preference: a plugin's callback can call *back* into
    /// the kernel — a codec resolution is the case that found it — so the call the kernel is
    /// waiting on and the call that answers it must not need the same execution lane. On a
    /// runtime with one lane the kernel would hold it while waiting for an answer that needs
    /// it, and a deadlock is not something an embedding application should be able to choose
    /// by picking a current-thread runtime. Two workers, because serving a callback while
    /// answering another is the ordinary case for a busy session.
    callback_runtime: Option<tokio::runtime::Runtime>,
    /// The scope stack each in-flight operation belongs to.
    ///
    /// Held here because both sides of the kernel need the same map: the proxy
    /// registers an operation while it runs, and the service looks the operation
    /// up when the host forwards a mark a plugin raised during it.
    operation_scopes: Arc<OperationScopes>,
    /// The continuations this session is holding for the plugins it runs.
    ///
    /// Owned by the supervisor because both halves need it: the proxy parks a
    /// position while an intercept runs, and the kernel's own service resumes it
    /// when the host asks.
    continuations: Arc<crate::continuations::Continuations>,
    /// The codec capabilities this session has issued and not yet taken back.
    ///
    /// Owned here for the same reason as the continuations: the proxy issues a reference
    /// while a sanitize invocation runs and holds the guard for exactly that call, and the
    /// kernel's own service is what checks a reference and executes the codec work.
    codecs: Arc<crate::codec_capability::CodecCapabilities>,
    session: PluginSessionIdentity,
    /// Kept for a second transport: the host checks the credential at attach as
    /// it does at handshake, so a descriptor has to carry it.
    session_credential: String,
    /// Kept for the same reason, and because the session's identity does not
    /// carry it: the binding is a property of the runtime, not of the handshake.
    runtime_binding_digest: String,
    /// What this session's operations have to present.
    ///
    /// Minted here, before the handshake, because it is the kernel's to choose:
    /// a host that minted its own capability would be handing out the thing that
    /// authorises calls to it.
    capability: crate::capability::SessionCapability,
    client: PluginHostClient<Channel>,
}

impl PluginHostSupervisor {
    /// Spawn a host, handshake with it, and hold the session.
    pub async fn spawn(config: PluginHostSupervisorConfig) -> Result<Self, PluginProtocolError> {
        // How much the host is contained, decided before a socket exists: a policy
        // this build cannot honor is a failure to start rather than a host that
        // runs without the confinement the deployment named. The executable is
        // resolved here because under a confinement policy the host is the
        // bundle's executable, which is not necessarily the path the configuration
        // was built with.
        let executable = config.isolation.host_executable(
            &config.executable,
            &crate::host_location::this_process_directory(),
        )?;
        config.isolation.verify_host_signature(&executable)?;
        let restricted_ipc =
            config.isolation == crate::isolation_policy::NativeIsolationPolicy::RestrictedMacOS;
        let mut socket_dir = create_runtime_dir()?;
        let mut socket = socket_dir.join("s");
        let credential = Uuid::now_v7().to_string();
        // The capability every operation on this session has to present, minted
        // before the host is told anything so that the session is established
        // with it rather than asking for one afterwards.
        let capability = crate::capability::SessionCapability::mint().map_err(|error| {
            unavailable(format!("failed to mint a session capability: {error}"))
        })?;
        // The kernel's own socket, in the same private directory. The child is
        // told about it and given a credential of its own: a call back into the
        // kernel is a different relationship than a call into the host, and each
        // side checks the credential the other was given rather than the path,
        // which anybody who can read the environment already knows.
        let mut kernel_endpoint = socket_dir.join("k");
        let kernel_credential = Uuid::now_v7().to_string();
        let operation_scopes = Arc::new(OperationScopes::new());
        let continuations = Arc::new(crate::continuations::Continuations::new());
        // The codec capabilities this session will issue. One record for the session, held
        // here rather than by the proxy, because the kernel's own callback service is what
        // checks a reference and the object it authorizes has to be reachable from both.
        let codecs = Arc::new(crate::codec_capability::CodecCapabilities::new());
        // Bound before the child starts, so the path it is told about exists by
        // the time it could want it. Accepting begins once the session is
        // established, because the service is bound to that session.
        // Bound as an ordinary socket rather than a tokio one, because the executor that will
        // *accept* on it is not the one that is running this function: a tokio listener belongs
        // to the reactor that created it, so adopting it on another runtime would leave a socket
        // that accepts at the operating-system level and never answers. The callback executor
        // adopts this one from inside its own reactor below.
        let mut kernel_listener = if restricted_ipc {
            None
        } else {
            Some(
                std::os::unix::net::UnixListener::bind(&kernel_endpoint).map_err(|error| {
                    unavailable(format!(
                        "failed to bind the kernel's socket at '{}': {error}",
                        kernel_endpoint.display()
                    ))
                })?,
            )
        };
        // The confined Linux host cannot connect anywhere: its seccomp filter
        // answers `connect` with EPERM, so the kernel callback channel has to
        // exist before the sandbox does. The supervisor connects to the
        // listener it just bound and hands the child the connected descriptor;
        // the callback executor accepts it like any other connection when it
        // starts serving. The path itself is never given to the confined host.
        #[cfg(unix)]
        let kernel_channel = if config.isolation
            == crate::isolation_policy::NativeIsolationPolicy::RestrictedLinux
        {
            Some(
                std::os::unix::net::UnixStream::connect(&kernel_endpoint).map_err(|error| {
                    unavailable(format!(
                        "failed to open the kernel channel the confined host is handed: {error}"
                    ))
                })?,
            )
        } else {
            None
        };
        let mut command = Command::new(&executable);
        // The bounds the child runs under, applied between `fork` and `exec`.
        // This is the only point at which they can be applied and the only point
        // at which they cannot be undone by what they are bounding: whatever the
        // plugin does afterwards, these are the limits it does it under.
        #[cfg(unix)]
        {
            let limits = config.limits;
            // The kernel channel descriptor has to survive `exec`: it is opened
            // CLOEXEC by the std socket call and the confined child's only copy
            // of it is the descriptor it inherits.
            let channel_fd = kernel_channel
                .as_ref()
                .map(std::os::unix::io::AsRawFd::as_raw_fd);
            // The descriptor table is enumerated here, in the parent, where
            // allocation and directory walks are safe; the closure below only
            // reads the snapshot. An enumeration that cannot run means the
            // boundary cannot be established — a host started without it is
            // worse than none, so the launch is refused.
            let descriptor_inventory = open_descriptor_inventory().map_err(|error| {
                unavailable(format!(
                    "cannot enumerate the descriptors a plugin host must not inherit: {error}"
                ))
            })?;
            // Safety: the closure runs in the forked child before `exec`, and
            // calls `setrlimit` (and, on Linux, `prctl`, `fcntl` and
            // `close_range`), `close`, and nothing else: it reads the captured
            // inventory without mutating it, allocates nothing, takes no
            // locks, and returns only an error the spawn reports.
            unsafe {
                command.pre_exec(move || {
                    if let Some(fd) = channel_fd {
                        let descriptor = rustix::fd::BorrowedFd::borrow_raw(fd);
                        if let Err(error) =
                            rustix::io::fcntl_setfd(descriptor, rustix::io::FdFlags::empty())
                        {
                            return Err(error.into());
                        }
                    }
                    // Everything above stdio that the supervisor holds is the
                    // supervisor's, not the host's — except the channel above,
                    // which is the confined host's only copy of it.
                    mark_inherited_descriptors_close_on_exec(channel_fd, &descriptor_inventory)?;
                    crate::limits::apply(&limits)
                });
            }
        }
        // A filtered environment: the child gets what it needs to be this host
        // and nothing about the kernel's own environment that it has no business
        // reading.
        command
            .env_clear()
            .env(
                "PATH",
                std::env::var("PATH").unwrap_or_else(|_| String::new()),
            )
            .env("NEMO_RELAY_PLUGIN_HOST_SOCKET", &socket)
            .env("NEMO_RELAY_PLUGIN_HOST_CREDENTIAL", &credential)
            .env("NEMO_RELAY_KERNEL_CREDENTIAL", &kernel_credential)
            .env(
                "NEMO_RELAY_PLUGIN_HOST_BINDING",
                &config.runtime_binding_digest,
            )
            .env(
                "NEMO_RELAY_PLUGIN_HOST_PROTOCOL",
                PROTOCOL_VERSION.to_string(),
            )
            .env(
                "NEMO_RELAY_PLUGIN_HOST_ISOLATION",
                config.isolation.as_str(),
            )
            // A pipe rather than null: the host watches it and exits when the
            // kernel that owns it goes away, which is the one thing that still
            // holds when a supervisor never gets to run its own teardown. The
            // write end is kept in this struct, so a session that ends closes it.
            .stdin(Stdio::piped())
            // Logs stay logs: the child's output goes to this process's streams
            // and is never a channel the protocol travels on.
            .stdout(if restricted_ipc {
                Stdio::piped()
            } else {
                Stdio::inherit()
            })
            .stderr(Stdio::inherit())
            .kill_on_drop(true);
        if config.isolation == crate::isolation_policy::NativeIsolationPolicy::RestrictedLinux {
            // The confined host's HOME is a directory inside its own session:
            // staging and scratch land in the one place the filesystem
            // allow-list leaves writable, and nothing the account owns is
            // visible under the name HOME suggests.
            let home = socket_dir.join("home");
            let mut builder = std::fs::DirBuilder::new();
            #[cfg(unix)]
            {
                use std::os::unix::fs::DirBuilderExt;
                builder.mode(0o700);
            }
            builder.create(&home).map_err(|error| {
                unavailable(format!(
                    "failed to create the confined host's home '{}': {error}",
                    home.display()
                ))
            })?;
            command.env("HOME", &home);
        }
        // Which kernel channel the child is offered depends on what it may do
        // once confined: a confined Linux host gets a descriptor it inherits —
        // its `connect` is dead — and everything else gets the path it dials.
        #[cfg(unix)]
        if config.isolation == crate::isolation_policy::NativeIsolationPolicy::RestrictedLinux {
            let Some(stream) = kernel_channel.as_ref() else {
                return Err(unavailable(
                    "the confined host's kernel channel was not prepared",
                ));
            };
            command.env(
                "NEMO_RELAY_KERNEL_FD",
                std::os::unix::io::AsRawFd::as_raw_fd(stream).to_string(),
            );
        } else {
            command.env("NEMO_RELAY_KERNEL_SOCKET", &kernel_endpoint);
        }
        #[cfg(not(unix))]
        {
            command.env("NEMO_RELAY_KERNEL_SOCKET", &kernel_endpoint);
        }
        let child = command.spawn().map_err(|error| {
            // A host that is not there is a deployment that received a runtime
            // without the executable that makes isolation possible, so the
            // failure names what was looked for rather than only that the spawn
            // failed: a caller cannot repair a path it was never told.
            if !executable.exists() {
                let looked = host_search_locations()
                    .into_iter()
                    .map(|location| format!("'{}'", location.display()))
                    .collect::<Vec<_>>()
                    .join(", ");
                return unavailable(format!(
                    "the plugin host executable '{}' does not exist, and a runtime that starts a \
                     host needs the host installed beside it; it was looked for at {looked}, and \
                     {EXECUTABLE_ENV} names one somewhere else",
                    executable.display(),
                ));
            }
            unavailable(format!(
                "failed to start plugin host '{}': {error}; the limits the child was to run \
                 under are applied here, so a limit this platform refuses is a host that does \
                 not start rather than one that runs unbounded",
                executable.display(),
            ))
        })?;
        // The kernel channel's other end belongs to the child now: the
        // supervisor's copy of the descriptor is closed, and the connection the
        // callback executor will accept lives on in the confined host.
        #[cfg(unix)]
        drop(kernel_channel);
        let process_id = child.id();
        let mut child = child;
        // Held, not used: the host reads it, and what it observes is the moment
        // this handle goes away with the session.
        let mut child_pipe = child.stdin.take();

        let mut host_endpoint = socket.clone();
        if restricted_ipc {
            let stdout = child.stdout.take().ok_or_else(|| {
                unavailable("the restricted host did not expose its IPC startup pipe")
            })?;
            let mut reader = BufReader::new(stdout);
            let mut line = String::new();
            let read_endpoint =
                tokio::time::timeout(config.startup_timeout, reader.read_line(&mut line)).await;
            let read_endpoint = match read_endpoint {
                Ok(Ok(count)) if count > 0 => Ok(()),
                Ok(Ok(_)) => Err(
                    "the host closed its startup pipe before reporting IPC endpoints".to_string(),
                ),
                Ok(Err(error)) => Err(format!("could not read restricted IPC endpoints: {error}")),
                Err(_) => Err(
                    "the host did not report restricted IPC endpoints before its startup deadline"
                        .to_string(),
                ),
            };
            if let Err(error) = read_endpoint {
                let _ = child.kill().await;
                return Err(unavailable(error));
            }
            let fields = line.trim_end().split('\t').collect::<Vec<_>>();
            if fields.len() != 3 || fields[0] != "NEMO_RELAY_RESTRICTED_IPC" {
                let _ = child.kill().await;
                return Err(unavailable(format!(
                    "the restricted host sent an invalid IPC record: {line:?}"
                )));
            }
            host_endpoint = PathBuf::from(fields[1]);
            kernel_endpoint = PathBuf::from(fields[2]);
            let Some(host_directory) = host_endpoint.parent() else {
                let _ = child.kill().await;
                return Err(unavailable(
                    "the restricted host endpoint has no parent directory",
                ));
            };
            if kernel_endpoint.parent() != Some(host_directory)
                || host_endpoint.file_name().is_none_or(|name| name != "h")
                || kernel_endpoint.file_name().is_none_or(|name| name != "k")
            {
                let _ = child.kill().await;
                return Err(unavailable(
                    "the restricted host reported mismatched IPC endpoints",
                ));
            }
            let listener = std::os::unix::net::UnixListener::bind(&kernel_endpoint).map_err(|error| {
                let _ = child.start_kill();
                unavailable(format!("failed to bind the kernel callback socket inside the host container: {error}"))
            })?;
            kernel_listener = Some(listener);
            if let Some(pipe) = child_pipe.as_mut()
                && let Err(error) = pipe.write_all(b"R").await
            {
                let _ = child.kill().await;
                return Err(unavailable(format!(
                    "could not release restricted host startup: {error}"
                )));
            }
            tokio::spawn(async move {
                let mut stream = reader.into_inner();
                let mut output = tokio::io::stdout();
                let _ = tokio::io::copy(&mut stream, &mut output).await;
            });
            let _ = std::fs::remove_dir_all(&socket_dir);
            socket_dir = host_directory.to_path_buf();
            socket = host_endpoint.clone();
        }

        // One budget covers the whole startup: the socket appearing *and* the
        // handshake completing. A host that binds, accepts and then never
        // answers would otherwise hold `spawn` open forever, which would make the
        // stated guarantee half true.
        let startup = tokio::time::timeout(config.startup_timeout, async {
            let channel = loop {
                match connect(&socket).await {
                    Ok(channel) => break channel,
                    Err(error) => {
                        // The startup budget bounds this loop, so a host that
                        // never binds is killed when it expires rather than
                        // retried forever.
                        if let Some(status) = child.try_wait().ok().flatten() {
                            return Err(unavailable(format!(
                                "plugin host did not accept a connection at '{}': {error}; \
                                 the host exited with {status}",
                                socket.display()
                            )));
                        }
                        tokio::time::sleep(Duration::from_millis(20)).await;
                    }
                }
            };
            let client = PluginHostClient::new(channel)
                .max_decoding_message_size(config.maximum_frame_bytes as usize)
                .max_encoding_message_size(config.maximum_frame_bytes as usize);
            let mut client = client;
            let session = handshake(
                &mut client,
                &HandshakeOffer {
                    credential: &credential,
                    runtime_binding_digest: &config.runtime_binding_digest,
                    expected_host_build: &config.expected_host_build,
                    offered_read_capabilities: &config.offered_read_capabilities,
                    supported_registration_operations:
                        &ProcessPluginBackend::supported_registration_operations(),
                    maximum_frame_bytes: config.maximum_frame_bytes,
                },
                &capability,
            )
            .await?;
            Ok::<_, PluginProtocolError>((client, session))
        })
        .await;

        let (client, session) = match startup {
            Ok(Ok(started)) => started,
            Ok(Err(error)) => {
                let _ = child.kill().await;
                return Err(error);
            }
            Err(_) => {
                // A host that will not finish starting is not a host.
                let _ = child.kill().await;
                let _ = std::fs::remove_dir_all(&socket_dir);
                return Err(unavailable(
                    "the plugin host did not start and handshake within its startup budget",
                ));
            }
        };
        // Every transport this session opens uses this one number, so it has to
        // be the number both sides can carry rather than whichever one named it
        // last. The host reports what it will accept and the kernel cannot be
        // told a size larger than the one it configured itself for, so the
        // session keeps the smaller of the two — including for the second,
        // attached transport, which is handed this value and no other.
        let negotiated_frame_limit = session
            .maximum_frame_bytes
            .min(config.maximum_frame_bytes)
            .min(MAX_FRAME_BYTES);
        let session = PluginSessionIdentity {
            maximum_frame_bytes: negotiated_frame_limit,
            ..session
        };

        // The kernel's side of the boundary, serving the session that was just established — on
        // an executor of its own, because a plugin's callback can call back into the kernel and
        // the two directions must not need the same lane.
        let callback_runtime = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .thread_name("nemo-plugin-callbacks")
            .enable_all()
            .build()
            .map_err(|error| {
                PluginProtocolError::new(
                    nemo_relay_plugin_protocol::PluginFailureCode::Rejected,
                    format!(
                        "the executor the kernel's callback service needs did not start: {error}"
                    ),
                )
            })?;
        // Spawned rather than awaited: nothing calls it until a plugin's host does, and
        // holding `start` open for that would make starting a host depend on a call nobody
        // has made.
        let serving_session_id = session.session_id.clone();
        let serving_binding_digest = config.runtime_binding_digest.clone();
        let serving_operation_scopes = Arc::clone(&operation_scopes);
        let serving_continuations = Arc::clone(&continuations);
        let serving_codecs = Arc::clone(&codecs);
        let runtime_server = callback_runtime.spawn(async move {
            let Some(kernel_listener) = kernel_listener else {
                return Err("the kernel callback listener was not created".to_string());
            };
            if let Err(error) = kernel_listener.set_nonblocking(true) {
                return Err(format!(
                    "the kernel's socket could not be made non-blocking: {error}"
                ));
            }
            // Adopted here, inside the executor that will accept on it: this is the line that
            // binds the socket's reactor to the runtime that serves the session.
            let listener =
                tokio::net::UnixListener::from_std(kernel_listener).map_err(|error| {
                    format!("the kernel's socket could not be adopted by its executor: {error}")
                })?;
            Server::builder()
                .add_service(RelayRuntimeServer::new(RelayRuntimeService::new(
                    RelayRuntimeConfig {
                        session_id: serving_session_id,
                        session_credential: kernel_credential,
                        protocol_version: PROTOCOL_VERSION,
                        runtime_binding_digest: serving_binding_digest,
                        operation_scopes: serving_operation_scopes,
                        continuations: serving_continuations,
                        codecs: serving_codecs,
                    },
                )))
                .serve_with_incoming(tokio_stream::wrappers::UnixListenerStream::new(listener))
                .await
                .map_err(|error| error.to_string())
        });

        Ok(Self {
            child: Mutex::new(child),
            process_id,
            child_pipe,
            socket_dir,
            host_endpoint,
            kernel_endpoint,
            runtime_server,
            callback_runtime: Some(callback_runtime),
            operation_scopes,
            continuations,
            codecs,
            session,
            session_credential: credential,
            capability,
            runtime_binding_digest: config.runtime_binding_digest.clone(),
            client,
        })
    }

    /// The session this host established.
    pub fn session(&self) -> &PluginSessionIdentity {
        &self.session
    }

    /// The socket this kernel serves for the child's own calls.
    ///
    /// The path is not a secret — the child is told it, and knowing it is not
    /// enough to be served — so exposing it lets a caller point a host's client
    /// at the right socket without also exposing the credential that authorises
    /// it.
    pub fn kernel_endpoint(&self) -> &Path {
        &self.kernel_endpoint
    }

    /// Everything a second transport needs to attach to this session.
    pub fn connection_descriptor(&self) -> crate::attached::ConnectionDescriptor {
        crate::attached::ConnectionDescriptor {
            endpoint: self.host_endpoint.clone(),
            session_credential: self.session_credential.clone(),
            runtime_binding_digest: self.runtime_binding_digest.clone(),
            session_id: self.session.session_id.clone(),
            maximum_frame_bytes: self.session.maximum_frame_bytes,
            capability: self.capability.as_str().to_owned(),
        }
    }

    /// The registry that says which scope an in-flight operation belongs to.
    ///
    /// Whoever installs a proxy registers into it, so a mark the host forwards
    /// during an operation is attached to the call that raised it.
    pub fn operation_scopes(&self) -> Arc<OperationScopes> {
        Arc::clone(&self.operation_scopes)
    }

    /// The continuations this session holds for the plugins it runs.
    pub fn continuations(&self) -> Arc<crate::continuations::Continuations> {
        Arc::clone(&self.continuations)
    }

    /// The codec capabilities this session issues into.
    pub fn codec_capabilities(&self) -> Arc<crate::codec_capability::CodecCapabilities> {
        Arc::clone(&self.codecs)
    }

    /// The host's process id, as it was while the process was running.
    pub fn process_id(&self) -> Option<u32> {
        self.process_id
    }

    /// End the host process.
    pub async fn kill(&self) -> Result<(), PluginProtocolError> {
        self.child
            .lock()
            .await
            .kill()
            .await
            .map_err(|error| unavailable(format!("failed to kill the plugin host: {error}")))
    }

    /// Whether the host has already exited, and how.
    async fn exit_status(&self) -> Option<std::process::ExitStatus> {
        self.child.lock().await.try_wait().ok().flatten()
    }

    /// Send one lifecycle request, holding it to the operation's budget.
    async fn request<W, F>(&self, budget: Duration, send: F) -> Result<W, PluginProtocolError>
    where
        F: std::future::Future<Output = Result<W, tonic::Status>>,
    {
        match tokio::time::timeout(budget, send).await {
            Ok(Ok(response)) => Ok(response),
            Ok(Err(status)) => {
                // A transport failure is either a host that ended or a channel
                // that broke; the difference decides whether the kernel may
                // consider the operation undone, so it is never guessed at.
                Err(match self.exit_status().await {
                    Some(status) => crashed(format!("the plugin host exited: {status}")),
                    None => {
                        // The channel broke while the host is still running, so
                        // nobody can say whether it acted on the request. Keeping
                        // it alive would leave a process whose state the kernel
                        // cannot account for; killing it makes the session's
                        // state certain again, which is what a restart from
                        // nothing depends on.
                        let _ = self.child.lock().await.kill().await;
                        unavailable(format!(
                            "the plugin host did not answer '{status}', so its state is unknown \
                             and it was killed"
                        ))
                    }
                })
            }
            Err(_) => {
                // The deadline is the kernel's, and a plugin is not trusted to
                // honour it: the process is killed rather than asked to stop.
                let _ = self.child.lock().await.kill().await;
                Err(PluginProtocolError::new(
                    PluginFailureCode::DeadlineExceeded,
                    "the plugin host exceeded the operation's budget".to_string(),
                ))
            }
        }
    }
}

impl Drop for PluginHostSupervisor {
    fn drop(&mut self) {
        // The server is this session's, and it goes when the session does.
        self.runtime_server.abort();
        // And the executor it ran on. Ended in the background for the same reason the off-path
        // runtime is: a composition is usually torn down from inside an async context, and
        // dropping a runtime there panics.
        if let Some(runtime) = self.callback_runtime.take() {
            runtime.shutdown_background();
        }
        // The pipe closes here too, so a host whose kill somehow did not land
        // still learns that this kernel is gone.
        drop(self.child_pipe.take());
        // And so does the host process. `kill_on_drop` is not enough on its own:
        // it signals the child from a task on this process's runtime, and the
        // last composition of a process is dropped exactly when that runtime is
        // shutting down — so the task may never run, and the host outlives the
        // session that started it. Signalling here is synchronous, and a signal
        // cannot be lost to a scheduler that is going away.
        let _ = self.child.get_mut().start_kill();
        // The directory holds the socket and nothing else, and it is removed
        // with the session it belonged to.
        let _ = std::fs::remove_dir_all(&self.socket_dir);
    }
}

/// A backend that reaches the plugin host process.
pub struct ProcessPluginBackend {
    supervisor: PluginHostSupervisor,
    /// How to start a replacement, so a crashed host can be replaced without the
    /// caller having to know it ever existed.
    config: PluginHostSupervisorConfig,
}

impl ProcessPluginBackend {
    /// Registration classes this backend can install a proxy for.
    ///
    /// Derived from what the backend implements rather than supplied by a
    /// caller: a caller that could declare support the backend does not have
    /// would break the guarantee that a load which cannot be served does not
    /// happen. Each entry is next to the proxy that makes it true — a class
    /// belongs here when the kernel can install a proxy for it and the host can
    /// run it — and the list is the whole of what the boundary carries today.
    pub fn supported_registration_operations()
    -> Vec<nemo_relay_plugin_protocol::PluginRegistrationOperation> {
        // The classes this kernel can install a proxy for and this host can run.
        // A class appearing here without a proxy would let a load report success
        // for a callback the runtime never calls, so the list grows one entry at
        // a time, next to the proxy that makes the entry true.
        vec![
            nemo_relay_plugin_protocol::PluginRegistrationOperation::ToolRequestIntercept,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::LlmRequestIntercept,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::Subscriber,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::EventMetadataInjector,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::ToolConditionalExecutionGuardrail,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::LlmConditionalExecutionGuardrail,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::ToolSanitizeRequestGuardrail,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::ToolSanitizeResponseGuardrail,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::ToolExecutionIntercept,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::LlmExecutionIntercept,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::LlmStreamExecutionIntercept,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::MarkSanitizeGuardrail,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::ScopeSanitizeStartGuardrail,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::ScopeSanitizeEndGuardrail,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::LlmSanitizeRequestGuardrail,
            nemo_relay_plugin_protocol::PluginRegistrationOperation::LlmSanitizeResponseGuardrail,
        ]
    }

    /// Transfer the approved artifact into the confined host's own container.
    async fn transfer_artifact(
        &self,
        request: &PluginLoadRequest,
        context: &PluginExecutionContext,
    ) -> Result<String, PluginProtocolError> {
        let (manifest, library_path, _library_relative_path) = artifact_transfer_sources(request)?;
        let length = std::fs::metadata(&library_path)
            .map_err(|error| rejected(format!("cannot size approved plugin library: {error}")))?
            .len();
        const MAX_PLUGIN_ARTIFACT_BYTES: u64 = 512 * 1024 * 1024;
        if length > MAX_PLUGIN_ARTIFACT_BYTES {
            return Err(rejected(format!(
                "plugin library is {length} bytes, over the transfer limit of {MAX_PLUGIN_ARTIFACT_BYTES}"
            )));
        }
        let library = std::fs::File::open(&library_path)
            .map_err(|error| rejected(format!("cannot open approved plugin library: {error}")))?;
        let artifact_id = Uuid::now_v7().to_string();
        let session_id = self.supervisor.session.session_id.clone();
        let begin = v1::ArtifactTransferFrame {
            frame: Some(v1::artifact_transfer_frame::Frame::Begin(
                v1::ArtifactTransferBegin {
                    session_id: session_id.clone(),
                    artifact_id: artifact_id.clone(),
                    plugin_id: request.plugin_id.clone(),
                    manifest,
                    manifest_sha256: request.identity.manifest_sha256.clone(),
                    library_sha256: request.identity.library_sha256.clone(),
                    library_length: length,
                },
            )),
        };
        let chunk_size = (self.supervisor.session.maximum_frame_bytes as usize)
            .saturating_sub(256)
            .min(256 * 1024);
        if chunk_size == 0 {
            return Err(rejected(
                "the negotiated frame limit is too small to transfer an approved artifact",
            ));
        }
        let source_error = Arc::new(std::sync::Mutex::new(None));
        let chunks = artifact_chunk_frames(
            library,
            artifact_id.clone(),
            chunk_size,
            Arc::clone(&source_error),
        );
        let finalize = v1::ArtifactTransferFrame {
            frame: Some(v1::artifact_transfer_frame::Frame::Finalize(
                v1::ArtifactTransferFinalize {
                    artifact_id: artifact_id.clone(),
                },
            )),
        };
        let frames = std::iter::once(begin)
            .chain(chunks)
            .chain(std::iter::once(finalize));
        let request_stream = capable(tokio_stream::iter(frames), &self.supervisor.capability);
        let budget = Self::budget(context, now_unix_ms()?)?;
        let mut client = self.supervisor.client.clone();
        let outcome = self
            .supervisor
            .request(budget, async move {
                client.transfer_artifact(request_stream).await
            })
            .await;
        if let Some(error) = source_error
            .lock()
            .expect("artifact stream error mutex is not poisoned")
            .take()
        {
            return Err(rejected(error));
        }
        let outcome = outcome?.into_inner();
        match outcome.result {
            Some(v1::artifact_transfer_outcome::Result::Approved(approved))
                if approved.artifact_id == artifact_id
                    && approved.plugin_id == request.plugin_id
                    && approved.manifest_sha256 == request.identity.manifest_sha256
                    && approved.library_sha256 == request.identity.library_sha256 =>
            {
                if self.config.isolation
                    == crate::isolation_policy::NativeIsolationPolicy::RestrictedMacOS
                {
                    #[cfg(target_os = "macos")]
                    {
                        let session_id = session_id.clone();
                        let artifact_id = artifact_id.clone();
                        let expected_sha256 = request.identity.library_sha256.clone();
                        tokio::task::spawn_blocking(move || {
                            crate::macos_quarantine::clear_approved_quarantine(
                                &session_id,
                                &artifact_id,
                                &_library_relative_path,
                                &expected_sha256,
                            )
                        })
                        .await
                        .map_err(|error| {
                            rejected(format!(
                                "the approved macOS artifact quarantine handoff did not complete: {error}"
                            ))
                        })?
                        .map_err(|error| {
                            rejected(format!(
                                "the approved macOS artifact quarantine handoff was refused: {error}"
                            ))
                        })?;
                    }
                    #[cfg(not(target_os = "macos"))]
                    {
                        return Err(rejected(
                            "restricted artifact quarantine handoff is available only on macOS",
                        ));
                    }
                }
                Ok(artifact_id)
            }
            Some(v1::artifact_transfer_outcome::Result::Failure(failure)) => {
                Err(error_to_protocol(failure_from_wire(&failure)?))
            }
            Some(v1::artifact_transfer_outcome::Result::Approved(_)) => {
                Err(PluginProtocolError::new(
                    PluginFailureCode::MalformedResponse,
                    "the host approved a different artifact transfer than the one sent",
                ))
            }
            None => Err(PluginProtocolError::new(
                PluginFailureCode::MalformedResponse,
                "the host returned no artifact transfer outcome",
            )),
        }
    }

    /// Ask the host to activate components and report what they registered.
    ///
    /// The kernel sends the configuration, the plugin's register callbacks run in
    /// the host, and the descriptors that come back are what the kernel installs
    /// proxies from. A plugin that registered something this session cannot
    /// serve is refused by the host, so nothing is activated that the kernel
    /// would then have to ignore.
    pub async fn activate(
        &self,
        request: nemo_relay_plugin_protocol::PluginActivateRequest,
        context: PluginExecutionContext,
    ) -> Result<Vec<PluginDescriptor>, PluginProtocolError> {
        let budget = Self::budget(&context, now_unix_ms()?)?;
        let session_id = self.supervisor.session.session_id.clone();
        let wire = nemo_relay_plugin_proto::convert::activate_request_to_wire(
            &request,
            &session_id,
            &context,
        );
        let mut client = self.supervisor.client.clone();
        let request = capable(wire, &self.supervisor.capability);
        let outcome = self
            .supervisor
            .request(budget, async move { client.activate(request).await })
            .await?
            .into_inner();
        nemo_relay_plugin_proto::convert::activate_outcome_from_wire(&outcome)?
            .into_result()
            .map_err(error_to_protocol)
    }

    /// Start a streaming invocation and read its frames.
    ///
    /// The one call whose answer is a stream rather than a value: the host runs
    /// the registration and produces the frames the plugin's returned stream
    /// yields, and this side reads them one at a time. Reading is what asks the
    /// host for the next one, so a kernel that stops reading stops the plugin —
    /// which is the same pacing the downstream direction has, in the other
    /// direction.
    ///
    /// The deadline is not applied to the stream as a whole here: a stream's
    /// budget is about when it *starts* and about the bytes it carries, and the
    /// operation's deadline is enforced on the call the way it is for any other
    /// — by the supervisor's kill when the host overruns.
    pub async fn invoke_stream(
        &self,
        request: nemo_relay_plugin_protocol::PluginInvokeRequest,
        context: PluginExecutionContext,
    ) -> Result<PluginStreamFrames, PluginProtocolError> {
        let budget = Self::budget(&context, now_unix_ms()?)?;
        let session_id = self.supervisor.session.session_id.clone();
        let wire = nemo_relay_plugin_proto::convert::invoke_request_to_wire(
            &request,
            &session_id,
            &context,
        );
        let mut client = self.supervisor.client.clone();
        let start = capable(wire, &self.supervisor.capability);
        // The call itself is bounded by the operation's budget; the frames that
        // follow are bounded by the reader, which is the backpressure the host
        // is entitled to see.
        let started = self
            .supervisor
            .request(budget, async move { client.invoke_stream(start).await })
            .await?;
        Ok(PluginStreamFrames {
            frames: started.into_inner(),
            operation_request_id: context.operation_request_id.clone(),
            terminal: false,
        })
    }

    /// Take ownership of a running host.
    pub fn new(supervisor: PluginHostSupervisor, config: PluginHostSupervisorConfig) -> Self {
        Self { supervisor, config }
    }

    /// Spawn a host and serve it.
    pub async fn launch(config: PluginHostSupervisorConfig) -> Result<Self, PluginProtocolError> {
        let supervisor = PluginHostSupervisor::spawn(config.clone()).await?;
        Ok(Self::new(supervisor, config))
    }

    /// The session this backend belongs to.
    pub fn session(&self) -> &PluginSessionIdentity {
        self.supervisor.session()
    }

    /// The runtime binding this backend's host was started with.
    ///
    /// The kernel knows it — it sent it — and the host checks every operation
    /// against it, so anything the kernel asks on the session's behalf has to
    /// carry it.
    pub fn runtime_binding_digest(&self) -> &str {
        &self.config.runtime_binding_digest
    }

    /// The host's process id, while it is running.
    pub fn process_id(&self) -> Option<u32> {
        self.supervisor.process_id()
    }

    /// The socket this backend's kernel serves for the child's own calls.
    pub fn kernel_endpoint(&self) -> &Path {
        self.supervisor.kernel_endpoint()
    }

    /// The registry that says which scope an in-flight operation belongs to.
    pub fn operation_scopes(&self) -> Arc<OperationScopes> {
        self.supervisor.operation_scopes()
    }

    /// The continuations this session holds for the plugins it runs.
    pub fn continuations(&self) -> Arc<crate::continuations::Continuations> {
        self.supervisor.continuations()
    }

    /// The codec capabilities this session issues into.
    pub fn codec_capabilities(&self) -> Arc<crate::codec_capability::CodecCapabilities> {
        self.supervisor.codec_capabilities()
    }

    /// Everything a second transport needs to attach to this session.
    pub fn connection_descriptor(&self) -> crate::attached::ConnectionDescriptor {
        self.supervisor.connection_descriptor()
    }

    /// End the host process.
    pub async fn kill(&self) -> Result<(), PluginProtocolError> {
        self.supervisor.kill().await
    }

    /// Whether the host has exited, and how.
    pub async fn exit_status(&self) -> Option<std::process::ExitStatus> {
        self.supervisor.exit_status().await
    }

    /// Replace a host that has exited with a fresh one.
    ///
    /// Deliberately *not* a reload. Everything the previous host held — its
    /// session, its loaded plugins, and the generations behind their handles —
    /// belonged to that session, and a new host starts with none of it: a handle
    /// from before the crash addresses nothing, and the kernel has to ask for a
    /// load again. Restarting with the old set in place would imply a continuity
    /// the crash took away, and the loaded set is the kernel's record rather than
    /// the backend's.
    pub async fn restart(&mut self) -> Result<(), PluginProtocolError> {
        let supervisor = PluginHostSupervisor::spawn(self.config.clone()).await?;
        // The old supervisor drops here, which kills it if it is somehow still
        // running and removes its socket directory either way.
        self.supervisor = supervisor;
        Ok(())
    }

    /// How long the operation may take, or a refusal if it may not start.
    fn budget(
        context: &PluginExecutionContext,
        now_unix_ms: u64,
    ) -> Result<Duration, PluginProtocolError> {
        if deadline_expired(context.deadline_unix_ms, now_unix_ms) {
            return Err(PluginProtocolError::new(
                PluginFailureCode::DeadlineExceeded,
                "the operation's deadline has already passed".to_string(),
            ));
        }
        let remaining = context
            .deadline_unix_ms
            .saturating_sub(now_unix_ms)
            .min(context.remaining_budget_millis);
        Ok(Duration::from_millis(remaining))
    }
}

impl PluginExecutionBackend for ProcessPluginBackend {
    fn load<'a>(
        &'a self,
        mut request: PluginLoadRequest,
        context: PluginExecutionContext,
    ) -> PluginExecutionFuture<'a, PluginLoadResponse> {
        Box::pin(async move {
            if self.config.isolation.confines_resources() {
                // A confined host cannot open a path the kernel hands it — the
                // artifact has to arrive over the authenticated session instead.
                request.artifact = self.transfer_artifact(&request, &context).await?;
            }
            let budget = Self::budget(&context, now_unix_ms()?)?;
            let session_id = self.supervisor.session.session_id.clone();
            let wire = load_request_to_wire(&request, &session_id, &context);
            let mut client = self.supervisor.client.clone();
            let request = capable(wire, &self.supervisor.capability);
            let outcome = self
                .supervisor
                .request(budget, async move { client.load(request).await })
                .await?
                .into_inner();
            let outcome = load_outcome_from_wire(&outcome)?
                .into_result()
                .map_err(error_to_protocol)?;
            Ok(outcome)
        })
    }

    fn unload<'a>(
        &'a self,
        request: PluginUnloadRequest,
        context: PluginExecutionContext,
    ) -> PluginExecutionFuture<'a, ()> {
        Box::pin(async move {
            let budget = Self::budget(&context, now_unix_ms()?)?;
            let session_id = self.supervisor.session.session_id.clone();
            let wire = unload_request_to_wire(&request, &session_id, &context);
            let mut client = self.supervisor.client.clone();
            let request = capable(wire, &self.supervisor.capability);
            let outcome = self
                .supervisor
                .request(budget, async move { client.unload(request).await })
                .await?
                .into_inner();
            unload_outcome_from_wire(&outcome)?
                .into_result()
                .map_err(error_to_protocol)
        })
    }

    fn inspect<'a>(
        &'a self,
        request: PluginInspectRequest,
        context: PluginExecutionContext,
    ) -> PluginExecutionFuture<'a, Vec<PluginDescriptor>> {
        Box::pin(async move {
            let budget = Self::budget(&context, now_unix_ms()?)?;
            let session_id = self.supervisor.session.session_id.clone();
            let wire = inspect_request_to_wire(&request, &session_id, &context);
            let mut client = self.supervisor.client.clone();
            let request = capable(wire, &self.supervisor.capability);
            let outcome = self
                .supervisor
                .request(budget, async move { client.inspect(request).await })
                .await?
                .into_inner();
            inspect_outcome_from_wire(&outcome)?
                .into_result()
                .map_err(error_to_protocol)
        })
    }

    fn invoke<'a>(
        &'a self,
        request: nemo_relay_plugin_protocol::PluginInvokeRequest,
        context: PluginExecutionContext,
    ) -> PluginExecutionFuture<'a, nemo_relay_plugin_protocol::PluginExecutionOutcome> {
        Box::pin(async move {
            let budget = Self::budget(&context, now_unix_ms()?)?;
            let session_id = self.supervisor.session.session_id.clone();
            let wire = nemo_relay_plugin_proto::convert::invoke_request_to_wire(
                &request,
                &session_id,
                &context,
            );
            let mut client = self.supervisor.client.clone();
            let request = capable(wire, &self.supervisor.capability);
            let outcome = self
                .supervisor
                .request(budget, async move { client.invoke(request).await })
                .await?
                .into_inner();
            // The same budget the host measured against, measured again here.
            // This side does not take the host's word for it any more than it
            // takes its word for anything else: the host runs a native plugin,
            // and an answer that outgrew its operation is refused on arrival
            // rather than handed to a caller that asked for a smaller one.
            nemo_relay_plugin_proto::convert::check_invoke_outcome_budget(
                &outcome,
                context.max_response_bytes,
            )?;
            // The outcome travels whole, because the distinction it carries is
            // the reason it exists: a plugin that may have dispatched before the
            // channel died produced no definite result, and collapsing that into
            // a failure would turn "nobody knows" into "it did not happen".
            //
            // It also has to be the outcome for *this* invocation: the answer
            // names the operation the host accepted, and an answer that names a
            // different one is refused here rather than attributed to this call.
            nemo_relay_plugin_proto::convert::invocation_answer_from_wire(
                &outcome,
                &context.operation_request_id,
            )
        })
    }

    fn health<'a>(
        &'a self,
        context: PluginExecutionContext,
    ) -> PluginExecutionFuture<'a, PluginHostHealth> {
        Box::pin(async move {
            let budget = Self::budget(&context, now_unix_ms()?)?;
            let session_id = self.supervisor.session.session_id.clone();
            let wire = v1::HealthRequest {
                session_id,
                context: Some(context_to_wire(&context)),
            };
            let mut client = self.supervisor.client.clone();
            let request = capable(wire, &self.supervisor.capability);
            let outcome = self
                .supervisor
                .request(budget, async move { client.health(request).await })
                .await?
                .into_inner();
            health_outcome_from_wire(&outcome)?
                .into_result()
                .map_err(error_to_protocol)
        })
    }
}

/// The frames one streaming invocation produces.
///
/// Read one at a time, because reading is what asks the host for the next one:
/// a stream this side stops reading is one the plugin stops producing, which is
/// the pacing the host's own pull has in the other direction.
pub struct PluginStreamFrames {
    frames: tonic::Streaming<v1::StreamChunk>,
    /// The invocation these frames belong to.
    operation_request_id: String,
    /// Whether a terminal frame has been read, so a stream ends once.
    terminal: bool,
}

impl std::fmt::Debug for PluginStreamFrames {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("PluginStreamFrames")
            .field("operation_request_id", &self.operation_request_id)
            .field("terminal", &self.terminal)
            .finish()
    }
}

impl PluginStreamFrames {
    /// The invocation these frames answer.
    pub fn operation_request_id(&self) -> &str {
        &self.operation_request_id
    }
}

impl tokio_stream::Stream for PluginStreamFrames {
    type Item = Result<nemo_relay_plugin_protocol::PluginStreamChunk, PluginProtocolError>;

    fn poll_next(
        mut self: std::pin::Pin<&mut Self>,
        context: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        use std::task::Poll;

        let this = self.as_mut().get_mut();
        if this.terminal {
            return Poll::Ready(None);
        }
        match std::pin::Pin::new(&mut this.frames).poll_next(context) {
            Poll::Ready(Some(Ok(frame))) => {
                let converted = nemo_relay_plugin_proto::convert::stream_chunk_from_wire(&frame);
                match converted {
                    Ok(chunk) => {
                        // A frame naming another operation is refused rather than
                        // attributed to this stream: the answer has to be the
                        // answer to the invocation that asked.
                        if chunk.operation_request_id != this.operation_request_id {
                            this.terminal = true;
                            return Poll::Ready(Some(Err(PluginProtocolError::new(
                                PluginFailureCode::MalformedResponse,
                                format!(
                                    "a streaming answer names '{}' but arrived for '{}'",
                                    chunk.operation_request_id, this.operation_request_id
                                ),
                            ))));
                        }
                        if !matches!(
                            chunk.chunk,
                            nemo_relay_plugin_protocol::PluginStreamChunkKind::Data(_)
                        ) {
                            this.terminal = true;
                        }
                        Poll::Ready(Some(Ok(chunk)))
                    }
                    Err(error) => {
                        this.terminal = true;
                        Poll::Ready(Some(Err(error)))
                    }
                }
            }
            Poll::Ready(Some(Err(status))) => {
                // The channel broke mid-stream. Whether the plugin had produced
                // anything is known — the frames already read — but whether its
                // work finished is not, and the failure says so rather than
                // claiming either.
                this.terminal = true;
                Poll::Ready(Some(Err(PluginProtocolError::new(
                    PluginFailureCode::Unavailable,
                    format!("the plugin host's stream ended: {status}"),
                ))))
            }
            // A stream that simply stopped is a truncation, not an end: the
            // protocol ends a stream with a terminal frame, so this is a failure
            // rather than something a caller may read as completion.
            Poll::Ready(None) => {
                this.terminal = true;
                Poll::Ready(Some(Err(PluginProtocolError::new(
                    PluginFailureCode::MalformedResponse,
                    "the plugin host's stream ended without a terminal frame".to_string(),
                ))))
            }
            Poll::Pending => Poll::Pending,
        }
    }
}

/// The plugin's structured failure as a protocol error.
fn error_to_protocol(failure: PluginFailure) -> PluginProtocolError {
    PluginProtocolError::new(failure.code, failure.message)
}

fn rejected(message: impl Into<String>) -> PluginProtocolError {
    PluginProtocolError::new(PluginFailureCode::Rejected, message)
}

/// Stream the approved library in bounded frames, preserving local read errors
/// as transport errors instead of disguising them as end-of-file.
fn artifact_chunk_frames<R: Read>(
    mut library: R,
    artifact_id: String,
    chunk_size: usize,
    source_error: Arc<std::sync::Mutex<Option<String>>>,
) -> impl Iterator<Item = v1::ArtifactTransferFrame> {
    let mut offset = 0_u64;
    let mut source_done = false;
    std::iter::from_fn(move || {
        if source_done {
            return None;
        }
        let mut bytes = vec![0_u8; chunk_size];
        match library.read(&mut bytes) {
            Ok(0) => {
                source_done = true;
                None
            }
            Ok(count) => {
                bytes.truncate(count);
                let frame = v1::ArtifactTransferFrame {
                    frame: Some(v1::artifact_transfer_frame::Frame::Chunk(
                        v1::ArtifactTransferChunk {
                            artifact_id: artifact_id.clone(),
                            offset,
                            bytes,
                        },
                    )),
                };
                offset += count as u64;
                Some(frame)
            }
            Err(error) => {
                source_done = true;
                *source_error
                    .lock()
                    .expect("artifact stream error mutex is not poisoned") = Some(format!(
                    "failed reading approved plugin artifact at byte {offset}: {error}"
                ));
                None
            }
        }
    })
}

/// Read the manifest and resolve its library after confirming the kernel's
/// approval still describes the source artifact. The receiver independently
/// hashes both streams before making either file loadable.
fn artifact_transfer_sources(
    request: &PluginLoadRequest,
) -> Result<(Vec<u8>, PathBuf, String), PluginProtocolError> {
    let (manifest_digest, library_digest) =
        nemo_relay::plugin::dynamic::plugin_artifact_identity(&request.artifact)
            .map_err(|error| rejected(format!("the approved artifact cannot be read: {error}")))?;
    if manifest_digest != request.identity.manifest_sha256
        || library_digest != request.identity.library_sha256
    {
        return Err(rejected(
            "the source artifact no longer matches the kernel's approved identity",
        ));
    }
    let reference = PathBuf::from(&request.artifact);
    let manifest_path = if reference.is_dir() {
        reference.join(nemo_relay::plugin::dynamic::DYNAMIC_PLUGIN_MANIFEST_FILENAME)
    } else {
        reference
    };
    let manifest = std::fs::read(&manifest_path)
        .map_err(|error| rejected(format!("cannot read approved plugin manifest: {error}")))?;
    if manifest.len() > 64 * 1024 {
        return Err(rejected("the approved plugin manifest exceeds 64 KiB"));
    }
    let text = std::str::from_utf8(&manifest).map_err(|error| {
        rejected(format!(
            "the approved plugin manifest is not UTF-8: {error}"
        ))
    })?;
    let parsed = nemo_relay::plugin::dynamic::DynamicPluginManifest::parse_toml(text)
        .map_err(|error| rejected(format!("the approved plugin manifest is invalid: {error}")))?;
    if parsed.plugin.id != request.plugin_id {
        return Err(rejected(
            "the approved plugin manifest declares a different plugin id",
        ));
    }
    let nemo_relay::plugin::dynamic::DynamicPluginManifestLoad::RustDynamic(load) = parsed.load
    else {
        return Err(rejected(
            "the approved plugin manifest does not describe a native library",
        ));
    };
    let library = load
        .library
        .ok_or_else(|| rejected("the approved plugin manifest has no library path"))?;
    let library = PathBuf::from(library);
    if library.is_absolute()
        || library.components().any(|component| {
            matches!(
                component,
                std::path::Component::ParentDir
                    | std::path::Component::RootDir
                    | std::path::Component::Prefix(_)
            )
        })
    {
        return Err(rejected(
            "the approved plugin manifest library path must stay inside its artifact directory",
        ));
    }
    let relative_library_path = library.to_string_lossy().into_owned();
    let library_path = if library.is_absolute() {
        library
    } else {
        manifest_path
            .parent()
            .unwrap_or_else(|| Path::new("."))
            .join(library)
    };
    Ok((manifest, library_path, relative_library_path))
}

fn unavailable(message: impl Into<String>) -> PluginProtocolError {
    PluginProtocolError::new(PluginFailureCode::Unavailable, message)
}

fn crashed(message: impl Into<String>) -> PluginProtocolError {
    PluginProtocolError::new(PluginFailureCode::HostCrashed, message)
}

/// Wall-clock milliseconds, for comparing against an absolute deadline.
fn now_unix_ms() -> Result<u64, PluginProtocolError> {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|error| unavailable(format!("the system clock is before the epoch: {error}")))?;
    Ok(now.as_millis() as u64)
}

/// A directory private to this account, for one host's socket.
///
/// The name is short on purpose: a Unix socket path has a small, fixed limit,
/// and the platform's temporary directory can already be most of it, so a long
/// name here would refuse to bind on a machine whose temp directory is deep. The
/// mode denies other users; it does not distinguish processes of the same account,
/// which is the boundary this socket is for.
fn create_runtime_dir() -> Result<PathBuf, PluginProtocolError> {
    // The random tail, not the timestamp: two hosts started in the same
    // millisecond would otherwise share a directory, and the second would find
    // the first's socket already there.
    let unique = Uuid::now_v7().simple().to_string();
    let dir = std::env::temp_dir().join(format!("nemo-ph-{}", &unique[20..]));
    let mut builder = std::fs::DirBuilder::new();
    #[cfg(unix)]
    {
        use std::os::unix::fs::DirBuilderExt;
        builder.mode(0o700);
    }
    builder
        .recursive(true)
        .create(&dir)
        .map_err(|error| unavailable(format!("failed to create '{}': {error}", dir.display())))?;
    Ok(dir)
}

/// Dial a host's socket.
async fn connect(socket: &Path) -> Result<Channel, String> {
    let path: Arc<PathBuf> = Arc::new(socket.to_path_buf());
    let endpoint = Endpoint::try_from("http://[::]:50051").map_err(|error| error.to_string())?;
    endpoint
        .connect_with_connector(service_fn(move |_| {
            let path = Arc::clone(&path);
            async move {
                UnixStream::connect(&*path)
                    .await
                    .map(hyper_util::rt::TokioIo::new)
            }
        }))
        .await
        .map_err(|error| error.to_string())
}

/// A request carrying the capability this session's operations have to present.
///
/// Every call after the handshake presents it, and the host refuses a call that
/// does not. The session's identity says which session a request means; this
/// says the request may use it — and an identity is what an attach announces,
/// so without this the two would be the same thing.
fn capable<T>(message: T, capability: &crate::capability::SessionCapability) -> tonic::Request<T> {
    let mut request = tonic::Request::new(message);
    request.metadata_mut().insert(
        crate::capability::SESSION_CAPABILITY_HEADER,
        tonic::metadata::MetadataValue::try_from(capability.as_str())
            .expect("a minted capability is ASCII hex, and so is a valid header value"),
    );
    request
}

/// What this kernel offers a host it is about to start.
///
/// Gathered rather than passed one argument at a time because these are one
/// decision — what the kernel will carry, and what it expects in return — and a
/// parameter list that is a bag of strings is one where two of them can be
/// passed in the wrong order.
struct HandshakeOffer<'a> {
    /// What the host must present to prove it is this kernel's.
    credential: &'a str,
    /// Digest of the runtime identity this session is bound to.
    runtime_binding_digest: &'a str,
    /// What the host beside this runtime is expected to have been built from.
    expected_host_build: &'a PluginHostBuild,
    /// Kernel-held state this host is offered.
    offered_read_capabilities: &'a [PluginHostReadCapability],
    /// Registration classes this kernel can install a proxy for.
    supported_registration_operations:
        &'a [nemo_relay_plugin_protocol::PluginRegistrationOperation],
    /// Largest frame this kernel is configured to carry.
    maximum_frame_bytes: u32,
}

/// Establish the session this host will answer on.
async fn handshake(
    client: &mut PluginHostClient<Channel>,
    offer: &HandshakeOffer<'_>,
    capability: &crate::capability::SessionCapability,
) -> Result<PluginSessionIdentity, PluginProtocolError> {
    let request = v1::HandshakeRequest {
        protocol_version: u32::from(PROTOCOL_VERSION),
        runtime_binding_digest: offer.runtime_binding_digest.to_string(),
        client_nonce: Uuid::now_v7().to_string(),
        session_credential: offer.credential.to_string(),
        // What this kernel is configured to carry, not the protocol's ceiling:
        // advertising the ceiling while decoding at a smaller limit would open a
        // session whose stated size nothing on this side honours.
        maximum_frame_bytes: offer.maximum_frame_bytes,
        supported_features: Vec::new(),
        offered_read_capabilities: offer
            .offered_read_capabilities
            .iter()
            .map(|capability| {
                nemo_relay_plugin_proto::convert::read_capability_to_wire(*capability)
            })
            .collect(),
        supported_registration_operations: offer
            .supported_registration_operations
            .iter()
            .map(|operation| {
                nemo_relay_plugin_proto::convert::registration_operation_to_wire(*operation)
            })
            .collect(),
    };
    let outcome = client
        .handshake(capable(request, capability))
        .await
        .map_err(|status| unavailable(format!("the plugin host did not answer: {status}")))?
        .into_inner();
    let identity = nemo_relay_plugin_proto::convert::handshake_outcome_from_wire(&outcome)?
        .into_result()
        .map_err(error_to_protocol)?;
    if identity.protocol_version != PROTOCOL_VERSION {
        return Err(PluginProtocolError::new(
            PluginFailureCode::VersionMismatch {
                expected: PROTOCOL_VERSION,
                received: identity.protocol_version,
            },
            format!(
                "the plugin host speaks version {}, this kernel speaks {}",
                identity.protocol_version, PROTOCOL_VERSION
            ),
        ));
    }
    // Before the frame limit and before any capability: a host from another
    // build is not a host whose answers mean what this runtime thinks they mean,
    // and everything below is a comparison against values this runtime chose.
    if let Some(disagreement) = identity
        .host_build
        .disagreement_with(offer.expected_host_build)
    {
        let (code, message) = disagreement.into_failure();
        return Err(PluginProtocolError::new(code, message));
    }
    if identity.maximum_frame_bytes > MAX_FRAME_BYTES {
        return Err(PluginProtocolError::new(
            PluginFailureCode::OversizedFrame {
                observed: u64::from(identity.maximum_frame_bytes),
                limit: MAX_FRAME_BYTES,
            },
            format!(
                "the plugin host will accept {} byte frames, above the {} this kernel speaks",
                identity.maximum_frame_bytes, MAX_FRAME_BYTES
            ),
        ));
    }
    if !identity.accepted_within(offer.offered_read_capabilities) {
        // A host cannot read what it was not offered, so an acceptance that
        // names something else is refused rather than believed.
        return Err(PluginProtocolError::new(
            PluginFailureCode::Rejected,
            "the plugin host accepted a read capability it was not offered".to_string(),
        ));
    }
    Ok(identity)
}

/// Mark every descriptor above stdio that the host must not inherit
/// close-on-exec.
///
/// The standard library opens its own descriptors close-on-exec, but an
/// inherited descriptor is not the supervisor's to trust: anything the kernel
/// process was handed without CLOEXEC — a launcher's log file, another
/// service's socket, a credential the deployment thought it had put away —
/// would otherwise cross into the host, and through the host into every plugin
/// it loads. The one deliberate exception is the confined host's kernel channel
/// descriptor, which is the child's only copy of that channel; it is named by
/// `preserve` and is left alone (the spawn clears its flag separately).
///
/// Coverage is complete by construction, not by bound. On Linux `close_range`
/// marks the entire descriptor space in one syscall, above any ceiling a loop
/// could stop at. Where the kernel lacks that call the boundary is
/// `inventory`: the open-descriptor snapshot the parent took before `fork`,
/// so every descriptor the kernel reported open is marked. The bounded sweep
/// after it is only a backstop for a descriptor opened in the narrow window
/// between snapshot and `exec`, and it is not what the guarantee stands on.
///
/// Marking rather than closing is deliberate. The standard library keeps a
/// private close-on-exec pipe between parent and child so a failed `exec` is
/// reported instead of looking like a successful spawn; a loop that *closed*
/// descriptors would close that pipe before the `exec` attempt and turn every
/// exec failure into a host that silently never starts. Setting the flag is
/// idempotent for descriptors that already carry it — including that pipe —
/// so the child's table gains exactly the property this boundary is about and
/// the machinery around it keeps working.
///
/// Runs between `fork` and `exec`: every call here is a raw syscall or a read
/// of the captured inventory, so it allocates nothing and cannot deadlock
/// against a lock another thread held at fork time. A marking failure other
/// than EBADF is returned, not ignored: a host that cannot establish the
/// boundary is a host that does not start.
#[cfg(unix)]
fn mark_inherited_descriptors_close_on_exec(
    preserve: Option<std::os::fd::RawFd>,
    inventory: &[std::os::fd::RawFd],
) -> std::io::Result<()> {
    // The complete mechanism first: one call covers every descriptor number
    // the kernel can mint, including any opened after the inventory was
    // taken. A kernel without it — or without the CLOEXEC flag for it —
    // falls through to the inventory path rather than running unconfined.
    #[cfg(target_os = "linux")]
    if close_range_cloexec(preserve)? {
        return Ok(());
    }

    // The inventory is the boundary: every descriptor the parent observed
    // open gets marked, however high its number.
    for &descriptor in inventory {
        if descriptor < 3 || Some(descriptor) == preserve {
            continue;
        }
        mark_cloexec(descriptor)?;
    }
    // The backstop for the snapshot-to-exec window. It stays bounded on
    // purpose — the guarantee above does not stand on it — and a slot that
    // was never open answers EBADF, the expected result.
    let bound = supplementary_sweep_bound();
    for descriptor in 3..bound {
        if Some(descriptor) == preserve {
            continue;
        }
        mark_cloexec(descriptor)?;
    }
    Ok(())
}

/// One `F_SETFD` for the boundary. `EBADF` is the expected answer for a slot
/// that was never open; anything else is a containment failure the spawn
/// reports rather than ignores.
#[cfg(unix)]
fn mark_cloexec(descriptor: std::os::fd::RawFd) -> std::io::Result<()> {
    // Safety: the raw descriptor is borrowed for the duration of the call
    // and never closed here.
    let borrowed = unsafe { rustix::fd::BorrowedFd::borrow_raw(descriptor) };
    match rustix::io::fcntl_setfd(borrowed, rustix::io::FdFlags::CLOEXEC) {
        Ok(()) | Err(rustix::io::Errno::BADF) => Ok(()),
        Err(error) => Err(std::io::Error::other(format!(
            "descriptor {descriptor} could not be marked close-on-exec: {error}"
        ))),
    }
}

/// The bound on the supplementary sweep — the smaller of the process's hard
/// descriptor limit and the shipped constant. Neither is the boundary; this
/// only bounds the backstop's worst case.
#[cfg(unix)]
fn supplementary_sweep_bound() -> std::os::fd::RawFd {
    let bound = crate::limits::SUPPLEMENTARY_DESCRIPTOR_SWEEP_BOUND;
    let hard = rustix::process::getrlimit(rustix::process::Resource::Nofile)
        .maximum
        .unwrap_or(bound);
    hard.min(bound) as std::os::fd::RawFd
}

/// Mark every descriptor above stdio close-on-exec in one kernel call, or
/// report that this kernel cannot.
///
/// `Ok(true)` means the entire descriptor space is covered and no fallback
/// is needed. `Ok(false)` means the kernel lacks the call or the
/// `CLOSE_RANGE_CLOEXEC` flag and the caller should fall back to the
/// inventory. `Err` is a real failure: a boundary that cannot be established
/// is a host that does not start.
#[cfg(target_os = "linux")]
fn close_range_cloexec(preserve: Option<std::os::fd::RawFd>) -> std::io::Result<bool> {
    // `<sys/close_range.h>`: CLOSE_RANGE_CLOEXEC.
    const CLOSE_RANGE_CLOEXEC: libc::c_int = 1 << 3;
    // The call is unsigned; a preserved descriptor outside the marked space
    // needs no range carved around it.
    let preserve = preserve
        .filter(|descriptor| *descriptor >= 3)
        .map(|descriptor| descriptor as u32);
    let spans: [(u32, u32); 2] = match preserve {
        Some(preserved) if preserved > 3 && preserved < u32::MAX => {
            [(3, preserved - 1), (preserved + 1, u32::MAX)]
        }
        Some(3) => [(4, u32::MAX), (0, 0)],
        Some(_) => [(3, u32::MAX - 1), (0, 0)],
        None => [(3, u32::MAX), (0, 0)],
    };
    for (first, last) in spans {
        if first > last {
            continue;
        }
        // Safety: `close_range` touches no memory and marks only this
        // process's own descriptors; the arguments are within range by
        // construction.
        if unsafe { libc::syscall(libc::SYS_close_range, first, last, CLOSE_RANGE_CLOEXEC) } != 0 {
            let error = std::io::Error::last_os_error();
            return match error.raw_os_error() {
                // Kernel older than 5.9 has no such call; 5.9–5.10 has it
                // without the CLOEXEC flag and answers EINVAL. Both mean the
                // inventory is the boundary here, not that the boundary
                // failed.
                Some(libc::ENOSYS) | Some(libc::EINVAL) => Ok(false),
                _ => Err(error),
            };
        }
    }
    Ok(true)
}

/// The process's open descriptors, enumerated in the parent before `fork`.
///
/// The fallback boundary marks against a real table rather than a guessed
/// bound: whatever the kernel reports open here is what the child marks
/// close-on-exec. An enumeration that cannot run is a containment failure —
/// a host started without the boundary is worse than none.
#[cfg(unix)]
fn open_descriptor_inventory() -> std::io::Result<Vec<std::os::fd::RawFd>> {
    descriptor_inventory_impl()
}

/// Linux enumerates `/proc/self/fd`, with `/dev/fd` as the fallback for
/// kernels or containers where procfs is not mounted.
#[cfg(any(target_os = "linux", target_os = "android"))]
fn descriptor_inventory_impl() -> std::io::Result<Vec<std::os::fd::RawFd>> {
    fd_dir_inventory("/proc/self/fd").or_else(|_| fd_dir_inventory("/dev/fd"))
}

/// macOS has neither close_range nor a reliable descriptor filesystem:
/// `proc_pidinfo` reports the real table, and the buffer grows until the
/// kernel says it fit.
#[cfg(target_os = "macos")]
fn descriptor_inventory_impl() -> std::io::Result<Vec<std::os::fd::RawFd>> {
    let mut capacity = 1024usize;
    loop {
        let mut records = vec![
            libc::proc_fdinfo {
                proc_fd: 0,
                proc_fdtype: 0,
            };
            capacity
        ];
        // Safety: `records` is a live buffer of exactly the advertised size.
        let written = unsafe {
            libc::proc_pidinfo(
                libc::getpid(),
                libc::PROC_PIDLISTFDS,
                0,
                records.as_mut_ptr().cast::<libc::c_void>(),
                (capacity * std::mem::size_of::<libc::proc_fdinfo>()) as libc::c_int,
            )
        };
        if written < 0 {
            return Err(std::io::Error::last_os_error());
        }
        let count = written as usize / std::mem::size_of::<libc::proc_fdinfo>();
        if count < capacity {
            records.truncate(count);
            return Ok(records.into_iter().map(|record| record.proc_fd).collect());
        }
        capacity = capacity.saturating_mul(4);
        if capacity > (1 << 22) {
            return Err(std::io::Error::other(
                "the descriptor table kept growing past four million entries",
            ));
        }
    }
}

/// Every other unix target enumerates `/dev/fd` — the per-process view the
/// descriptor filesystem serves where it is mounted. Where it is not, the
/// spawn refuses rather than starting a host without the boundary.
#[cfg(all(
    unix,
    not(any(target_os = "linux", target_os = "android", target_os = "macos"))
))]
fn descriptor_inventory_impl() -> std::io::Result<Vec<std::os::fd::RawFd>> {
    fd_dir_inventory("/dev/fd")
}

/// Read a descriptor directory (`/proc/self/fd`, `/dev/fd`) into numbers.
/// A non-numeric entry is skipped rather than failing the inventory; a
/// directory that cannot be read fails it.
#[cfg(all(unix, not(target_os = "macos")))]
fn fd_dir_inventory(path: &str) -> std::io::Result<Vec<std::os::fd::RawFd>> {
    let entries = std::fs::read_dir(path).map_err(|error| {
        std::io::Error::new(
            error.kind(),
            format!("cannot enumerate {path} for descriptor containment: {error}"),
        )
    })?;
    let mut descriptors = Vec::new();
    for entry in entries {
        if let Ok(descriptor) = entry?
            .file_name()
            .to_string_lossy()
            .parse::<std::os::fd::RawFd>()
        {
            descriptors.push(descriptor);
        }
    }
    Ok(descriptors)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::host_location::executable_name;

    #[test]
    fn artifact_stream_preserves_source_read_errors() {
        struct FailsAfterPrefix {
            prefix: &'static [u8],
            sent: bool,
        }

        impl Read for FailsAfterPrefix {
            fn read(&mut self, buffer: &mut [u8]) -> std::io::Result<usize> {
                if !self.sent {
                    self.sent = true;
                    buffer[..self.prefix.len()].copy_from_slice(self.prefix);
                    return Ok(self.prefix.len());
                }
                Err(std::io::Error::other("injected EIO"))
            }
        }

        let source_error = Arc::new(std::sync::Mutex::new(None));
        let mut frames = artifact_chunk_frames(
            FailsAfterPrefix {
                prefix: b"part",
                sent: false,
            },
            "artifact-1".into(),
            8,
            Arc::clone(&source_error),
        );
        assert!(frames.next().is_some());
        assert!(frames.next().is_none(), "the failed stream terminates");
        let error = source_error
            .lock()
            .expect("test mutex is not poisoned")
            .take()
            .expect("the source read failure is recorded");
        assert!(error.contains("failed reading approved plugin artifact"));
        assert!(error.contains("injected EIO"));
        assert!(
            frames.next().is_none(),
            "the failed stream remains terminated"
        );
    }

    #[tokio::test]
    async fn a_missing_host_is_reported_with_the_places_it_was_looked_for() {
        // A deployment that received a runtime without the host cannot repair a
        // path it was never told, so the failure names the file, the locations
        // the resolver tries in order, and the variable that names one somewhere
        // else — rather than reporting only that a spawn failed.
        let config = PluginHostSupervisorConfig {
            executable: PathBuf::from("/nonexistent/nemo-plugin-host"),
            expected_host_build: PluginHostBuild::expected(env!("CARGO_PKG_VERSION")),
            runtime_binding_digest: "binding".to_string(),
            offered_read_capabilities: Vec::new(),
            maximum_frame_bytes: MAX_FRAME_BYTES,
            limits: crate::limits::PluginHostLimits::default(),
            isolation: crate::isolation_policy::NativeIsolationPolicy::default(),
            startup_timeout: Duration::from_secs(1),
        };
        let message = match PluginHostSupervisor::spawn(config).await {
            Ok(_) => panic!("a host that is not there does not start"),
            Err(error) => error.to_string(),
        };
        assert!(
            message.contains("/nonexistent/nemo-plugin-host"),
            "{message}"
        );
        assert!(message.contains(EXECUTABLE_ENV), "{message}");
        assert!(message.contains(executable_name()), "{message}");
    }

    #[tokio::test]
    async fn a_confinement_this_build_cannot_deliver_is_refused_before_anything_starts() {
        // The configuration says the host is confined. A build that cannot confine
        // it refuses rather than starting the host anyway: a boundary described in
        // configuration and absent from the process is worse than one that was
        // never asked for, because every reader downstream takes the
        // configuration for the truth. Nothing is created either — the decision
        // comes before the first socket.
        let config = PluginHostSupervisorConfig {
            isolation: crate::isolation_policy::NativeIsolationPolicy::RestrictedMacOS,
            ..PluginHostSupervisorConfig::beside_this_executable("binding")
        };

        let message = match PluginHostSupervisor::spawn(config).await {
            Ok(_) => panic!("a confinement this build cannot deliver does not start a host"),
            Err(error) => error.to_string(),
        };

        use crate::isolation_policy::RestrictionRequirement;
        assert!(message.contains("restricted-macos"), "{message}");
        #[cfg(target_os = "macos")]
        assert!(
            message.contains(crate::host_location::BUNDLE_NAME)
                || message.contains(RestrictionRequirement::StagedArtifactTransfer.message()),
            "the refusal names what is missing: {message}"
        );
        #[cfg(not(target_os = "macos"))]
        assert!(
            message.contains(RestrictionRequirement::MacOS.message()),
            "the refusal names what is missing: {message}"
        );
        assert!(
            !message.contains("failed to start plugin host"),
            "nothing was spawned to fail: {message}"
        );
    }

    // Where a host is found is `host_location`'s rule, and its tests live with it:
    // `an_override_that_names_a_host_is_the_host_that_is_used`,
    // `a_host_beside_the_process_is_found_when_nothing_names_one` and
    // `a_host_that_is_nowhere_is_named_rather_than_invented`. What stays here is
    // what the supervisor does with the answer, which is the test above.

    /// The descriptor boundary, exercised through real fork/execs: the parent
    /// opens descriptors without CLOEXEC — the shape a launcher's file or
    /// another service's socket has — the child runs the boundary, and a
    /// grandchild proves what actually crossed the second `exec`.
    #[test]
    fn inherited_descriptors_do_not_cross_exec() {
        use std::os::fd::AsRawFd;

        let directory = std::env::temp_dir().join(format!(
            "nemo-descriptor-boundary-{}",
            nemo_relay_plugin_protocol::Uuid::now_v7().simple()
        ));
        std::fs::create_dir_all(&directory).expect("a directory for the descriptor fixture");
        let leaked = std::fs::File::create(directory.join("leaked")).expect("the leaked file");
        let preserved =
            std::fs::File::create(directory.join("preserved")).expect("the preserved file");
        // The standard library opens descriptors close-on-exec; clear the flag
        // so both have the shape this boundary exists for.
        for file in [&leaked, &preserved] {
            rustix::io::fcntl_setfd(file, rustix::io::FdFlags::empty())
                .expect("clearing close-on-exec");
        }

        let witness = directory.join("witness");
        let status = std::process::Command::new(
            std::env::current_exe().expect("the test binary's own path"),
        )
        .arg("--exact")
        .arg("supervisor::tests::descriptor_boundary_child")
        .arg("--nocapture")
        .env(
            "NEMO_DESCRIPTOR_BOUNDARY_LEAKED",
            leaked.as_raw_fd().to_string(),
        )
        .env(
            "NEMO_DESCRIPTOR_BOUNDARY_PRESERVED",
            preserved.as_raw_fd().to_string(),
        )
        .env("NEMO_DESCRIPTOR_BOUNDARY_WITNESS", &witness)
        .env("NEMO_DESCRIPTOR_BOUNDARY_DIRECTORY", &directory)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .status()
        .expect("the child test binary runs");

        let ran = witness.exists();
        std::fs::remove_dir_all(&directory).ok();
        assert!(
            ran,
            "the child never ran the boundary: the test filter matched nothing"
        );
        assert!(
            status.success(),
            "the child reported the descriptor boundary did not hold"
        );
    }

    /// The child half of `inherited_descriptors_do_not_cross_exec`: it runs
    /// the boundary, asserts the flag the boundary sets, and re-execs a
    /// grandchild so the property that actually matters — the descriptor is
    /// gone after `exec` — is observed rather than inferred.
    #[test]
    fn descriptor_boundary_child() {
        let Ok(leaked) = std::env::var("NEMO_DESCRIPTOR_BOUNDARY_LEAKED") else {
            return;
        };
        let leaked: std::os::fd::RawFd = leaked.parse().expect("a leaked descriptor number");
        let preserved: std::os::fd::RawFd = std::env::var("NEMO_DESCRIPTOR_BOUNDARY_PRESERVED")
            .expect("a preserved descriptor number")
            .parse()
            .expect("a preserved descriptor number");
        let witness = std::env::var("NEMO_DESCRIPTOR_BOUNDARY_WITNESS")
            .expect("a witness path for the parent");
        let directory =
            std::env::var("NEMO_DESCRIPTOR_BOUNDARY_DIRECTORY").expect("the fixture directory");

        let inventory = open_descriptor_inventory()
            .expect("the child's descriptor table enumerates for the boundary");
        mark_inherited_descriptors_close_on_exec(Some(preserved), &inventory)
            .expect("the descriptor boundary applies");

        // Safety: the descriptors were inherited from the parent and are only
        // interrogated here.
        let (leaked_flags, preserved_flags) = unsafe {
            (
                rustix::io::fcntl_getfd(rustix::fd::BorrowedFd::borrow_raw(leaked)).ok(),
                rustix::io::fcntl_getfd(rustix::fd::BorrowedFd::borrow_raw(preserved)).ok(),
            )
        };
        std::fs::write(
            &witness,
            format!("leaked={leaked_flags:?} preserved={preserved_flags:?}"),
        )
        .expect("the witness file");
        let leaked_flags = leaked_flags.expect("the leaked descriptor is still open before exec");
        assert!(
            leaked_flags.contains(rustix::io::FdFlags::CLOEXEC),
            "an inherited descriptor was left crossing exec"
        );
        assert!(
            !preserved_flags
                .expect("the preserved descriptor is still open")
                .contains(rustix::io::FdFlags::CLOEXEC),
            "the preserved descriptor was marked for closing"
        );

        // The property itself: a descriptor marked close-on-exec is gone in
        // the next process, and one that was preserved is still there.
        let grandchild_witness = std::path::Path::new(&directory).join("grandchild-witness");
        let status = std::process::Command::new(
            std::env::current_exe().expect("the test binary's own path"),
        )
        .arg("--exact")
        .arg("supervisor::tests::descriptor_boundary_grandchild")
        .arg("--nocapture")
        .env("NEMO_DESCRIPTOR_BOUNDARY_LEAKED", leaked.to_string())
        .env("NEMO_DESCRIPTOR_BOUNDARY_PRESERVED", preserved.to_string())
        .env("NEMO_DESCRIPTOR_BOUNDARY_WITNESS", &grandchild_witness)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .status()
        .expect("the grandchild test binary runs");
        assert!(
            grandchild_witness.exists(),
            "the grandchild never ran: the test filter matched nothing"
        );
        assert!(
            status.success(),
            "the grandchild reported a descriptor crossed exec"
        );
    }

    /// The grandchild half of `inherited_descriptors_do_not_cross_exec`; a
    /// no-op when the harness runs it as part of the ordinary suite.
    #[test]
    fn descriptor_boundary_grandchild() {
        let Ok(leaked) = std::env::var("NEMO_DESCRIPTOR_BOUNDARY_LEAKED") else {
            return;
        };
        let leaked: std::os::fd::RawFd = leaked.parse().expect("a leaked descriptor number");
        let preserved: std::os::fd::RawFd = std::env::var("NEMO_DESCRIPTOR_BOUNDARY_PRESERVED")
            .expect("a preserved descriptor number")
            .parse()
            .expect("a preserved descriptor number");
        let witness = std::env::var("NEMO_DESCRIPTOR_BOUNDARY_WITNESS")
            .expect("a witness path for the parent");

        // Safety: the descriptors were inherited from the parent process and
        // are only interrogated here.
        let (leaked_open, preserved_open) = unsafe {
            (
                rustix::io::fcntl_getfd(rustix::fd::BorrowedFd::borrow_raw(leaked)).is_ok(),
                rustix::io::fcntl_getfd(rustix::fd::BorrowedFd::borrow_raw(preserved)).is_ok(),
            )
        };
        std::fs::write(
            &witness,
            format!("leaked={leaked_open} preserved={preserved_open}"),
        )
        .expect("the grandchild witness file");
        assert!(
            !leaked_open,
            "a descriptor the host must not inherit crossed exec"
        );
        assert!(
            preserved_open,
            "the preserved descriptor did not cross exec"
        );
    }

    /// The sweep's own bound is part of the boundary's contract: a
    /// descriptor planted ABOVE the historical 65,536 ceiling, left
    /// inheritable, is still the supervisor's responsibility — whatever
    /// the launcher handed this process is exactly what the confined
    /// host would otherwise inherit.
    ///
    /// Hosts whose descriptor hard limit cannot place an fd that high
    /// cannot run this check; they print SKIP and return. A skip is a
    /// qualification gap to close on a capable runner, never evidence
    /// that the guarantee held on this host.
    #[test]
    fn inherited_descriptor_above_the_legacy_ceiling_is_marked() {
        use std::os::fd::AsRawFd;

        const PLANTED_FD: std::os::fd::RawFd = 70_000;

        let rlimit = rustix::process::getrlimit(rustix::process::Resource::Nofile);
        if let Some(hard) = rlimit.maximum {
            if hard <= PLANTED_FD as u64 {
                eprintln!(
                    "SKIP: descriptor hard limit {hard} cannot place fd {PLANTED_FD} — \
                     this host cannot qualify the high-descriptor boundary"
                );
                return;
            }
        }
        let needed = PLANTED_FD as u64 + 1024;
        if rlimit.current.is_some_and(|soft| soft < needed) {
            if let Err(error) = rustix::process::setrlimit(
                rustix::process::Resource::Nofile,
                rustix::process::Rlimit {
                    current: Some(needed),
                    maximum: rlimit.maximum,
                },
            ) {
                eprintln!(
                    "SKIP: raising the soft descriptor limit for the planted fd failed: \
                     {error} — this host cannot qualify the high-descriptor boundary"
                );
                return;
            }
        }

        let directory = std::env::temp_dir().join(format!(
            "nemo-descriptor-high-fd-{}",
            nemo_relay_plugin_protocol::Uuid::now_v7().simple()
        ));
        std::fs::create_dir_all(&directory).expect("a directory for the high-fd fixture");
        let source = std::fs::File::create(directory.join("planted"))
            .expect("the planted descriptor's file");

        // F_DUPFD places the duplicate at the first free number at or
        // above the floor; clearing the flag then gives it the shape a
        // launcher's log file or a credential handle arrives in. A
        // kernel that cannot place a descriptor there — macOS caps a
        // process below the legacy ceiling outright — cannot run the
        // check and reports SKIP rather than pretending to.
        let planted = match rustix::io::fcntl_dupfd_cloexec(&source, PLANTED_FD) {
            Ok(fd) => fd,
            Err(error) => {
                eprintln!(
                    "SKIP: the kernel cannot plant a descriptor at {PLANTED_FD} \
                     ({error}) — this host cannot qualify the high-descriptor boundary"
                );
                std::fs::remove_dir_all(&directory).ok();
                return;
            }
        };
        rustix::io::fcntl_setfd(&planted, rustix::io::FdFlags::empty())
            .expect("the planted descriptor starts inheritable");
        let planted_fd = planted.as_raw_fd();
        assert!(
            planted_fd >= PLANTED_FD,
            "the planted descriptor landed at {planted_fd}, below the legacy ceiling"
        );
        assert!(
            !rustix::io::fcntl_getfd(&planted)
                .expect("the planted descriptor is open")
                .contains(rustix::io::FdFlags::CLOEXEC),
            "the fixture must start inheritable"
        );

        // The inventory is taken after planting: on the fallback path the
        // planted descriptor is above every bound the sweep could reach, so
        // only the inventory — or Linux's complete `close_range` — can cover
        // it. That is the property this test qualifies.
        let inventory =
            open_descriptor_inventory().expect("the descriptor table enumerates for the boundary");
        mark_inherited_descriptors_close_on_exec(None, &inventory)
            .expect("the descriptor boundary applies");

        let flags = rustix::io::fcntl_getfd(&planted)
            .expect("the planted descriptor stays open until exec");
        drop(planted);
        drop(source);
        std::fs::remove_dir_all(&directory).ok();
        assert!(
            flags.contains(rustix::io::FdFlags::CLOEXEC),
            "descriptor {planted_fd} above the legacy sweep ceiling was left inheritable — \
             it would cross exec into the confined host"
        );
    }

    /// The fallback boundary stands on the inventory, so the inventory must
    /// actually see what is open: a descriptor planted inheritable is in the
    /// snapshot. This is the qualification the macOS fallback runs on — the
    /// high-descriptor test above can only run where the kernel can place
    /// one.
    #[test]
    fn the_inventory_reports_an_open_descriptor() {
        use std::os::fd::AsRawFd;

        let file = std::fs::File::create(
            std::env::temp_dir().join("nemo-inventory-witness"),
        )
        .expect("a file for the inventory check");
        rustix::io::fcntl_setfd(&file, rustix::io::FdFlags::empty())
            .expect("the descriptor starts inheritable");
        let inventory =
            open_descriptor_inventory().expect("the descriptor table enumerates for the boundary");
        assert!(
            inventory.contains(&file.as_raw_fd()),
            "an open descriptor is absent from the inventory the boundary marks against"
        );
    }
}
