# SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Tests for the built-in observability plugin config helpers."""

from __future__ import annotations

import http.server
import json
import threading
import time
import typing
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from nemo_relay import (
    PropagationContext,
    ScopeType,
    create_scope_stack_from_propagation,
    plugin,
    scope,
    subscribers,
    use_scope_stack,
)
from nemo_relay.observability import (
    OBSERVABILITY_PLUGIN_KIND,
    AtifConfig,
    AtofConfig,
    AtofEndpointConfig,
    AtofFileSinkConfig,
    AtofStreamSinkConfig,
    ComponentSpec,
    HttpStorageConfig,
    ObservabilityConfig,
    OpenTelemetryEndpointConfig,
    OpenTelemetryLogSectionConfig,
    OpenTelemetryMetricSectionConfig,
    OpenTelemetrySectionConfig,
    OpenTelemetrySignalEndpointConfig,
    S3StorageConfig,
)

if typing.TYPE_CHECKING:
    from pathlib import Path


class _AtofCaptureServer(http.server.ThreadingHTTPServer):
    requests: list[tuple[dict[str, str], bytes]]
    request_event: threading.Event


class _AtofCaptureHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self) -> None:  # noqa: N802
        content_length = int(self.headers.get("content-length", "0"))
        server = typing.cast(_AtofCaptureServer, self.server)
        server.requests.append((dict(self.headers.items()), self.rfile.read(content_length)))
        server.request_event.set()
        self.send_response(200)
        self.end_headers()

    def log_message(self, format: str, *args: object) -> None:  # noqa: ARG002
        return


class _AtofCapture:
    server: "_AtofCaptureServer"
    thread: threading.Thread

    def __enter__(self) -> _AtofCapture:
        self.server = _AtofCaptureServer(("127.0.0.1", 0), _AtofCaptureHandler)
        self.server.requests = []
        self.server.request_event = threading.Event()
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *args: object) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=1)

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.server.server_port}"

    def wait_for_requests(self, expected: int, timeout: float = 5.0) -> list[tuple[dict[str, str], bytes]]:
        deadline = time.monotonic() + timeout
        while len(self.server.requests) < expected:
            remaining = deadline - time.monotonic()
            assert remaining > 0, f"timed out waiting for {expected} ATOF requests"
            self.server.request_event.wait(remaining)
            self.server.request_event.clear()
        return self.server.requests


class TestObservabilityConfigHelpers:
    def test_opentelemetry_endpoint_preserves_existing_positional_arguments(self):
        endpoint = OpenTelemetryEndpointConfig(
            "full",
            "http://localhost:4318/v1/traces",
            "event",
            ["custom.mark"],
            [{"key": "source", "alias": "destination"}],
            "grpc",
            "relay-service",
            "relay-namespace",
            "1.2.3",
            "relay-instrumentation",
            1234,
            {"x-test": "header"},
            {"authorization": "OTEL_AUTHORIZATION"},
            {"deployment.environment": "test"},
        )

        assert endpoint.headers == {"x-test": "header"}
        assert endpoint.header_env == {"authorization": "OTEL_AUTHORIZATION"}
        assert endpoint.resource_attributes == {"deployment.environment": "test"}
        assert endpoint.max_queue_size is None
        assert endpoint.max_export_batch_size is None
        assert endpoint.scheduled_delay_millis is None
        assert endpoint.completed_span_context_ttl_millis is None

    def test_defaults_and_component_wrapper(self):
        assert AtofConfig().to_dict() == {"enabled": False}
        assert AtifConfig().to_dict() == {
            "enabled": False,
            "agent_name": "NeMo Relay",
            "model_name": "unknown",
            "filename_template": "nemo-relay-atif-{session_id}.json",
        }
        assert OpenTelemetrySectionConfig().to_dict() == {
            "enabled": False,
            "endpoints": [],
        }
        assert OpenTelemetryEndpointConfig(
            "gen_ai",
            "http://localhost:4318/v1/traces",
            header_env={"authorization": "OTEL_AUTHORIZATION"},
            max_queue_size=4096,
            max_export_batch_size=256,
            scheduled_delay_millis=750,
            completed_span_context_ttl_millis=60_000,
        ).to_dict() == {
            "type": "gen_ai",
            "endpoint": "http://localhost:4318/v1/traces",
            "mark_projection": "inherit",
            "mark_exclude_names": ["llm.chunk"],
            "attribute_mappings": [],
            "promote_metadata_prefixes": [],
            "promote_resource_metadata_prefixes": [],
            "transport": "http_binary",
            "service_name": "unknown_service",
            "instrumentation_scope": "opentelemetry",
            "timeout_millis": 3000,
            "max_queue_size": 4096,
            "max_export_batch_size": 256,
            "scheduled_delay_millis": 750,
            "completed_span_context_ttl_millis": 60_000,
            "headers": {},
            "header_env": {"authorization": "OTEL_AUTHORIZATION"},
            "resource_attributes": {},
        }
        endpoint = OpenTelemetryEndpointConfig(
            "gen_ai",
            "http://localhost:4318/v1/traces",
            promote_metadata_prefixes=["nv."],
        )
        assert endpoint.to_dict()["promote_metadata_prefixes"] == ["nv."]
        endpoint.promote_resource_metadata_prefixes = ["deployment."]
        assert endpoint.to_dict()["promote_resource_metadata_prefixes"] == ["deployment."]

        wrapped = ComponentSpec(ObservabilityConfig(atof=AtofConfig())).to_dict()
        assert wrapped["kind"] == OBSERVABILITY_PLUGIN_KIND
        assert wrapped["enabled"] is True
        wrapped_config = wrapped["config"]
        assert isinstance(wrapped_config, dict)
        assert wrapped_config["version"] == 4
        assert wrapped_config["enable_full_payloads"] is False

        full_payload_config = ObservabilityConfig(enable_full_payloads=True).to_dict()
        assert full_payload_config["enable_full_payloads"] is True

    def test_opentelemetry_signal_section_defaults_and_serialization(self):
        endpoint = OpenTelemetrySignalEndpointConfig(
            "https://collector.example/custom/logs",
            headers={"x-static": "value"},
            header_env={"authorization": "OTEL_AUTHORIZATION"},
            resource_attributes={"nv.project": "observability-dev"},
            service_namespace="telemetry",
            service_version="1.0",
        )
        assert endpoint.to_dict() == {
            "endpoint": "https://collector.example/custom/logs",
            "transport": "http_binary",
            "headers": {"x-static": "value"},
            "header_env": {"authorization": "OTEL_AUTHORIZATION"},
            "resource_attributes": {"nv.project": "observability-dev"},
            "service_name": "unknown_service",
            "service_namespace": "telemetry",
            "service_version": "1.0",
            "instrumentation_scope": "opentelemetry",
            "timeout_millis": 3000,
        }

        logs = OpenTelemetryLogSectionConfig(enabled=True, endpoints=[endpoint])
        metrics = OpenTelemetryMetricSectionConfig(enabled=True, endpoints=[endpoint])
        assert OpenTelemetryLogSectionConfig().to_dict() == {
            "enabled": False,
            "minimum_severity": "info",
            "max_queue_size": 2048,
            "max_export_batch_size": 512,
            "scheduled_delay_millis": 1000,
        }
        assert OpenTelemetryMetricSectionConfig().to_dict() == {
            "enabled": False,
            "export_interval_millis": 60000,
            "temporality": "cumulative",
            "max_instruments": 256,
            "cardinality_limit": 2000,
        }

        section = OpenTelemetrySectionConfig(enabled=True, logs=logs, metrics=metrics).to_dict()
        assert section["logs"] == logs.to_dict()
        assert section["metrics"] == metrics.to_dict()
        assert typing.cast(dict[str, object], section["metrics"])["endpoints"] == [endpoint.to_dict()]

    def test_validation_rejects_bad_values(self):
        report = plugin.validate(
            plugin.PluginConfig(
                components=[
                    ComponentSpec(
                        {
                            "version": 3,
                            "atof": {"sinks": [{"type": "file", "mode": "bad"}]},
                            "atif": {"filename_template": "missing-placeholder"},
                        }
                    )
                ]
            )
        )
        fields = {diag.get("field") for diag in report["diagnostics"]}
        assert {"sinks[0].mode", "filename_template"} <= fields

    def test_list_kinds_includes_builtin_observability(self):
        assert OBSERVABILITY_PLUGIN_KIND in plugin.list_kinds()

    def test_s3_storage_config_serializes_credential_fields(self):
        storage = S3StorageConfig(
            bucket="my-bucket",
            key_prefix="prefix/",
            access_key_id="AKIAEXAMPLE",
            secret_access_key_var="MY_SECRET",
            session_token_var="MY_TOKEN",
            region="us-west-2",
            endpoint_url="https://s3.example.com",
            allow_http=False,
        )
        assert storage.to_dict() == {
            "type": "s3",
            "bucket": "my-bucket",
            "key_prefix": "prefix/",
            "access_key_id": "AKIAEXAMPLE",
            "secret_access_key_var": "MY_SECRET",
            "session_token_var": "MY_TOKEN",
            "region": "us-west-2",
            "endpoint_url": "https://s3.example.com",
            "allow_http": False,
        }
        atif = AtifConfig(enabled=True, storage=[storage])
        assert atif.to_dict()["storage"] == [storage.to_dict()]

    def test_atof_sink_config_serializes_streaming_fields(self):
        sink = AtofStreamSinkConfig(
            url="http://localhost:8080/events",
            name="switchyard",
            transport="http_post",
            headers={"X-Test": "yes"},
            header_env={"authorization": "NEMO_RELAY_ATOF_AUTH"},
            timeout_millis=1000,
            field_name_policy="replace_dots",
        )
        assert sink.to_dict() == {
            "type": "stream",
            "name": "switchyard",
            "url": "http://localhost:8080/events",
            "transport": "http_post",
            "headers": {"X-Test": "yes"},
            "header_env": {"authorization": "NEMO_RELAY_ATOF_AUTH"},
            "timeout_millis": 1000,
            "field_name_policy": "replace_dots",
        }
        assert AtofConfig(sinks=[sink]).to_dict()["sinks"] == [sink.to_dict()]
        assert "name" not in AtofStreamSinkConfig(url="http://localhost:8080/events").to_dict()

    def test_atof_endpoint_alias_preserves_positional_transport(self):
        endpoint = AtofEndpointConfig("http://localhost:8080/events", "websocket")
        assert endpoint.transport == "websocket"
        assert endpoint.name is None

    async def test_atof_stream_sink_snapshots_header_env(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ):
        variable = "NEMO_RELAY_TEST_ATOF_HEADER_ENV"
        credential = "Bearer relay-499"
        monkeypatch.setenv(variable, credential)

        with _AtofCapture() as capture:
            config = ObservabilityConfig(
                atof=AtofConfig(
                    enabled=True,
                    sinks=[
                        AtofStreamSinkConfig(
                            url=capture.url,
                            transport="http_post",
                            header_env={"authorization": variable},
                        )
                    ],
                )
            )
            report = await plugin.initialize(plugin.PluginConfig(components=[ComponentSpec(config)]))
            assert report["diagnostics"] == []
            monkeypatch.delenv(variable)

            try:
                with scope.scope("python-header-env-agent", ScopeType.Agent) as handle:
                    scope.event("python-header-env-mark", handle=handle, data={"step": 1})
            finally:
                await plugin.clear_async()
            requests = capture.wait_for_requests(3)

        assert len(requests) == 3
        payload = b"".join(body for _, body in requests).decode()
        assert '"scope_category":"start"' in payload
        assert '"name":"python-header-env-mark"' in payload
        assert '"scope_category":"end"' in payload
        for headers, _ in requests:
            authorization = next(value for name, value in headers.items() if name.lower() == "authorization")
            assert authorization == credential
        assert credential not in json.dumps(report)
        assert credential not in caplog.text

    def test_http_storage_config_serializes_headers(self):
        s3 = S3StorageConfig(bucket="archive")
        http = HttpStorageConfig(
            endpoint="https://example.com/atif",
            headers={"x-static": "value"},
            header_env={"authorization": "NEMO_RELAY_ATIF_HTTP_AUTH"},
            timeout_millis=1500,
        )
        assert http.to_dict() == {
            "type": "http",
            "endpoint": "https://example.com/atif",
            "headers": {"x-static": "value"},
            "header_env": {"authorization": "NEMO_RELAY_ATIF_HTTP_AUTH"},
            "timeout_millis": 1500,
        }
        atif = AtifConfig(enabled=True, storage=[s3, http])
        assert atif.to_dict()["storage"] == [s3.to_dict(), http.to_dict()]

    @pytest.mark.parametrize("use_context_manager", [True, False])
    async def test_atof_and_atif_file_outputs(self, tmp_path: Path, use_context_manager: bool):
        config = ObservabilityConfig(
            atof=AtofConfig(
                enabled=True,
                sinks=[
                    AtofFileSinkConfig(
                        output_directory=str(tmp_path),
                        filename="events.jsonl",
                        mode="overwrite",
                    )
                ],
            ),
            atif=AtifConfig(
                enabled=True,
                agent_name="python-agent",
                agent_version="1.2.3",
                model_name="python-model",
                tool_definitions=[{"name": "search"}],
                extra={"binding": "python"},
                output_directory=str(tmp_path),
                filename_template="trajectory-{session_id}.json",
            ),
        )

        def _inner():
            with scope.scope("python-observability-agent", ScopeType.Agent) as handle:
                scope.event("python-mark", handle=handle, data={"step": 1})

            return handle

        plugin_config = plugin.PluginConfig(components=[ComponentSpec(config)])
        if use_context_manager:
            async with plugin.plugin(plugin_config):
                handle = _inner()
        else:
            await plugin.initialize(plugin_config)
            try:
                handle = _inner()
            finally:
                await plugin.clear_async()

        lines = (tmp_path / "events.jsonl").read_text().strip().splitlines()
        assert len(lines) == 3
        assert json.loads(lines[1])["name"] == "python-mark"

        trajectory = json.loads((tmp_path / f"trajectory-{handle.uuid}.json").read_text())
        assert trajectory["agent"]["name"] == "python-agent"
        assert trajectory["agent"]["version"] == "1.2.3"
        assert trajectory["agent"]["model_name"] == "python-model"
        assert trajectory["agent"]["tool_definitions"][0]["name"] == "search"
        assert trajectory["agent"]["extra"]["binding"] == "python"
        assert "python-observability-agent" in json.dumps(trajectory["extra"])

    @pytest.mark.parametrize(
        ("field_name_policy", "expected_data"),
        [
            (
                "preserve",
                {
                    "service.name": "relay",
                    "nested": {"deployment.region": "us-east"},
                },
            ),
            (
                "replace_dots",
                {
                    "service_name": "relay",
                    "nested": {"deployment_region": "us-east"},
                },
            ),
        ],
    )
    async def test_atof_stream_sink_dotted_fields_deliver_during_plugin_clear(
        self,
        tmp_path: Path,
        field_name_policy: typing.Literal["preserve", "replace_dots"],
        expected_data: dict[str, object],
    ):
        received: list[bytes] = []
        request_received = threading.Event()
        allow_response = threading.Event()
        teardown_started = threading.Event()

        class CaptureHandler(BaseHTTPRequestHandler):
            def do_POST(self):
                content_length = int(self.headers["Content-Length"])
                received.append(self.rfile.read(content_length))
                request_received.set()
                assert allow_response.wait(timeout=5)
                self.send_response(204)
                self.end_headers()

            def log_message(self, format: str, *args: typing.Any) -> None:
                return None

        server = HTTPServer(("127.0.0.1", 0), CaptureHandler)
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()
        cleared = False
        try:
            await plugin.initialize(
                plugin.PluginConfig(
                    components=[
                        ComponentSpec(
                            ObservabilityConfig(
                                atof=AtofConfig(
                                    enabled=True,
                                    sinks=[
                                        AtofFileSinkConfig(
                                            output_directory=str(tmp_path),
                                            filename="events.jsonl",
                                            mode="overwrite",
                                        ),
                                        AtofStreamSinkConfig(
                                            url=f"http://127.0.0.1:{server.server_port}/events",
                                            timeout_millis=5000,
                                            field_name_policy=field_name_policy,
                                        ),
                                    ],
                                )
                            )
                        )
                    ]
                )
            )
            with scope.scope("python-stream-agent", ScopeType.Agent) as handle:
                scope.event(
                    "python-dotted-mark",
                    handle=handle,
                    data={
                        "service.name": "relay",
                        "nested": {"deployment.region": "us-east"},
                    },
                )

            def release_response() -> None:
                teardown_started.wait(timeout=5)
                request_received.wait(timeout=5)
                allow_response.set()

            response_thread = threading.Thread(target=release_response, daemon=True)
            response_thread.start()
            teardown_started.set()
            started_at = time.monotonic()
            await plugin.clear_async()
            cleared = True
            assert time.monotonic() - started_at < 2
            response_thread.join(timeout=2)
            assert not response_thread.is_alive()

            file_events = [json.loads(line) for line in (tmp_path / "events.jsonl").read_text().splitlines()]
            stream_events = [json.loads(body) for body in received]
            assert len(file_events) == len(stream_events) == 3
            file_mark = next(event for event in file_events if event["name"] == "python-dotted-mark")
            stream_mark = next(event for event in stream_events if event["name"] == "python-dotted-mark")
            assert file_mark["data"] == {
                "service.name": "relay",
                "nested": {"deployment.region": "us-east"},
            }
            assert stream_mark["data"] == expected_data
        finally:
            allow_response.set()
            if not cleared:
                await plugin.clear_async()
            server.shutdown()
            server_thread.join(timeout=5)
            server.server_close()

    async def test_atif_flushes_open_agent_on_clear(self, tmp_path):
        await plugin.initialize(
            plugin.PluginConfig(
                components=[
                    ComponentSpec(ObservabilityConfig(atif=AtifConfig(enabled=True, output_directory=str(tmp_path))))
                ]
            )
        )
        handle = scope.push("python-open-agent", ScopeType.Agent)
        try:
            await plugin.clear_async()
            assert (tmp_path / f"nemo-relay-atif-{handle.uuid}.json").exists()
        finally:
            scope.pop(handle)

    async def test_atif_can_use_propagation_root_as_run_session_id(self, tmp_path):
        request_id = "018f47a4-3af7-7d94-8e61-9f0f89b5d312"
        stack = create_scope_stack_from_propagation(PropagationContext(request_id, request_id))
        await plugin.initialize(
            plugin.PluginConfig(
                components=[
                    ComponentSpec(
                        ObservabilityConfig(
                            atif=AtifConfig(
                                enabled=True,
                                output_directory=str(tmp_path),
                                filename_template="trajectory-{session_id}.json",
                            )
                        )
                    )
                ]
            )
        )
        try:
            with use_scope_stack(stack):
                with scope.scope("python-propagated-agent", ScopeType.Agent) as handle:
                    scope.event("python-mark", handle=handle, data={"step": 1})
        finally:
            await plugin.clear_async()

        trajectory_path = tmp_path / f"trajectory-{handle.uuid}.json"
        trajectory = json.loads(trajectory_path.read_text())
        assert trajectory["session_id"] == request_id
        assert trajectory["trajectory_id"] == handle.uuid
        assert trajectory["extra"]["nemo_relay"]["session_instance_id"] == request_id

    async def test_atif_non_string_metadata_is_reported_and_failed_clear_is_drainable(self, tmp_path):
        await plugin.initialize(
            plugin.PluginConfig(
                components=[
                    ComponentSpec(
                        ObservabilityConfig(
                            atif=AtifConfig(
                                enabled=True,
                                output_directory=str(tmp_path),
                                filename_template="{metadata.atif_prefix:-unassigned}/trajectory-{session_id}.json",
                            )
                        )
                    )
                ]
            )
        )

        try:
            with scope.scope("python-invalid-metadata-agent", ScopeType.Agent, metadata={"atif_prefix": 123}):
                pass
            await subscribers.flush_async()

            report = plugin.report()
            assert report is not None
            assert any(
                diagnostic["code"] == "atif.destination_render_failed" and "non-string" in diagnostic["message"]
                for diagnostic in report["runtime_diagnostics"]
            )
            assert not (tmp_path / "unassigned").exists()

            with pytest.raises(RuntimeError, match=r"atif\.destination_render_failed") as teardown:
                await plugin.clear_async()
            assert "could not be removed" not in str(teardown.value)
            retained = plugin.report()
            assert retained is not None
            assert any(
                diagnostic["code"] == "atif.destination_render_failed" for diagnostic in retained["runtime_diagnostics"]
            )
        finally:
            try:
                await plugin.clear_async()
            except RuntimeError:
                await plugin.clear_async()
        assert plugin.report() is None

    async def test_atif_splits_multiple_top_level_agent_scopes(self, tmp_path):
        await plugin.initialize(
            plugin.PluginConfig(
                components=[
                    ComponentSpec(
                        ObservabilityConfig(
                            atif=AtifConfig(
                                enabled=True,
                                output_directory=str(tmp_path),
                                filename_template="trajectory-{session_id}.json",
                            )
                        )
                    )
                ]
            )
        )
        try:
            with scope.scope("python-first-agent", ScopeType.Agent) as first:
                scope.event("python-first-mark", handle=first, data={"agent": "first"})
                with scope.scope("python-nested-agent", ScopeType.Agent) as nested:
                    scope.event("python-nested-mark", handle=nested, data={"agent": "nested"})

            with scope.scope("python-second-agent", ScopeType.Agent) as second:
                scope.event("python-second-mark", handle=second, data={"agent": "second"})
        finally:
            await plugin.clear_async()

        files = sorted(tmp_path.glob("trajectory-*.json"))
        assert len(files) == 2

        first_trajectory = json.loads((tmp_path / f"trajectory-{first.uuid}.json").read_text())
        second_trajectory = json.loads((tmp_path / f"trajectory-{second.uuid}.json").read_text())
        first_payload = json.dumps(first_trajectory["extra"])
        second_payload = json.dumps(second_trajectory["extra"])

        assert "python-first-agent" in first_payload
        assert "python-nested-agent" in first_payload
        assert "python-second-agent" not in first_payload
        assert "python-second-agent" in second_payload
        assert "python-first-agent" not in second_payload
        assert "python-nested-agent" not in second_payload
