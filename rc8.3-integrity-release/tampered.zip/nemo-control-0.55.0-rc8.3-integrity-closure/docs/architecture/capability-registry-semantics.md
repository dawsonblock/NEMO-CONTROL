# Capability Registry Semantics

This document resolves the registry's identity permanently:
**`registry_sha256` identifies the complete policy-defined capability
catalog shipped by a release.** It does not identify which capabilities
happen to have configured adapters on a particular machine.

## registry = the release's capability surface

The registry contains every capability the release ships and
recognizes — including capabilities whose adapters are not configured in
a given deployment:

```
system.echo
system.info
test.counter.increment
github.issue.get
github.issue.list
github.issue.create
github.issue.comment
github.issue.close
github.issue.update
github.pr.create
github.pr.merge
```

The registry digest is identical on two machines running the same
qualified release, whether or not GitHub credentials exist. Deployment
configuration never enters the registry, the registry digest, or any
descriptor digest.

## The qualification registry is an explicit extension

Qualification-only capabilities are never members of the release
registry. They are added by an explicit extension layer
(`internal/execution/qualification_registry.go`) under one rule:

```
exact release registry + explicit qualification descriptors
  = qualification registry
```

The extension refuses to overwrite or modify an existing release
descriptor, so a qualification build can never silently replace
production policy. The qualification registry therefore has its own
digest, and the record that binds the two identities
(`RegistryExtensionRecord`) carries the release digest, the
qualification digest, and the descriptor digest of every
qualification-only capability that separates them. The two digests are
deliberately different: the release digest identifies the security
policy a release ships, the qualification digest identifies the policy
the qualification build actually loaded.

`qualification.critical.commit` exists only as such an extension: it is
registered when a deployment explicitly configures the external
qualification provider (`CRABEDENCE_QUAL_PROVIDER_URL`). Unset, the
service serves the unmodified release registry and its digest is
unchanged.

## Four different states

| State | Question | Decided by | Failure code |
|---|---|---|---|
| `KNOWN` | Does this release recognize the capability? | The built-in catalog (compiled into the build) | `CAPABILITY_NOT_FOUND` when no |
| `AVAILABLE` | Can this deployment currently execute it? | Adapter wiring / health (runtime state) | `CAPABILITY_UNAVAILABLE` when no |
| `AUTHORIZED` | Does the principal hold authority for it? | Grant resolution at admission | `UNAUTHORIZED` when no |
| `EXECUTABLE` | Is this specific request admitted right now? | Admission (class assertion, schema, idempotency key, deadline) | `ADMISSION_DENIED` / `INVALID_REQUEST` when no |

These are orthogonal. A capability can be `KNOWN` but not `AVAILABLE`
(GitHub not configured), `AVAILABLE` but not `AUTHORIZED` (no grant),
or `AUTHORIZED` but not `EXECUTABLE` (missing idempotency key, expired
deadline). Each failure is reported with its own code; they are never
collapsed into each other.

Availability values (`internal/capability/availability.go`):

```
AVAILABLE
ADAPTER_NOT_CONFIGURED
ADAPTER_UNHEALTHY
FEATURE_DISABLED
```

## Availability is runtime state, never policy

Availability lives beside the registry, never inside it:

- It is not written into `ResolvedDescriptor` and never changes a
  descriptor's `execution_class`, `execution_route`,
  `assurance_profile`, authority policy, schemas, or digest.
- An unavailable adapter fails closed at dispatch. It never becomes a
  routing change, a `LOCAL`/`DIRECT` fallback, or a class downgrade.
- The failure is pre-dispatch and therefore definitive:
  `FAILED` + `CAPABILITY_UNAVAILABLE` + `definitive_failure` on the wire,
  never `UNKNOWN` and never `reconciliation_required` — nothing ran, so
  no effect is possible for any execution class.
- Enabling an integration does not change the security catalog.

**INV-014**: provider availability cannot modify capability security
classification.

## registry_sha256 vs runtime_configuration_sha256

Two identities, deliberately distinct:

| Identity | Covers | Changes when |
|---|---|---|
| `registry_sha256` | Descriptors sorted by ID, canonicalized: id, descriptor version, policy revision, class, assurance, route, schema, authority policy, adapter binding | The release's capability policy changes |
| `runtime_configuration_sha256` | Safe, normalized deployment identity: schema version, release, registry digest, effect-store backend, enabled adapters | The deployment's configuration changes |

`runtime_configuration_sha256` is computed over non-secret identity
only. API keys, passwords, OAuth tokens, cookies, private keys,
database credentials, and raw environment variables are excluded by
construction — the structure has no field for them.

Runtime identity is therefore:

```
release identity + registry identity + configuration identity
```

without leaking secrets, and without configuration contaminating the
policy identity.

## Three-way registry verification

Release qualification establishes, and the release evidence binds, one
value three ways:

```
registry generated from the exact qualified source
        ↓  registry_sha256 = ABC
artifact.json binds          registry_sha256 = ABC
runtime serves               registry_sha256 = ABC
```

`cmd/registry-digest` computes the digest from the same built-in
registration path the service uses at startup, so qualified policy =
released policy = runtime policy is checkable, not asserted.

## Where this is enforced

| Rule | Enforcement |
|---|---|
| Complete built-in catalog registered unconditionally | `internal/execution/serve.go`; `cmd/registry-digest` |
| Qualification capabilities are extensions, never release members | `internal/execution/qualification_registry.go`; `RegistryExtensionRecord` |
| Availability separate from policy | `internal/capability/availability.go`; `Registry.Availability` |
| Unavailable ≠ unknown | `CAPABILITY_UNAVAILABLE` + `ADAPTER_NOT_CONFIGURED` reason |
| No routing/class fallback | `RouteDispatcher`; `MultiHandler` |
| Digest covers policy only | `internal/capability/registry_digest.go` |
| Runtime identity excludes secrets | `internal/execution/runtime_identity.go` |
